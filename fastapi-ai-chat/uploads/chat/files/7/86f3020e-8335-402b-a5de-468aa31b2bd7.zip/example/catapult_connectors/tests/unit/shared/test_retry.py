import pytest
import asyncio
from unittest.mock import Mock, call
from connectors.shared.retry import async_retry
from connectors.shared.errors import NetworkError, InternalServerError, NotFoundError

@pytest.mark.asyncio
async def test_retry_success(mocker):
    """Test that function succeeds without retries if no error."""
    mock_func = Mock(return_value="success")
    
    @async_retry()
    async def decorated_func():
        return mock_func()
    
    result = await decorated_func()
    
    assert result == "success"
    assert mock_func.call_count == 1

@pytest.mark.asyncio
async def test_retry_eventual_success(mocker):
    """Test that function retries and eventually succeeds."""
    # Fail twice, then succeed
    mock_func = Mock(side_effect=[NetworkError("fail1"), NetworkError("fail2"), "success"])
    # Mock sleep to avoid actual waiting
    mock_sleep = mocker.patch("asyncio.sleep", return_value=None)
    
    @async_retry(max_retries=3, delay=0.1, jitter=0)
    async def decorated_func():
        return mock_func()
    
    result = await decorated_func()
    
    assert result == "success"
    assert mock_func.call_count == 3
    assert mock_sleep.call_count == 2

@pytest.mark.asyncio
async def test_retry_max_retries_exceeded(mocker):
    """Test that function raises exception after max retries."""
    mock_func = Mock(side_effect=NetworkError("fail"))
    mock_sleep = mocker.patch("asyncio.sleep", return_value=None)
    
    @async_retry(max_retries=2, delay=0.1, jitter=0)
    async def decorated_func():
        return mock_func()
    
    with pytest.raises(NetworkError):
        await decorated_func()
        
    # Initial call + 2 retries = 3 calls
    assert mock_func.call_count == 3
    assert mock_sleep.call_count == 2

@pytest.mark.asyncio
async def test_retry_unhandled_exception(mocker):
    """Test that function does not retry on unhandled exceptions."""
    # NotFoundError is not in default retry list
    mock_func = Mock(side_effect=NotFoundError("fail"))
    mock_sleep = mocker.patch("asyncio.sleep", return_value=None)
    
    @async_retry(max_retries=3)
    async def decorated_func():
        return mock_func()
    
    with pytest.raises(NotFoundError):
        await decorated_func()
        
    assert mock_func.call_count == 1
    assert mock_sleep.call_count == 0

@pytest.mark.asyncio
async def test_retry_custom_exceptions(mocker):
    """Test that function retries on custom specified exceptions."""
    mock_func = Mock(side_effect=[ValueError("fail"), "success"])
    mock_sleep = mocker.patch("asyncio.sleep", return_value=None)
    
    @async_retry(max_retries=3, exceptions=(ValueError,))
    async def decorated_func():
        return mock_func()
    
    result = await decorated_func()
    
    assert result == "success"
    assert mock_func.call_count == 2

@pytest.mark.asyncio
async def test_retry_backoff(mocker):
    """Test that backoff is applied to sleep times."""
    mock_func = Mock(side_effect=[NetworkError("fail"), NetworkError("fail"), "success"])
    mock_sleep = mocker.patch("asyncio.sleep", return_value=None)
    
    # Delay 0.1, Backoff 2.0 -> Sleeps: 0.1, 0.2
    @async_retry(max_retries=3, delay=0.1, backoff=2.0, jitter=0)
    async def decorated_func():
        return mock_func()
    
    await decorated_func()
    
    assert mock_sleep.call_count == 2
    # Check arguments of sleep calls (approximate)
    mock_sleep.assert_has_calls([call(0.1), call(0.2)])