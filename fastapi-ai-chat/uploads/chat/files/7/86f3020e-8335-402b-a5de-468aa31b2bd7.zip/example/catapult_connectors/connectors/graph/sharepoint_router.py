"""
FastAPI router for SharePoint/OneDrive connector endpoints.

Uses Microsoft Graph API with On-Behalf-Of (OBO) authentication,
allowing per-user access to files and sites via Copilot Studio.
"""
from fastapi import APIRouter, Query, Path, Body, UploadFile, File, Depends
from typing import Optional, List
from fastapi.responses import StreamingResponse
import io

from .client import GraphClient
from .models import Site, Drive, DriveItem, FolderCreate, SearchResult
from ..shared.dependencies import validate_token, UserContext

router = APIRouter()


@router.get(
    "/sites",
    response_model=List[Site],
    operation_id="sharepoint_get_sites",
    summary="List SharePoint sites",
    description="Get SharePoint sites you have access to. Optionally search by name."
)
async def get_sites(
    search: Optional[str] = Query(None, description="Search sites by name"),
    user: UserContext = Depends(validate_token)
) -> List[Site]:
    """Get SharePoint sites accessible to the user."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.get_sites(search=search)
    finally:
        await client.close()


@router.get(
    "/sites/{site_id}/drives",
    response_model=List[Drive],
    operation_id="sharepoint_get_drives",
    summary="List document libraries",
    description="Get all document libraries for a SharePoint site."
)
async def get_drives(
    site_id: str = Path(..., description="SharePoint site ID"),
    user: UserContext = Depends(validate_token)
) -> List[Drive]:
    """Get document libraries."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.get_drives(site_id)
    finally:
        await client.close()


@router.get(
    "/me/drive",
    response_model=List[DriveItem],
    operation_id="onedrive_list_root",
    summary="List OneDrive root",
    description="List files and folders in your OneDrive root folder."
)
async def list_onedrive_root(
    user: UserContext = Depends(validate_token)
) -> List[DriveItem]:
    """List user's OneDrive root items."""
    client = GraphClient(user_token=user.token)
    try:
        # For user's OneDrive, use the /me/drive endpoint
        return await client.list_items("me", folder_path=None)
    finally:
        await client.close()


@router.get(
    "/drives/{drive_id}/items",
    response_model=List[DriveItem],
    operation_id="sharepoint_list_items",
    summary="List files and folders",
    description="List all files and folders in a drive or specific folder path."
)
async def list_items(
    drive_id: str = Path(..., description="Drive/library ID"),
    folder_path: Optional[str] = Query(None, description="Folder path (e.g., 'Projects/Client A')"),
    user: UserContext = Depends(validate_token)
) -> List[DriveItem]:
    """List files and folders."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.list_items(drive_id, folder_path=folder_path)
    finally:
        await client.close()


@router.get(
    "/drives/{drive_id}/items/{item_id}",
    response_model=DriveItem,
    operation_id="sharepoint_get_item",
    summary="Get file or folder metadata",
    description="Get detailed metadata for a specific file or folder."
)
async def get_item(
    drive_id: str = Path(..., description="Drive/library ID"),
    item_id: str = Path(..., description="Item ID"),
    user: UserContext = Depends(validate_token)
) -> DriveItem:
    """Get item metadata."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.get_item(drive_id, item_id)
    finally:
        await client.close()


@router.post(
    "/upload",
    response_model=DriveItem,
    operation_id="sharepoint_upload_file",
    summary="Upload file",
    description="Upload a file to SharePoint. For files larger than 4MB, use resumable upload."
)
async def upload_file(
    drive_id: str = Query(..., description="Drive/library ID"),
    folder_path: str = Query(..., description="Target folder path"),
    file_name: str = Query(..., description="Name for the uploaded file"),
    file: UploadFile = File(..., description="File to upload"),
    user: UserContext = Depends(validate_token)
) -> DriveItem:
    """Upload a file."""
    client = GraphClient(user_token=user.token)
    try:
        content = await file.read()
        return await client.upload_file(drive_id, folder_path, file_name, content)
    finally:
        await client.close()


@router.get(
    "/download/{drive_id}/{item_id}",
    operation_id="sharepoint_download_file",
    summary="Download file",
    description="Download a file's content. Returns the file as a binary stream."
)
async def download_file(
    drive_id: str = Path(..., description="Drive/library ID"),
    item_id: str = Path(..., description="File item ID"),
    user: UserContext = Depends(validate_token)
):
    """Download file content."""
    client = GraphClient(user_token=user.token)
    try:
        content = await client.download_file(drive_id, item_id)
        return StreamingResponse(
            io.BytesIO(content),
            media_type="application/octet-stream"
        )
    finally:
        await client.close()


@router.post(
    "/folders",
    response_model=DriveItem,
    operation_id="sharepoint_create_folder",
    summary="Create folder",
    description="Create a new folder in SharePoint."
)
async def create_folder(
    drive_id: str = Query(..., description="Drive/library ID"),
    folder: FolderCreate = Body(..., description="Folder details"),
    user: UserContext = Depends(validate_token)
) -> DriveItem:
    """Create a folder."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.create_folder(drive_id, folder.parent_path, folder.folder_name)
    finally:
        await client.close()


@router.get(
    "/search",
    response_model=List[SearchResult],
    operation_id="sharepoint_search",
    summary="Search files",
    description="Search for files and folders in a document library by name or content."
)
async def search_files(
    drive_id: str = Query(..., description="Drive/library ID to search in"),
    query: str = Query(..., min_length=2, description="Search query"),
    user: UserContext = Depends(validate_token)
) -> List[SearchResult]:
    """Search for files."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.search_files(drive_id, query)
    finally:
        await client.close()
