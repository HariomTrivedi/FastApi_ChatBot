# Catapult Connectors API

## Overview

Catapult Connectors is a unified API backend designed for Microsoft Copilot Studio integration. It provides REST API endpoints that wrap multiple external services, allowing Copilot Studio agents to interact with various business tools through a single, consistent interface.

## Table of Contents

- [Architecture](./ARCHITECTURE.md)
- [API Reference](./API-REFERENCE.md)
- [Deployment Guide](./DEPLOYMENT.md)
- [Development Guide](./DEVELOPMENT.md)
- [Connector Documentation](./CONNECTORS.md)

## Supported Connectors

| Connector | Description | Status |
|-----------|-------------|--------|
| **Simplicate CRM** | Client management, projects, time tracking, capacity | ✅ Complete |
| **Trello** | Boards, lists, cards, todo tracking | ✅ Complete |
| **Microsoft Graph - Mail** | Outlook inbox, send/forward emails | ✅ Complete |
| **Microsoft Graph - Calendar** | Events, scheduling, availability | ✅ Complete |
| **Microsoft Graph - SharePoint** | Sites, drives, files, folders | ✅ Complete |
| **Word Documents** | Create, modify, analyze .docx files | ✅ Complete |

## Technology Stack

- **Runtime**: Azure Container Apps (Docker)
- **Framework**: FastAPI
- **Language**: Python 3.11+
- **Server**: Uvicorn (Development) / Gunicorn (Production)
- **Authentication**:
  - OAuth 2.0 On-Behalf-Of (OBO) flow for Microsoft Graph
  - API Key/Secret for Simplicate
  - API Key/Token for Trello
- **Containerization**: Docker

## Quick Start

### Prerequisites

- Python 3.11+
- Docker (optional, for containerized testing)
- Git

### Local Development

```bash
# Clone and navigate
cd catapult_connectors

# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
.venv\Scripts\activate     # Windows

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your credentials

# Run locally with hot reload
uvicorn main:app --reload --port 8000
```

### Run with Docker

```bash
# Build image
docker build -t catapult-connectors .

# Run container
docker run -p 8000:8000 --env-file .env catapult-connectors
```

### Access API Documentation

Once running, access the interactive API docs:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc
- OpenAPI JSON: http://localhost:8000/openapi.json

## Project Structure

```
catapult_connectors/
├── main.py                      # FastAPI entry point
├── requirements.txt             # Python dependencies
├── .env.example                 # Environment template
├── Dockerfile                   # Container configuration
├── azure-pipelines.yml          # CI/CD pipeline
│
├── connectors/                  # Connector implementations
│   ├── shared/                  # Shared utilities
│   │   ├── auth.py              # Authentication handlers
│   │   ├── errors.py            # Error handling
│   │   └── config.py            # Configuration
│   │
│   ├── simplicate/              # Simplicate CRM connector
│   │   ├── client.py            # API client
│   │   ├── router.py            # FastAPI endpoints
│   │   └── models.py            # Pydantic models
│   │
│   ├── trello/                  # Trello connector
│   │   ├── client.py
│   │   ├── router.py
│   │   └── models.py
│   │
│   ├── graph/                   # Microsoft Graph connectors
│   │   ├── client.py            # Unified Graph client
│   │   ├── mail_router.py       # Outlook Mail endpoints
│   │   ├── calendar_router.py   # Calendar endpoints
│   │   ├── sharepoint_router.py # SharePoint endpoints
│   │   └── models.py            # Shared Graph models
│   │
│   └── word/                    # Word document connector
│       ├── client.py
│       ├── router.py
│       └── models.py
│
├── openapi/                     # OpenAPI/Swagger tools
│   └── generate_swagger.py      # Swagger 2.0 converter
│
├── documentation/               # This documentation
│   ├── README.md
│   ├── ARCHITECTURE.md
│   ├── API-REFERENCE.md
│   ├── DEPLOYMENT.md
│   ├── DEVELOPMENT.md
│   └── CONNECTORS.md
│
└── tests/                       # Test suites
    └── ...
```

## Copilot Studio Integration

This API is designed for seamless integration with Microsoft Copilot Studio:

1. **Generate Swagger 2.0 spec** (required by Copilot Studio):
   ```bash
   # For local dev
   python openapi/generate_swagger.py --host localhost:8000

   # For production (Azure Container Apps)
   python openapi/generate_swagger.py --host your-container-app.azurecontainer.io --https
   ```

2. **Import into Copilot Studio**:
   - Go to your Copilot Studio agent
   - Navigate to Actions → Add an action
   - Select "Import from OpenAPI"
   - Upload the generated `swagger.json`

3. **Configure authentication**:
   - **Authentication Type**: OAuth 2.0
   - **Client ID/Secret**: From your Azure AD App Registration
   - **Scopes**: `api://<client-id>/access_as_user` (for OBO flow)
   - **Token Exchange**: Configured to exchange User Token for Graph Token

## License

Proprietary - Synthwave Solutions

## Support

For issues and feature requests, contact the development team.
