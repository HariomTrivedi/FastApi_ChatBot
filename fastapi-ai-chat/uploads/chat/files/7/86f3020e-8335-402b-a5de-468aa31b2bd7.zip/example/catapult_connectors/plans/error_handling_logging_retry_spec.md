# Technical Specification: Consistent Error Handling, Logging, and Retry Strategy

## 1. Introduction

This document outlines a standardized approach for error handling, logging, and retry mechanisms across the Catapult Connectors codebase. The goal is to improve observability, maintainability, and resilience against transient failures in integrations with external APIs.

## 2. Current State Analysis

### 2.1. Error Handling (`connectors/shared/errors.py`, `function_app.py`)
- **`ConnectorError`**: A base exception class is defined, allowing for structured error responses with `status_code`, `error` (a string code), `message`, `details`, and `connector`.
- **Connector-Specific Exceptions**: `SimplicateError`, `TrelloError`, and `GraphError` inherit from `ConnectorError`, mapping specific API status codes to predefined error strings. `AuthenticationError` and `ConfigurationError` also exist.
- **Global Exception Handler**: `function_app.py` registers `connector_error_handler` to catch `ConnectorError` instances globally, ensuring consistent JSON error responses from the FastAPI application.
- **`handle_http_error`**: A utility function to convert HTTP response status codes and text into appropriate `ConnectorError` subclasses.

### 2.2. Logging (`connectors/shared/config.py`, Client Modules)
- **Basic Python Logging**: Each module (`connectors/graph/client.py`, `connectors/trello/client.py`, `connectors/shared/errors.py`) initializes its own logger using `logging.getLogger(__name__)`.
- **Configurable Log Level**: `connectors/shared/config.py` defines a `log_level` setting (defaulting to "INFO"), which is likely used to configure the root logger, though explicit configuration is not centralized in `shared`.
- **Format**: Logging output appears to be text-based, typical of default Python `logging` configuration. `extra` dictionaries are used for additional context.

### 2.3. Retries
- No explicit, standardized retry mechanism is currently in place across the connector clients. Failures typically result in immediate exceptions.

## 3. Design Principles

- **Consistency**: All connectors should follow the same patterns for logging, error handling, and retries.
- **Observability**: Logs should be structured (JSON) and contain sufficient context for debugging and monitoring in a cloud environment.
- **Resilience**: Transient failures should be handled gracefully with configurable retry mechanisms.
- **Extensibility**: The design should allow for easy addition of new connectors and error types.
- **Maintainability**: Centralize common logic to reduce duplication and simplify updates.

## 4. Proposed Design

### 4.1. Logging Strategy

#### **Objective**
Implement standardized, structured (JSON) logging for all connector operations, configurable via environment variables.

#### **Implementation Steps**

1.  **Create `connectors/shared/logging_config.py`**:
    *   This new module will contain a function, e.g., `configure_logging()`, that sets up the root logger.
    *   It will read the `log_level` from `connectors/shared/config.py`.
    *   It will configure a `logging.Formatter` that outputs logs in JSON format. A custom `JsonFormatter` class might be needed if Python's `logging.basicConfig` doesn't directly support JSON output.
    *   Example fields for JSON logs: `timestamp`, `level`, `name` (logger name), `message`, `service` (e.g., "catapult-connectors"), `environment`, `connector` (if applicable), `details` (from `extra` dict).
    *   Ensure the `configure_logging()` function is called early in the application lifecycle (e.g., in `function_app.py`'s `lifespan` event or directly at the top of the file).

2.  **Update `connectors/shared/config.py`**:
    *   Add any new logging-related configuration parameters if deemed necessary (e.g., `log_format` to switch between JSON/text, though JSON will be default).

3.  **Review existing logger instances**:
    *   Confirm that `logger = logging.getLogger(__name__)` is consistently used in all modules.
    *   Ensure calls like `logger.error(..., extra={"details": ...})` are utilized to pass structured data into logs.

### 4.2. Error Handling Strategy

#### **Objective**
Refine the custom exception hierarchy to provide more granular, standardized error types that map common API issues to consistent internal exceptions, improving clarity and enabling more specific handling.

#### **Implementation Steps**

1.  **Enhance `connectors/shared/errors.py`**:
    *   **New Standardized Error Classes**: Introduce new subclasses of `ConnectorError` for common, generic HTTP error categories. These will serve as common parents for connector-specific errors where appropriate.
        *   `class UnauthorizedError(ConnectorError)`: status_code=401, error="UNAUTHORIZED"
        *   `class ForbiddenError(ConnectorError)`: status_code=403, error="FORBIDDEN"
        *   `class NotFoundError(ConnectorError)`: status_code=404, error="NOT_FOUND"
        *   `class TooManyRequestsError(ConnectorError)`: status_code=429, error="TOO_MANY_REQUESTS"
        *   `class ServiceUnavailableError(ConnectorError)`: status_code=503, error="SERVICE_UNAVAILABLE" (for transient server issues)
        *   `class InternalServerError(ConnectorError)`: status_code=500, error="INTERNAL_SERVER_ERROR" (for unhandled 5xx errors)
        *   `class NetworkError(ConnectorError)`: status_code=500, error="NETWORK_ERROR" (for `httpx.RequestError` and similar connection issues).
    *   **Refactor Connector-Specific Errors**: Update `SimplicateError`, `TrelloError`, and `GraphError` to inherit from these new standardized classes where appropriate, or directly from `ConnectorError` if they represent a unique connector-specific issue that doesn't fit a generic HTTP error.
        *   For example, if Trello returns a 401, it should raise an `UnauthorizedError` (or `TrelloUnauthorizedError` inheriting from `UnauthorizedError` if more specificity is required).
    *   **Update `handle_http_error`**: Modify this function to prioritize raising the new, generic HTTP error classes based on `response_status` before falling back to connector-specific types.
        *   It should also handle `httpx.RequestError` (e.g., `httpx.ConnectError`, `httpx.TimeoutException`) by raising a `NetworkError`.

2.  **Review Client Implementations**:
    *   In `connectors/graph/client.py`, `connectors/trello/client.py`, etc., ensure that `_request` methods catch `httpx.RequestError` and raise the new `NetworkError`.
    *   Update `_request` methods to raise the new standardized HTTP errors based on `response.status_code` instead of generic `GraphError`/`TrelloError` where possible.
    *   Update `ConfigurationError` and `AuthenticationError` in `shared/errors.py` to ensure their `status_code` and `error` align with the new hierarchy. `AuthenticationError` could inherit from `UnauthorizedError`.

### 4.3. Retry Strategy

#### **Objective**
Develop a flexible and configurable retry mechanism for handling transient failures in API client operations.

#### **Implementation Steps**

1.  **Create `connectors/shared/retry.py`**:
    *   This new module will contain an `async` decorator, e.g., `@retry_async`, designed to wrap `async` methods in client classes.
    *   **Parameters**: The decorator should accept parameters for `max_tries`, `delay` (initial delay in seconds), `backoff` (multiplier for exponential backoff), `jitter` (random factor for delay), and `exceptions_to_retry` (a tuple of exception types to catch and retry).
    *   **Logic**:
        *   Catch specified exceptions.
        *   Implement exponential backoff with jitter: `delay = min(max_delay, delay * backoff * (1 + random.uniform(-jitter, jitter)))`.
        *   Log each retry attempt (`logger.warning("Retrying attempt %d for %s due to %s", attempt, func.__name__, exc)`).
        *   After `max_tries`, re-raise the last exception if all attempts fail.

2.  **Update `connectors/shared/config.py`**:
    *   Add configuration settings for the retry mechanism: `default_max_retries`, `default_retry_delay`, `default_retry_backoff`, `default_retry_jitter`.

3.  **Apply Retry Decorator to Client Methods**:
    *   Identify methods in `GraphClient`, `TrelloClient`, `SimplicateClient`, `WordClient` that make external HTTP requests and are susceptible to transient failures (e.g., `_request` helper methods or specific public methods).
    *   Apply the `@retry_async` decorator to these methods, using the default settings from `config.py` or overriding them as needed.

## 5. Mermaid Diagrams

```mermaid
classDiagram
    exception <|-- ConnectorError
    ConnectorError <|-- UnauthorizedError
    ConnectorError <|-- ForbiddenError
    ConnectorError <|-- NotFoundError
    ConnectorError <|-- TooManyRequestsError
    ConnectorError <|-- ServiceUnavailableError
    ConnectorError <|-- InternalServerError
    ConnectorError <|-- NetworkError
    
    UnauthorizedError <|-- AuthenticationError
    InternalServerError <|-- ConfigurationError
    
    TooManyRequestsError <|-- SimplicateError
    NotFoundError <|-- SimplicateError
    UnauthorizedError <|-- SimplicateError
    SimplicateError --|> ConnectorError : falls back
    
    TooManyRequestsError <|-- TrelloError
    NotFoundError <|-- TrelloError
    UnauthorizedError <|-- TrelloError
    TrelloError --|> ConnectorError : falls back
    
    TooManyRequestsError <|-- GraphError
    NotFoundError <|-- GraphError
    UnauthorizedError <|-- GraphError
    ServiceUnavailableError <|-- GraphError
    GraphError --|> ConnectorError : falls back
    
    class ConnectorError {
        +int status_code
        +str error
        +str message
        +dict details
        +str connector
        +to_response() ErrorResponse
    }
    
    class UnauthorizedError {
        +__init__(message)
    }
    
    class NetworkError {
        +__init__(message)
    }

    class SimplicateError {
        +__init__(status_code, message, details)
    }
    class TrelloError {
        +__init__(status_code, message, details)
    }
    class GraphError {
        +__init__(status_code, message, details)
    }
```

```mermaid
graph TD
    A[Application Request] --> B{API Client Call}
    B -->|Success| C[Process Response]
    B -->|Transient Error (Network, Rate Limit, 5xx)| D{Retry Decorator}
    D -->|Attempts < Max Retries| E[Wait with Exponential Backoff + Jitter]
    E --> B
    D -->|Attempts == Max Retries| F[Re-raise Exception]
    B -->|Non-Transient Error (4xx)| F
    F --> G[Centralized Error Handler]
    G --> H[Log Structured Error]
    G --> I[Return Standardized Error Response]
```

## 6. Conclusion

This technical specification provides a clear roadmap for implementing a consistent and robust error handling, logging, and retry strategy across Catapult Connectors. Adhering to these guidelines will significantly improve the stability and maintainability of the integration layer.