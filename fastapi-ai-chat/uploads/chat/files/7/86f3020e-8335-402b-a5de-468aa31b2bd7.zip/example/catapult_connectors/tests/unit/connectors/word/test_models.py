import pytest
from pydantic import ValidationError
from connectors.word.models import (
    DocumentCreateRequest, DocumentSection, ParagraphContent, HeadingContent,
    TableContent, ImageContent, HeadingLevel, TextAlignment, DocumentFromTemplateRequest
)

class TestWordModels:

    def test_document_create_request_valid(self):
        """Test creating a valid DocumentCreateRequest."""
        data = {
            "title": "Test Document",
            "sections": [
                {
                    "type": "heading",
                    "content": {"text": "Heading 1", "level": 1}
                },
                {
                    "type": "paragraph",
                    "content": {"text": "A paragraph.", "alignment": "center"}
                }
            ]
        }
        model = DocumentCreateRequest(**data)
        assert model.title == "Test Document"
        assert len(model.sections) == 2
        assert model.sections[0].type == "heading"
        assert isinstance(model.sections[0].content, dict)
        
        # Verify nested conversion/validation
        heading = HeadingContent(**model.sections[0].content)
        assert heading.text == "Heading 1"
        assert heading.level == HeadingLevel.H1

    def test_document_create_request_missing_sections(self):
        """Test that sections are required."""
        data = {"title": "No Sections"}
        with pytest.raises(ValidationError):
            DocumentCreateRequest(**data)

    def test_paragraph_content_valid(self):
        """Test valid paragraph content."""
        data = {
            "text": "Hello World",
            "alignment": "left",
            "font_style": {"bold": True, "size_pt": 12}
        }
        model = ParagraphContent(**data)
        assert model.text == "Hello World"
        assert model.alignment == TextAlignment.LEFT
        assert model.font_style.bold is True
        assert model.font_style.size_pt == 12

    def test_heading_content_valid(self):
        """Test valid heading content."""
        data = {"text": "My Heading", "level": 2}
        model = HeadingContent(**data)
        assert model.text == "My Heading"
        assert model.level == HeadingLevel.H2

    def test_heading_content_invalid_level(self):
        """Test invalid heading level."""
        data = {"text": "My Heading", "level": 10}
        with pytest.raises(ValidationError):
            HeadingContent(**data)

    def test_table_content_valid(self):
        """Test valid table content."""
        data = {
            "headers": ["Col 1", "Col 2"],
            "rows": [["A", "B"], ["C", "D"]],
            "style": "Table Grid"
        }
        model = TableContent(**data)
        assert len(model.headers) == 2
        assert len(model.rows) == 2
        assert model.rows[0] == ["A", "B"]

    def test_document_from_template_request_valid(self):
        """Test valid template request."""
        data = {
            "template_base64": "SGVsbG8=",
            "replacements": {"{{name}}": "World"}
        }
        model = DocumentFromTemplateRequest(**data)
        assert model.template_base64 == "SGVsbG8="
        assert model.replacements["{{name}}"] == "World"