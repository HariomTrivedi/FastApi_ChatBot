"""
OpenAPI 3.x to Swagger 2.0 converter for Copilot Studio.

Microsoft Copilot Studio requires Swagger 2.0 format for custom connectors.
This script extracts the OpenAPI spec from the FastAPI app and converts it.

Usage:
    python openapi/generate_swagger.py
    python openapi/generate_swagger.py --output swagger.json
    python openapi/generate_swagger.py --host myapi.azurecontainerapps.io
"""
import json
import argparse
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from main import app as fast_app


def convert_openapi3_to_swagger2(
    openapi_spec: Dict[str, Any],
    host: str = "localhost:8000",
    base_path: str = "",
    schemes: List[str] = None,
    api_client_id: str = None
) -> Dict[str, Any]:
    """
    Convert OpenAPI 3.x specification to Swagger 2.0 format.

    Args:
        openapi_spec: OpenAPI 3.x specification dict
        host: API host for Swagger spec
        base_path: Base path prefix for all endpoints
        schemes: List of schemes (http, https)
        api_client_id: Azure AD API app client ID for OAuth configuration

    Returns:
        Swagger 2.0 specification dict
    """
    if schemes is None:
        schemes = ["https"]

    # Determine OAuth configuration
    if api_client_id:
        resource_url = f"api://{api_client_id}"
        scope = f"{resource_url}/access_as_user"
    else:
        resource_url = "api://<YOUR_API_CLIENT_ID>"
        scope = f"{resource_url}/access_as_user"

    swagger = {
        "swagger": "2.0",
        "info": openapi_spec.get("info", {}),
        "host": host,
        "basePath": base_path,
        "schemes": schemes,
        "consumes": ["application/json"],
        "produces": ["application/json"],
        "paths": {},
        "definitions": {},
        "securityDefinitions": {
            "oauth2": {
                "type": "oauth2",
                "flow": "accessCode",
                "authorizationUrl": "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
                "tokenUrl": "https://login.microsoftonline.com/common/oauth2/v2.0/token",
                "scopes": {
                    scope: "Access Catapult Connectors API on behalf of user"
                },
                "x-ms-oauth-resource": resource_url
            }
        },
        "security": [{"oauth2": [scope]}],
        "tags": openapi_spec.get("tags", [])
    }

    # Convert paths
    for path, path_item in openapi_spec.get("paths", {}).items():
        swagger_path = {}

        for method, operation in path_item.items():
            if method in ["get", "post", "put", "patch", "delete", "options", "head"]:
                swagger_operation = convert_operation(operation, openapi_spec)
                swagger_path[method] = swagger_operation

        swagger["paths"][path] = swagger_path

    # Convert components/schemas to definitions
    components = openapi_spec.get("components", {})
    schemas = components.get("schemas", {})

    for name, schema in schemas.items():
        swagger["definitions"][name] = convert_schema(schema)

    return swagger


def convert_operation(operation: Dict[str, Any], openapi_spec: Dict[str, Any]) -> Dict[str, Any]:
    """Convert OpenAPI 3.x operation to Swagger 2.0 format."""
    swagger_op = {
        "operationId": operation.get("operationId", ""),
        "summary": operation.get("summary", ""),
        "description": operation.get("description", ""),
        "tags": operation.get("tags", []),
        "parameters": [],
        "responses": {}
    }

    # Convert parameters
    for param in operation.get("parameters", []):
        swagger_param = convert_parameter(param)
        swagger_op["parameters"].append(swagger_param)

    # Convert request body to body parameter
    request_body = operation.get("requestBody")
    if request_body:
        body_param = convert_request_body(request_body, openapi_spec)
        if body_param:
            swagger_op["parameters"].append(body_param)

    # Convert responses
    for status_code, response in operation.get("responses", {}).items():
        swagger_op["responses"][status_code] = convert_response(response)

    return swagger_op


def convert_parameter(param: Dict[str, Any]) -> Dict[str, Any]:
    """Convert OpenAPI 3.x parameter to Swagger 2.0 format."""
    swagger_param = {
        "name": param.get("name", ""),
        "in": param.get("in", "query"),
        "required": param.get("required", False),
        "description": param.get("description", "")
    }

    schema = param.get("schema", {})

    # Handle schema reference
    if "$ref" in schema:
        ref = schema["$ref"].replace("#/components/schemas/", "#/definitions/")
        swagger_param["schema"] = {"$ref": ref}
    else:
        # Inline schema - flatten for Swagger 2.0
        param_type = schema.get("type", "string")
        swagger_param["type"] = param_type

        if param_type == "array":
            items = schema.get("items", {})
            swagger_param["items"] = convert_schema(items)
            swagger_param["collectionFormat"] = "multi"

        if "default" in schema:
            swagger_param["default"] = schema["default"]

        if "enum" in schema:
            swagger_param["enum"] = schema["enum"]

        if "minimum" in schema:
            swagger_param["minimum"] = schema["minimum"]

        if "maximum" in schema:
            swagger_param["maximum"] = schema["maximum"]

        if "minLength" in schema:
            swagger_param["minLength"] = schema["minLength"]

        if "maxLength" in schema:
            swagger_param["maxLength"] = schema["maxLength"]

    return swagger_param


def convert_request_body(request_body: Dict[str, Any], openapi_spec: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Convert OpenAPI 3.x requestBody to Swagger 2.0 body parameter."""
    content = request_body.get("content", {})

    # Prefer application/json
    json_content = content.get("application/json", {})
    if not json_content:
        # Try other content types
        for content_type, content_schema in content.items():
            json_content = content_schema
            break

    if not json_content:
        return None

    schema = json_content.get("schema", {})

    body_param = {
        "name": "body",
        "in": "body",
        "required": request_body.get("required", True),
        "description": request_body.get("description", "Request body"),
        "schema": convert_schema(schema)
    }

    return body_param


def convert_response(response: Dict[str, Any]) -> Dict[str, Any]:
    """Convert OpenAPI 3.x response to Swagger 2.0 format."""
    swagger_response = {
        "description": response.get("description", "")
    }

    content = response.get("content", {})
    json_content = content.get("application/json", {})

    if json_content:
        schema = json_content.get("schema", {})
        swagger_response["schema"] = convert_schema(schema)

    return swagger_response


def convert_schema(schema: Dict[str, Any]) -> Dict[str, Any]:
    """Convert OpenAPI 3.x schema to Swagger 2.0 format."""
    if not schema:
        return {}

    # Handle $ref
    if "$ref" in schema:
        ref = schema["$ref"].replace("#/components/schemas/", "#/definitions/")
        return {"$ref": ref}

    swagger_schema = {}

    # Copy basic properties
    for key in ["type", "format", "description", "default", "enum",
                "minimum", "maximum", "minLength", "maxLength",
                "minItems", "maxItems", "pattern", "title"]:
        if key in schema:
            swagger_schema[key] = schema[key]

    # Handle nullable (OpenAPI 3.x) - convert to x-nullable for Swagger 2.0
    if schema.get("nullable"):
        swagger_schema["x-nullable"] = True

    # Handle anyOf/oneOf for nullable types
    if "anyOf" in schema:
        # Often used for Optional types: anyOf: [{type: string}, {type: null}]
        non_null_types = [s for s in schema["anyOf"] if s.get("type") != "null"]
        if len(non_null_types) == 1:
            swagger_schema.update(convert_schema(non_null_types[0]))
            swagger_schema["x-nullable"] = True
        else:
            # Complex anyOf - just take the first non-null type
            if non_null_types:
                swagger_schema.update(convert_schema(non_null_types[0]))

    # Handle properties (object type)
    if "properties" in schema:
        swagger_schema["type"] = "object"
        swagger_schema["properties"] = {}
        for prop_name, prop_schema in schema["properties"].items():
            swagger_schema["properties"][prop_name] = convert_schema(prop_schema)

    # Handle required
    if "required" in schema:
        swagger_schema["required"] = schema["required"]

    # Handle items (array type)
    if "items" in schema:
        swagger_schema["items"] = convert_schema(schema["items"])

    # Handle additionalProperties
    if "additionalProperties" in schema:
        ap = schema["additionalProperties"]
        if isinstance(ap, dict):
            swagger_schema["additionalProperties"] = convert_schema(ap)
        else:
            swagger_schema["additionalProperties"] = ap

    # Handle allOf
    if "allOf" in schema:
        swagger_schema["allOf"] = [convert_schema(s) for s in schema["allOf"]]

    return swagger_schema


def generate_swagger(
    output_path: str = "swagger.json",
    host: str = "localhost:8000",
    base_path: str = "",
    schemes: List[str] = None,
    api_client_id: str = None
) -> Dict[str, Any]:
    """
    Generate Swagger 2.0 spec from FastAPI app.

    Args:
        output_path: Path to write the Swagger JSON file
        host: API host for the Swagger spec
        base_path: Base path prefix
        schemes: URL schemes (http, https)
        api_client_id: Azure AD API app client ID for OAuth

    Returns:
        Swagger 2.0 specification dict
    """
    # Get OpenAPI 3.x spec from FastAPI
    openapi_spec = fast_app.openapi()

    # Convert to Swagger 2.0
    swagger_spec = convert_openapi3_to_swagger2(
        openapi_spec,
        host=host,
        base_path=base_path,
        schemes=schemes,
        api_client_id=api_client_id
    )

    # Write to file
    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(swagger_spec, f, indent=2, ensure_ascii=False)

    print(f"Swagger 2.0 specification written to: {output_file.absolute()}")
    print(f"  - Paths: {len(swagger_spec['paths'])}")
    print(f"  - Definitions: {len(swagger_spec['definitions'])}")
    print(f"  - Security: OAuth 2.0 with Azure AD")

    return swagger_spec


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Generate Swagger 2.0 spec for Copilot Studio from FastAPI app"
    )
    parser.add_argument(
        "--output", "-o",
        default="openapi/swagger.json",
        help="Output path for Swagger JSON (default: openapi/swagger.json)"
    )
    parser.add_argument(
        "--host",
        default="catapult-connectors.azurecontainerapps.io",
        help="API host for Swagger spec"
    )
    parser.add_argument(
        "--base-path",
        default="",
        help="Base path prefix (default: empty for Container Apps)"
    )
    parser.add_argument(
        "--schemes",
        nargs="+",
        default=["https"],
        help="URL schemes (default: https)"
    )
    parser.add_argument(
        "--api-client-id",
        default=None,
        help="Azure AD API app client ID for OAuth configuration"
    )
    parser.add_argument(
        "--openapi3",
        action="store_true",
        help="Also output the original OpenAPI 3.x spec"
    )

    args = parser.parse_args()

    # Generate Swagger 2.0
    generate_swagger(
        output_path=args.output,
        host=args.host,
        base_path=args.base_path,
        schemes=args.schemes,
        api_client_id=args.api_client_id
    )

    # Optionally output OpenAPI 3.x as well
    if args.openapi3:
        openapi_path = args.output.replace("swagger", "openapi3")
        openapi_spec = fast_app.openapi()

        with open(openapi_path, "w", encoding="utf-8") as f:
            json.dump(openapi_spec, f, indent=2, ensure_ascii=False)

        print(f"OpenAPI 3.x specification written to: {openapi_path}")


if __name__ == "__main__":
    main()
