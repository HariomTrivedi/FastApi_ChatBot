"""
Simplicate API client for making requests to Simplicate CRM.
Handles authentication, request formatting, and error handling.
"""
import httpx
from typing import Optional, List, Dict, Any
from datetime import date
import logging

from ..shared.auth import get_simplicate_auth, SimplicateAuth
from ..shared.errors import ConfigurationError, handle_http_error, NetworkError
from ..shared.retry import async_retry
from .models import (
    Client, ClientCreate, ClientSearchResult,
    Project, ProjectCreate, ProjectUpdate,
    HoursEntry, HoursEntryCreate,
    Employee, CapacityCheck, EmployeeCapacity, CapacityStatus
)

logger = logging.getLogger(__name__)


class SimplicateClient:
    """
    HTTP client for Simplicate CRM API.

    Handles all communication with Simplicate's REST API including:
    - Client/Organization management
    - Project management
    - Time tracking (hours)
    - Employee/capacity queries
    """

    def __init__(self, auth: Optional[SimplicateAuth] = None):
        self.auth = auth or get_simplicate_auth()
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._client is None:
            if not self.auth.is_configured:
                raise ConfigurationError(
                    connector="simplicate",
                    message="Simplicate API credentials not configured. Set SIMPLICATE_SUBDOMAIN, SIMPLICATE_API_KEY, and SIMPLICATE_API_SECRET."
                )
            self._client = httpx.AsyncClient(
                base_url=self.auth.base_url,
                headers=self.auth.headers,
                timeout=30.0
            )
        return self._client

    @async_retry()
    async def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Make authenticated request to Simplicate API."""
        try:
            response = await self.client.request(
                method=method,
                url=endpoint,
                params=params,
                json=json
            )

            if response.status_code >= 400:
                raise handle_http_error(
                    response_status=response.status_code,
                    response_text=response.text,
                    connector="simplicate",
                    details={"endpoint": endpoint, "method": method}
                )

            return response.json() if response.text else {}

        except httpx.RequestError as e:
            logger.error(f"Simplicate request failed: {e}")
            raise NetworkError(
                message=f"Failed to connect to Simplicate: {str(e)}",
                connector="simplicate"
            )

    # --- Client/Organization Methods ---

    async def get_clients(
        self,
        limit: int = 100,
        offset: int = 0,
        select: Optional[List[str]] = None
    ) -> List[Client]:
        """
        Get all clients/organizations from Simplicate.

        Args:
            limit: Maximum number of results
            offset: Pagination offset
            select: Fields to include in response

        Returns:
            List of Client objects
        """
        params = {"limit": limit, "offset": offset}
        if select:
            params["select"] = ",".join(select)

        response = await self._request("GET", "/crm/organization", params=params)
        data = response.get("data", [])

        return [
            Client(
                id=item.get("id", ""),
                name=item.get("name", ""),
                email=item.get("email"),
                phone=item.get("phone"),
                website=item.get("url"),
                industry=item.get("industry", {}).get("name") if item.get("industry") else None,
                is_active=item.get("is_active", True),
                created_at=item.get("created_at"),
                updated_at=item.get("updated_at")
            )
            for item in data
        ]

    async def get_client(self, client_id: str) -> Client:
        """Get a single client by ID."""
        response = await self._request("GET", f"/crm/organization/{client_id}")
        item = response.get("data", {})

        return Client(
            id=item.get("id", ""),
            name=item.get("name", ""),
            email=item.get("email"),
            phone=item.get("phone"),
            website=item.get("url"),
            industry=item.get("industry", {}).get("name") if item.get("industry") else None,
            is_active=item.get("is_active", True),
            created_at=item.get("created_at"),
            updated_at=item.get("updated_at")
        )

    async def search_clients(self, query: str) -> List[Client]:
        """
        Search clients by name with fuzzy matching.

        Args:
            query: Search query string

        Returns:
            List of matching clients with match confidence
        """
        # Simplicate uses q parameter for search
        params = {"q[name]": f"*{query}*"}
        response = await self._request("GET", "/crm/organization", params=params)
        data = response.get("data", [])

        # Calculate simple match confidence based on name similarity
        clients = []
        query_lower = query.lower()
        for item in data:
            name = item.get("name", "")
            # Simple confidence calculation
            if query_lower in name.lower():
                confidence = 1.0 if name.lower() == query_lower else 0.8
            else:
                confidence = 0.5

            clients.append(Client(
                id=item.get("id", ""),
                name=name,
                email=item.get("email"),
                phone=item.get("phone"),
                website=item.get("url"),
                match_confidence=confidence,
                is_active=item.get("is_active", True)
            ))

        # Sort by confidence
        return sorted(clients, key=lambda c: c.match_confidence or 0, reverse=True)

    # --- Project Methods ---

    async def get_projects(
        self,
        client_id: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[Project]:
        """
        Get projects, optionally filtered by client or status.

        Args:
            client_id: Filter by client ID
            status: Filter by status (active, completed, on_hold)
            limit: Maximum results
            offset: Pagination offset

        Returns:
            List of Project objects
        """
        params = {"limit": limit, "offset": offset}
        if client_id:
            params["q[organization.id]"] = client_id
        if status:
            params["q[project_status.label]"] = status

        response = await self._request("GET", "/projects/project", params=params)
        data = response.get("data", [])

        return [
            Project(
                id=item.get("id", ""),
                name=item.get("name", ""),
                client_id=item.get("organization", {}).get("id", ""),
                client_name=item.get("organization", {}).get("name"),
                status=self._map_status(item.get("project_status", {}).get("label")),
                description=item.get("note"),
                start_date=item.get("start_date"),
                end_date=item.get("end_date"),
                budget_hours=item.get("budget_hours"),
                hours_logged=item.get("hours_logged"),
                created_at=item.get("created_at"),
                updated_at=item.get("updated_at")
            )
            for item in data
        ]

    async def get_project(self, project_id: str) -> Project:
        """Get a single project by ID."""
        response = await self._request("GET", f"/projects/project/{project_id}")
        item = response.get("data", {})

        return Project(
            id=item.get("id", ""),
            name=item.get("name", ""),
            client_id=item.get("organization", {}).get("id", ""),
            client_name=item.get("organization", {}).get("name"),
            status=self._map_status(item.get("project_status", {}).get("label")),
            description=item.get("note"),
            start_date=item.get("start_date"),
            end_date=item.get("end_date"),
            budget_hours=item.get("budget_hours"),
            hours_logged=item.get("hours_logged"),
            created_at=item.get("created_at"),
            updated_at=item.get("updated_at")
        )

    async def create_project(self, project: ProjectCreate) -> Project:
        """Create a new project in Simplicate."""
        payload = {
            "name": project.name,
            "organization": {"id": project.client_id},
            "note": project.description,
            "start_date": project.start_date.isoformat() if project.start_date else None,
            "end_date": project.end_date.isoformat() if project.end_date else None,
            "budget_hours": project.budget_hours,
        }

        response = await self._request("POST", "/projects/project", json=payload)
        return await self.get_project(response.get("data", {}).get("id", ""))

    async def update_project(self, project_id: str, update: ProjectUpdate) -> Project:
        """Update an existing project."""
        payload = {}
        if update.name:
            payload["name"] = update.name
        if update.description:
            payload["note"] = update.description
        if update.end_date:
            payload["end_date"] = update.end_date.isoformat()
        if update.budget_hours:
            payload["budget_hours"] = update.budget_hours

        await self._request("PUT", f"/projects/project/{project_id}", json=payload)
        return await self.get_project(project_id)

    # --- Hours/Time Tracking Methods ---

    async def get_hours(
        self,
        project_id: Optional[str] = None,
        employee_id: Optional[str] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[HoursEntry]:
        """Get time entries with optional filters."""
        params = {"limit": limit, "offset": offset}
        if project_id:
            params["q[project.id]"] = project_id
        if employee_id:
            params["q[employee.id]"] = employee_id
        if start_date:
            params["q[start_date][ge]"] = start_date.isoformat()
        if end_date:
            params["q[start_date][le]"] = end_date.isoformat()

        response = await self._request("GET", "/hours/hours", params=params)
        data = response.get("data", [])

        return [
            HoursEntry(
                id=item.get("id", ""),
                project_id=item.get("project", {}).get("id", ""),
                project_name=item.get("project", {}).get("name"),
                employee_id=item.get("employee", {}).get("id", ""),
                employee_name=item.get("employee", {}).get("name"),
                hours=item.get("hours", 0),
                entry_date=item.get("start_date"),
                description=item.get("note"),
                billable=item.get("billable", True),
                created_at=item.get("created_at")
            )
            for item in data
        ]

    async def log_hours(self, entry: HoursEntryCreate) -> HoursEntry:
        """Log a new time entry."""
        payload = {
            "project": {"id": entry.project_id},
            "employee": {"id": entry.employee_id},
            "hours": entry.hours,
            "start_date": entry.entry_date.isoformat(),
            "note": entry.description,
            "billable": entry.billable
        }

        response = await self._request("POST", "/hours/hours", json=payload)
        entry_id = response.get("data", {}).get("id", "")

        # Fetch the created entry
        hours = await self.get_hours(limit=1)
        return hours[0] if hours else HoursEntry(
            id=entry_id,
            entry_date=entry.entry_date,
            description=entry.description,
            billable=entry.billable
        )

    # --- Employee/Capacity Methods ---

    async def get_employees(
        self,
        is_active: bool = True,
        limit: int = 100,
        offset: int = 0
    ) -> List[Employee]:
        """Get all employees."""
        params = {"limit": limit, "offset": offset}
        if is_active:
            params["q[is_active]"] = "true"

        response = await self._request("GET", "/hrm/employee", params=params)
        data = response.get("data", [])

        return [
            Employee(
                id=item.get("id", ""),
                name=item.get("name", ""),
                email=item.get("work_email"),
                role=item.get("function"),
                is_active=item.get("is_active", True),
                avatar_url=item.get("avatar")
            )
            for item in data
        ]

    async def check_capacity(
        self,
        start_date: str,
        end_date: str,
        roles: Optional[str] = None
    ) -> CapacityCheck:
        """
        Check team capacity for a date range.

        This aggregates hours data to calculate availability.
        """
        start = date.fromisoformat(start_date)
        end = date.fromisoformat(end_date)

        # Get all employees
        employees = await self.get_employees()

        # Get logged hours for the period
        hours = await self.get_hours(start_date=start, end_date=end, limit=1000)

        # Calculate capacity per employee
        hours_by_employee: Dict[str, float] = {}
        for entry in hours:
            hours_by_employee[entry.employee_id] = hours_by_employee.get(entry.employee_id, 0) + entry.hours

        # Calculate working days (simple: exclude weekends)
        from datetime import timedelta
        working_days = 0
        current = start
        while current <= end:
            if current.weekday() < 5:  # Monday = 0, Friday = 4
                working_days += 1
            current += timedelta(days=1)

        hours_per_day = 8.0
        total_available = working_days * hours_per_day

        # Build capacity info per employee
        employee_capacities = []
        total_available_all = 0
        total_booked_all = 0

        for emp in employees:
            booked = hours_by_employee.get(emp.id, 0)
            available = max(0, total_available - booked)
            utilization = (booked / total_available * 100) if total_available > 0 else 0

            # Determine status
            if utilization < 70:
                status = CapacityStatus.GREEN
            elif utilization < 90:
                status = CapacityStatus.YELLOW
            else:
                status = CapacityStatus.RED

            employee_capacities.append(EmployeeCapacity(
                employee_id=emp.id,
                employee_name=emp.name,
                role=emp.role,
                total_hours=total_available,
                booked_hours=booked,
                available_hours=available,
                utilization_pct=round(utilization, 1),
                status=status
            ))

            total_available_all += total_available
            total_booked_all += booked

        # Calculate overall status
        overall_utilization = (total_booked_all / total_available_all * 100) if total_available_all > 0 else 0
        if overall_utilization < 70:
            overall_status = CapacityStatus.GREEN
        elif overall_utilization < 90:
            overall_status = CapacityStatus.YELLOW
        else:
            overall_status = CapacityStatus.RED

        # Suggest available team members
        suggested = [
            ec.employee_name for ec in employee_capacities
            if ec.status == CapacityStatus.GREEN
        ][:5]

        return CapacityCheck(
            start_date=start,
            end_date=end,
            employees=employee_capacities,
            overall_status=overall_status,
            total_available_hours=total_available_all,
            total_booked_hours=total_booked_all,
            suggested_team=suggested
        )

    def _map_status(self, status_label: Optional[str]) -> str:
        """Map Simplicate status label to our enum."""
        if not status_label:
            return "draft"
        mapping = {
            "active": "active",
            "actief": "active",
            "completed": "completed",
            "afgerond": "completed",
            "on_hold": "on_hold",
            "on hold": "on_hold",
            "gepauzeerd": "on_hold",
        }
        return mapping.get(status_label.lower(), "draft")

    async def close(self):
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None
