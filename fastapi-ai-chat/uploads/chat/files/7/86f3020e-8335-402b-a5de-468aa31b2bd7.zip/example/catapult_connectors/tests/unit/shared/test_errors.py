import pytest
from connectors.shared.errors import (
    ConnectorError,
    ErrorResponse,
    UnauthorizedError,
    ForbiddenError,
    NotFoundError,
    TooManyRequestsError,
    ServiceUnavailableError,
    InternalServerError,
    NetworkError,
    AuthenticationError,
    ConfigurationError,
    SimplicateError,
    TrelloError,
    GraphError,
    handle_http_error
)

def test_connector_error_to_response():
    """Test converting ConnectorError to ErrorResponse."""
    err = ConnectorError(
        status_code=400,
        error="TEST_ERROR",
        message="Test message",
        details={"foo": "bar"},
        connector="test_connector"
    )
    
    response = err.to_response()
    
    assert isinstance(response, ErrorResponse)
    assert response.error == "TEST_ERROR"
    assert response.message == "Test message"
    assert response.details == {"foo": "bar"}
    assert response.connector == "test_connector"

def test_handle_http_error_standard_codes():
    """Test mapping standard HTTP codes to exceptions."""
    cases = [
        (401, UnauthorizedError, 401),
        (403, ForbiddenError, 403),
        (404, NotFoundError, 404),
        (429, TooManyRequestsError, 429),
        (503, ServiceUnavailableError, 503),
        (500, InternalServerError, 500),
        (502, InternalServerError, 500), # 502 maps to InternalServerError which defaults to 500
    ]
    
    for status, exc_class, expected_status in cases:
        error = handle_http_error(status, "Error body", "test")
        assert isinstance(error, exc_class)
        assert error.status_code == expected_status
        assert "Error body" in error.message

def test_handle_http_error_connector_specific():
    """Test mapping errors to connector-specific exceptions for unknown status codes."""
    # Simplicate
    err = handle_http_error(418, "Tea", "simplicate")
    assert isinstance(err, SimplicateError)
    assert err.error == "SIMPLICATE_ERROR"
    
    # Trello
    err = handle_http_error(418, "Tea", "trello")
    assert isinstance(err, TrelloError)
    assert err.error == "TRELLO_ERROR"
    
    # Graph
    err = handle_http_error(418, "Tea", "graph")
    assert isinstance(err, GraphError)
    assert err.error == "GRAPH_ERROR"

def test_handle_http_error_generic_fallback():
    """Test fallback to generic ConnectorError."""
    err = handle_http_error(418, "Tea", "unknown_connector")
    assert type(err) == ConnectorError
    assert err.error == "UNKNOWN_CONNECTOR_ERROR"

def test_specific_error_classes():
    """Test instantiation of specific error classes."""
    auth_err = AuthenticationError("test", "Auth failed")
    assert auth_err.status_code == 401
    assert auth_err.error == "AUTHENTICATION_FAILED"
    
    config_err = ConfigurationError("test", "Bad config")
    assert config_err.status_code == 500
    assert config_err.error == "CONFIGURATION_ERROR"
    
    net_err = NetworkError("Connection failed")
    assert net_err.status_code == 502
    assert net_err.error == "NETWORK_ERROR"