"""
FastAPI router for Outlook Mail connector endpoints.

Uses Microsoft Graph API with On-Behalf-Of (OBO) authentication,
allowing per-user access to mail via Copilot Studio.
"""
from fastapi import APIRouter, Query, Path, Body, Depends
from typing import Optional, List

from .client import GraphClient
from .models import (
    Message, MessageCreate, MessageUpdate, MailFolder,
    DraftCreate, DraftUpdate, MoveMessageRequest, FolderCreate, FolderUpdate
)
from ..shared.dependencies import validate_token, UserContext

router = APIRouter()


def get_client(user: UserContext = Depends(validate_token)) -> GraphClient:
    """
    Get Graph client with user's token for OBO flow.

    The user's token from Copilot Studio is exchanged for a Graph token
    via the On-Behalf-Of flow, allowing access to the user's own mailbox.
    """
    return GraphClient(user_token=user.token)


# ==================== INBOX OPERATIONS ====================

@router.get(
    "/inbox",
    response_model=List[Message],
    operation_id="mail_get_inbox",
    summary="List inbox messages",
    description="Get messages from your inbox. Returns most recent messages first with preview, sender, and read status."
)
async def get_inbox(
    top: int = Query(25, ge=1, le=100, description="Number of messages to return"),
    skip: int = Query(0, ge=0, description="Number of messages to skip"),
    filter: Optional[str] = Query(None, description="OData filter (e.g., 'isRead eq false')"),
    user: UserContext = Depends(validate_token)
) -> List[Message]:
    """Get inbox messages for the authenticated user."""
    client = GraphClient(user_token=user.token)
    try:
        # Use 'me' endpoint for OBO - accesses the authenticated user's mailbox
        return await client.get_inbox("me", top=top, skip=skip, filter=filter)
    finally:
        await client.close()


@router.get(
    "/messages/{message_id}",
    response_model=Message,
    operation_id="mail_get_message",
    summary="Get message by ID",
    description="Retrieve a specific email message by its unique ID."
)
async def get_message(
    message_id: str = Path(..., description="Message ID"),
    user: UserContext = Depends(validate_token)
) -> Message:
    """Get a specific message."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.get_message("me", message_id)
    finally:
        await client.close()


@router.post(
    "/send",
    operation_id="mail_send",
    summary="Send email",
    description="Send an email from your mailbox. Supports HTML content, CC/BCC, and importance levels."
)
async def send_mail(
    message: MessageCreate = Body(..., description="Email message to send"),
    user: UserContext = Depends(validate_token)
) -> dict:
    """Send an email as the authenticated user."""
    client = GraphClient(user_token=user.token)
    try:
        await client.send_mail("me", message)
        return {"success": True, "message": "Email sent successfully"}
    finally:
        await client.close()


@router.post(
    "/messages/{message_id}/forward",
    operation_id="mail_forward",
    summary="Forward message",
    description="Forward an email message to other recipients with optional comment."
)
async def forward_message(
    message_id: str = Path(..., description="Message ID to forward"),
    to_recipients: List[str] = Body(..., description="Email addresses to forward to"),
    comment: Optional[str] = Body(None, description="Optional comment to include"),
    user: UserContext = Depends(validate_token)
) -> dict:
    """Forward a message."""
    client = GraphClient(user_token=user.token)
    try:
        await client.forward_message("me", message_id, to_recipients, comment)
        return {"success": True, "message": "Message forwarded"}
    finally:
        await client.close()


@router.patch(
    "/messages/{message_id}",
    response_model=Message,
    operation_id="mail_update",
    summary="Update message",
    description="Update message properties like read status or categories."
)
async def update_message(
    message_id: str = Path(..., description="Message ID to update"),
    update: MessageUpdate = Body(..., description="Properties to update"),
    user: UserContext = Depends(validate_token)
) -> Message:
    """Update a message."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.update_message("me", message_id, update)
    finally:
        await client.close()


@router.get(
    "/folders",
    response_model=List[MailFolder],
    operation_id="mail_get_folders",
    summary="List mail folders",
    description="Get all your mail folders including item counts."
)
async def get_folders(
    user: UserContext = Depends(validate_token)
) -> List[MailFolder]:
    """Get mail folders."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.get_mail_folders("me")
    finally:
        await client.close()


# ==================== DRAFT OPERATIONS ====================

@router.get(
    "/drafts",
    response_model=List[Message],
    operation_id="mail_get_drafts",
    summary="List draft emails",
    description="Get draft messages from your Drafts folder. Returns most recent drafts first."
)
async def get_drafts(
    top: int = Query(25, ge=1, le=100, description="Number of drafts to return"),
    skip: int = Query(0, ge=0, description="Number of drafts to skip"),
    user: UserContext = Depends(validate_token)
) -> List[Message]:
    """Get draft emails."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.get_drafts("me", top=top, skip=skip)
    finally:
        await client.close()


@router.post(
    "/drafts",
    response_model=Message,
    operation_id="mail_create_draft",
    summary="Create draft email",
    description="Create a draft email that can be edited and sent later. The draft is saved in the Drafts folder."
)
async def create_draft(
    draft: DraftCreate = Body(..., description="Draft email content"),
    user: UserContext = Depends(validate_token)
) -> Message:
    """Create a draft email."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.create_draft("me", draft)
    finally:
        await client.close()


@router.patch(
    "/drafts/{draft_id}",
    response_model=Message,
    operation_id="mail_update_draft",
    summary="Update draft email",
    description="Update a draft email's subject, body, recipients, or other properties."
)
async def update_draft(
    draft_id: str = Path(..., description="Draft message ID"),
    update: DraftUpdate = Body(..., description="Properties to update"),
    user: UserContext = Depends(validate_token)
) -> Message:
    """Update a draft email."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.update_draft("me", draft_id, update)
    finally:
        await client.close()


@router.post(
    "/drafts/{draft_id}/send",
    operation_id="mail_send_draft",
    summary="Send draft email",
    description="Send a draft email. The draft is moved to Sent Items after sending."
)
async def send_draft(
    draft_id: str = Path(..., description="Draft message ID to send"),
    user: UserContext = Depends(validate_token)
) -> dict:
    """Send a draft email."""
    client = GraphClient(user_token=user.token)
    try:
        await client.send_draft("me", draft_id)
        return {"success": True, "message": "Draft sent successfully"}
    finally:
        await client.close()


# ==================== FOLDER MANAGEMENT ====================

@router.post(
    "/folders",
    response_model=MailFolder,
    operation_id="mail_create_folder",
    summary="Create mail folder",
    description="Create a new mail folder. Optionally specify a parent folder ID to create a nested folder."
)
async def create_folder(
    folder: FolderCreate = Body(..., description="Folder creation details"),
    user: UserContext = Depends(validate_token)
) -> MailFolder:
    """Create a mail folder."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.create_mail_folder("me", folder)
    finally:
        await client.close()


@router.patch(
    "/folders/{folder_id}",
    response_model=MailFolder,
    operation_id="mail_update_folder",
    summary="Rename mail folder",
    description="Update a mail folder's display name."
)
async def update_folder(
    folder_id: str = Path(..., description="Folder ID to update"),
    update: FolderUpdate = Body(..., description="New folder properties"),
    user: UserContext = Depends(validate_token)
) -> MailFolder:
    """Update/rename a mail folder."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.update_mail_folder("me", folder_id, update)
    finally:
        await client.close()


@router.delete(
    "/folders/{folder_id}",
    operation_id="mail_delete_folder",
    summary="Delete mail folder",
    description="Delete a mail folder and all its contents. This action cannot be undone."
)
async def delete_folder(
    folder_id: str = Path(..., description="Folder ID to delete"),
    user: UserContext = Depends(validate_token)
) -> dict:
    """Delete a mail folder."""
    client = GraphClient(user_token=user.token)
    try:
        await client.delete_mail_folder("me", folder_id)
        return {"success": True, "message": "Folder deleted"}
    finally:
        await client.close()


@router.get(
    "/folders/{folder_id}/children",
    response_model=List[MailFolder],
    operation_id="mail_get_child_folders",
    summary="List child folders",
    description="Get all child folders of a specific mail folder (nested folders)."
)
async def get_child_folders(
    folder_id: str = Path(..., description="Parent folder ID"),
    user: UserContext = Depends(validate_token)
) -> List[MailFolder]:
    """Get child folders."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.get_child_folders("me", folder_id)
    finally:
        await client.close()


@router.post(
    "/messages/{message_id}/move",
    response_model=Message,
    operation_id="mail_move_message",
    summary="Move message to folder",
    description="Move an email message to a different folder."
)
async def move_message(
    message_id: str = Path(..., description="Message ID to move"),
    request: MoveMessageRequest = Body(..., description="Destination folder"),
    user: UserContext = Depends(validate_token)
) -> Message:
    """Move a message to another folder."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.move_message("me", message_id, request.destination_folder_id)
    finally:
        await client.close()
