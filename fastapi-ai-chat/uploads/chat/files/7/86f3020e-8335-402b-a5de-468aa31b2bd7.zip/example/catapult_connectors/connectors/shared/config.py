"""
Configuration management for Catapult Connectors.
Loads settings from environment variables.
"""
import os
from functools import lru_cache
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Simplicate CRM
    simplicate_subdomain: str = ""
    simplicate_api_key: str = ""
    simplicate_api_secret: str = ""

    # Trello
    trello_api_key: str = ""
    trello_api_token: str = ""

    # Azure AD / Microsoft Graph - API App Registration (for OBO flow)
    azure_tenant_id: str = ""
    azure_client_id: str = ""  # API app client ID
    azure_client_secret: str = ""  # API app client secret

    # Azure AD - API Audience (for token validation)
    # Format: api://<client-id> or the Application ID URI
    azure_api_audience: str = ""

    # Azure AD - Allowed issuers (comma-separated for multi-tenant)
    # Leave empty for single-tenant (auto-constructed from tenant_id)
    azure_allowed_issuers: str = ""

    # SharePoint specific
    sharepoint_site_id: Optional[str] = None
    sharepoint_drive_id: Optional[str] = None

    # Application
    environment: str = "development"
    log_level: str = "INFO"

    # Authentication mode: "obo" for per-user, "app" for app-only (legacy)
    auth_mode: str = "obo"

    # Retry Settings
    default_max_retries: int = 3
    default_retry_delay: float = 1.0  # seconds
    default_retry_backoff: float = 2.0
    default_retry_jitter: float = 0.1

    # Token cache settings
    token_cache_ttl: int = 3300  # 55 minutes (tokens valid for 60 min)

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False

    @property
    def api_audience(self) -> str:
        """Get the API audience for token validation."""
        if self.azure_api_audience:
            return self.azure_api_audience
        # Default to api://<client-id> format
        if self.azure_client_id:
            return f"api://{self.azure_client_id}"
        return ""

    @property
    def token_issuers(self) -> list[str]:
        """Get list of allowed token issuers."""
        if self.azure_allowed_issuers:
            return [i.strip() for i in self.azure_allowed_issuers.split(",")]
        # Single-tenant default issuers
        if self.azure_tenant_id:
            return [
                f"https://sts.windows.net/{self.azure_tenant_id}/",
                f"https://login.microsoftonline.com/{self.azure_tenant_id}/v2.0"
            ]
        return []

    @property
    def is_obo_configured(self) -> bool:
        """Check if OBO authentication is properly configured."""
        return all([
            self.azure_tenant_id,
            self.azure_client_id,
            self.azure_client_secret,
            self.api_audience
        ])


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()
