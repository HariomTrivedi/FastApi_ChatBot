"""
Pydantic models for Microsoft Graph API data structures.
Covers Mail, Calendar, and SharePoint/OneDrive resources.
"""
from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field
from enum import Enum


# --- Common Models ---

class EmailAddress(BaseModel):
    """Email address with optional name."""
    address: str = Field(..., description="Email address")
    name: Optional[str] = Field(None, description="Display name")


class Recipient(BaseModel):
    """Email recipient."""
    email_address: EmailAddress = Field(..., alias="emailAddress")

    class Config:
        populate_by_name = True


# --- Mail Models ---

class MessageImportance(str, Enum):
    """Email importance levels."""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"


class MessageBase(BaseModel):
    """Base model for email message."""
    subject: str = Field(..., description="Email subject")
    body_content: str = Field(..., description="Email body content (HTML or text)")
    body_content_type: str = Field("HTML", description="Body type: HTML or Text")


class MessageCreate(MessageBase):
    """Model for creating/sending an email."""
    to_recipients: List[str] = Field(..., description="List of recipient email addresses")
    cc_recipients: Optional[List[str]] = Field(None, description="CC recipients")
    bcc_recipients: Optional[List[str]] = Field(None, description="BCC recipients")
    importance: MessageImportance = Field(MessageImportance.NORMAL, description="Message importance")
    save_to_sent_items: bool = Field(True, description="Save to Sent Items folder")


class Message(BaseModel):
    """Full email message model."""
    id: str = Field(..., description="Unique message identifier")
    subject: Optional[str] = Field(None, description="Email subject")
    body_preview: Optional[str] = Field(None, description="First 255 characters of body")
    from_address: Optional[EmailAddress] = Field(None, description="Sender email address")
    to_recipients: Optional[List[EmailAddress]] = Field(None, description="To recipients")
    received_datetime: Optional[datetime] = Field(None, description="When message was received")
    sent_datetime: Optional[datetime] = Field(None, description="When message was sent")
    is_read: bool = Field(False, description="Whether message has been read")
    importance: Optional[str] = Field(None, description="Message importance")
    has_attachments: bool = Field(False, description="Whether message has attachments")
    categories: Optional[List[str]] = Field(None, description="Applied categories")
    web_link: Optional[str] = Field(None, description="URL to open in Outlook")

    class Config:
        from_attributes = True


class MessageUpdate(BaseModel):
    """Model for updating a message."""
    is_read: Optional[bool] = Field(None, description="Mark as read/unread")
    categories: Optional[List[str]] = Field(None, description="Set categories")


class DraftCreate(BaseModel):
    """Model for creating a draft email."""
    subject: str = Field(..., description="Email subject")
    body_content: str = Field(..., description="Email body content (HTML or text)")
    body_content_type: str = Field("HTML", description="Body type: HTML or Text")
    to_recipients: List[str] = Field(..., description="List of recipient email addresses")
    cc_recipients: Optional[List[str]] = Field(None, description="CC recipients")
    importance: MessageImportance = Field(MessageImportance.NORMAL, description="Message importance")


class DraftUpdate(BaseModel):
    """Model for updating a draft email."""
    subject: Optional[str] = Field(None, description="Updated subject")
    body_content: Optional[str] = Field(None, description="Updated body content")
    body_content_type: Optional[str] = Field(None, description="Body type: HTML or Text")
    to_recipients: Optional[List[str]] = Field(None, description="Updated recipients")
    cc_recipients: Optional[List[str]] = Field(None, description="Updated CC recipients")


class MoveMessageRequest(BaseModel):
    """Request to move a message to another folder."""
    destination_folder_id: str = Field(..., description="Target folder ID")


class FolderCreate(BaseModel):
    """Model for creating a mail folder."""
    display_name: str = Field(..., description="Folder display name")
    parent_folder_id: Optional[str] = Field(None, description="Parent folder ID (None for root level)")


class FolderUpdate(BaseModel):
    """Model for updating/renaming a mail folder."""
    display_name: str = Field(..., description="New folder display name")


class MailFolder(BaseModel):
    """Mail folder model."""
    id: str
    display_name: str
    parent_folder_id: Optional[str] = None
    total_item_count: int = 0
    unread_item_count: int = 0
    child_folder_count: int = 0


# --- Calendar Models ---

class EventType(str, Enum):
    """Calendar event types."""
    SINGLE_INSTANCE = "singleInstance"
    OCCURRENCE = "occurrence"
    EXCEPTION = "exception"
    SERIES_MASTER = "seriesMaster"


class ShowAs(str, Enum):
    """Free/busy status."""
    FREE = "free"
    TENTATIVE = "tentative"
    BUSY = "busy"
    OOF = "oof"
    WORKING_ELSEWHERE = "workingElsewhere"
    UNKNOWN = "unknown"


class DateTimeTimeZone(BaseModel):
    """DateTime with timezone."""
    date_time: str = Field(..., description="ISO 8601 datetime")
    time_zone: str = Field("UTC", description="Timezone identifier")


class EventBase(BaseModel):
    """Base model for calendar event."""
    subject: str = Field(..., description="Event subject/title")
    body_content: Optional[str] = Field(None, description="Event body/description")
    start: DateTimeTimeZone = Field(..., description="Start date and time")
    end: DateTimeTimeZone = Field(..., description="End date and time")
    location: Optional[str] = Field(None, description="Event location")
    is_all_day: bool = Field(False, description="All-day event")


class EventCreate(EventBase):
    """Model for creating a calendar event."""
    attendees: Optional[List[str]] = Field(None, description="Attendee email addresses")
    is_online_meeting: bool = Field(False, description="Create Teams meeting")
    show_as: ShowAs = Field(ShowAs.BUSY, description="Free/busy status")
    reminder_minutes: Optional[int] = Field(15, description="Reminder minutes before")


class Event(EventBase):
    """Full calendar event model."""
    id: str = Field(..., description="Unique event identifier")
    web_link: Optional[str] = Field(None, description="URL to open in Outlook")
    organizer: Optional[EmailAddress] = Field(None, description="Event organizer")
    attendees: Optional[List[dict]] = Field(None, description="Event attendees")
    show_as: Optional[str] = Field(None, description="Free/busy status")
    is_cancelled: bool = Field(False, description="Whether event is cancelled")
    is_online_meeting: bool = Field(False, description="Whether it's a Teams meeting")
    online_meeting_url: Optional[str] = Field(None, description="Teams meeting URL")
    created_datetime: Optional[datetime] = Field(None, description="When event was created")
    last_modified_datetime: Optional[datetime] = Field(None, description="Last modification")

    class Config:
        from_attributes = True


class EventUpdate(BaseModel):
    """Model for updating an event."""
    subject: Optional[str] = None
    body_content: Optional[str] = None
    start: Optional[DateTimeTimeZone] = None
    end: Optional[DateTimeTimeZone] = None
    location: Optional[str] = None
    is_cancelled: Optional[bool] = None


class ScheduleItem(BaseModel):
    """Free/busy schedule item."""
    status: str
    subject: Optional[str] = None
    location: Optional[str] = None
    start: Optional[DateTimeTimeZone] = None
    end: Optional[DateTimeTimeZone] = None


class AvailabilityResult(BaseModel):
    """Availability check result for a user."""
    schedule_id: str = Field(..., description="Email of the user")
    availability_view: str = Field(..., description="Encoded availability string")
    schedule_items: List[ScheduleItem] = Field(default_factory=list)
    working_hours: Optional[dict] = None


# --- SharePoint/OneDrive Models ---

class DriveItemType(str, Enum):
    """Drive item types."""
    FILE = "file"
    FOLDER = "folder"


class DriveItem(BaseModel):
    """SharePoint/OneDrive file or folder."""
    id: str = Field(..., description="Unique item identifier")
    name: str = Field(..., description="File or folder name")
    item_type: DriveItemType = Field(..., description="file or folder")
    size: Optional[int] = Field(None, description="Size in bytes (files only)")
    mime_type: Optional[str] = Field(None, description="MIME type (files only)")
    web_url: Optional[str] = Field(None, description="URL to open in browser")
    created_datetime: Optional[datetime] = Field(None, description="Creation time")
    last_modified_datetime: Optional[datetime] = Field(None, description="Last modified")
    created_by: Optional[str] = Field(None, description="Creator display name")
    last_modified_by: Optional[str] = Field(None, description="Last modifier name")
    parent_path: Optional[str] = Field(None, description="Parent folder path")

    class Config:
        from_attributes = True


class Drive(BaseModel):
    """SharePoint document library or OneDrive."""
    id: str = Field(..., description="Unique drive identifier")
    name: str = Field(..., description="Drive/library name")
    drive_type: str = Field(..., description="personal, business, or documentLibrary")
    web_url: Optional[str] = Field(None, description="URL to open in browser")
    quota_used: Optional[int] = Field(None, description="Used space in bytes")
    quota_total: Optional[int] = Field(None, description="Total space in bytes")


class Site(BaseModel):
    """SharePoint site."""
    id: str = Field(..., description="Unique site identifier")
    name: str = Field(..., description="Site name")
    display_name: Optional[str] = Field(None, description="Display name")
    web_url: str = Field(..., description="Site URL")
    created_datetime: Optional[datetime] = Field(None, description="Creation time")


class FileUpload(BaseModel):
    """File upload request."""
    folder_path: str = Field(..., description="Target folder path")
    file_name: str = Field(..., description="Name for the uploaded file")
    content_type: Optional[str] = Field(None, description="MIME type")


class FolderCreate(BaseModel):
    """Folder creation request."""
    parent_path: str = Field(..., description="Parent folder path")
    folder_name: str = Field(..., description="New folder name")


class SearchResult(BaseModel):
    """Search result item."""
    id: str
    name: str
    item_type: DriveItemType
    web_url: str
    parent_path: Optional[str] = None
    snippet: Optional[str] = None
