# Catapult Connectors - Complete Deployment Guide

This guide walks you through deploying the Catapult Connectors API to Azure Container Apps with per-user authentication via Microsoft Copilot Studio.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Architecture Overview](#architecture-overview)
3. [Step 1: Azure AD App Registrations](#step-1-azure-ad-app-registrations)
4. [Step 2: Deploy Azure Container Apps](#step-2-deploy-azure-container-apps)
5. [Step 3: Configure Environment Variables](#step-3-configure-environment-variables)
6. [Step 4: Generate OpenAPI Specification](#step-4-generate-openapi-specification)
7. [Step 5: Create Custom Connector](#step-5-create-custom-connector)
8. [Step 6: Configure Copilot Studio Agent](#step-6-configure-copilot-studio-agent)
9. [Step 7: Test End-to-End](#step-7-test-end-to-end)
10. [Troubleshooting](#troubleshooting)

---

## Prerequisites

Before starting, ensure you have:

- [ ] Azure subscription with permissions to create resources
- [ ] Azure CLI installed (`az --version`)
- [ ] Docker installed (for local testing)
- [ ] Power Platform environment with Copilot Studio access
- [ ] Global Admin or Application Administrator role in Azure AD

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              AUTHENTICATION FLOW                             │
└─────────────────────────────────────────────────────────────────────────────┘

    ┌──────────────┐     ┌──────────────────┐     ┌─────────────────┐
    │    User      │     │  Copilot Studio  │     │  Azure AD       │
    │  (Teams/M365)│     │  Custom Connector│     │                 │
    └──────┬───────┘     └────────┬─────────┘     └────────┬────────┘
           │                      │                        │
           │ 1. Interact          │                        │
           │────────────────────> │                        │
           │                      │ 2. Redirect to login   │
           │ <─────────────────── │ ────────────────────>  │
           │                      │                        │
           │ 3. User authenticates│                        │
           │ ─────────────────────│───────────────────────>│
           │                      │                        │
           │                      │ 4. Return access token │
           │                      │ <──────────────────────│
           │                      │                        │
           │                      │         ┌──────────────────────┐
           │                      │         │  Catapult Connectors │
           │                      │         │  (Container App)     │
           │                      │         └──────────┬───────────┘
           │                      │                    │
           │                      │ 5. Call API with   │
           │                      │    Bearer token    │
           │                      │ ──────────────────>│
           │                      │                    │
           │                      │                    │ 6. Validate token
           │                      │                    │ 7. OBO exchange
           │                      │                    │    for Graph token
           │                      │                    │
           │                      │                    │     ┌─────────────┐
           │                      │                    │     │  Microsoft  │
           │                      │                    │ ───>│  Graph API  │
           │                      │                    │ <───│             │
           │                      │                    │     └─────────────┘
           │                      │                    │
           │                      │ 8. Return user data│
           │                      │ <──────────────────│
           │                      │                    │
           │ 9. Display results   │                    │
           │ <────────────────────│                    │
           │                      │                    │
```

---

## Step 1: Azure AD App Registrations

You need to create **two** app registrations in Azure AD.

### 1.1 Create the API App Registration

This app represents your Catapult Connectors API.

1. Go to [Azure Portal](https://portal.azure.com) > **Microsoft Entra ID** > **App registrations**

2. Click **New registration**
   - **Name**: `Catapult Connectors API`
   - **Supported account types**: `Accounts in this organizational directory only`
   - **Redirect URI**: Leave empty for now
   - Click **Register**

3. **Note these values** (you'll need them later):
   ```
   Application (client) ID: ________________________________
   Directory (tenant) ID:   ________________________________
   ```

4. Go to **Certificates & secrets** > **New client secret**
   - **Description**: `API Secret`
   - **Expires**: Select appropriate duration
   - Click **Add**
   - **Copy the secret value immediately** (it won't be shown again):
   ```
   Client Secret: ________________________________
   ```

5. Go to **API permissions** > **Add a permission** > **Microsoft Graph** > **Delegated permissions**

   Add these permissions:
   - [x] `Mail.Read`
   - [x] `Mail.Send`
   - [x] `Calendars.ReadWrite`
   - [x] `Files.Read.All`
   - [x] `Sites.Read.All`
   - [x] `User.Read`

   Click **Add permissions**

6. Click **Grant admin consent for [Your Organization]** > **Yes**

7. Go to **Expose an API**

   a. Click **Add** next to Application ID URI
      - Accept the default: `api://<client-id>`
      - Click **Save**

   b. Click **Add a scope**
      - **Scope name**: `access_as_user`
      - **Who can consent**: `Admins and users`
      - **Admin consent display name**: `Access Catapult Connectors API`
      - **Admin consent description**: `Allow the application to access Catapult Connectors on behalf of the signed-in user`
      - **User consent display name**: `Access Catapult Connectors`
      - **User consent description**: `Allow access to your mail, calendar, and files`
      - **State**: `Enabled`
      - Click **Add scope**

   c. Click **Add a client application** (under Authorized client applications)
      - **Client ID**: `fe053c5f-3692-4f14-aef2-ee34fc081cae` (Azure API Connections service principal)
      - Check the scope you just created
      - Click **Add application**

### 1.2 Create the Connector App Registration

This app is used by the custom connector to authenticate users.

1. Go to **App registrations** > **New registration**
   - **Name**: `Catapult Connectors - Copilot Studio`
   - **Supported account types**: `Accounts in this organizational directory only`
   - **Redirect URI**: Leave empty (will be added later)
   - Click **Register**

2. **Note these values**:
   ```
   Connector Client ID: ________________________________
   ```

3. Go to **Certificates & secrets** > **New client secret**
   - **Description**: `Connector Secret`
   - Click **Add**
   - **Copy the secret value**:
   ```
   Connector Client Secret: ________________________________
   ```

4. Go to **API permissions** > **Add a permission**

   a. Select **My APIs** > **Catapult Connectors API**
      - Select `access_as_user`
      - Click **Add permissions**

   b. Add Microsoft Graph delegated permissions (same as API app):
      - `Mail.Read`, `Mail.Send`, `Calendars.ReadWrite`, `Files.Read.All`, `Sites.Read.All`, `User.Read`

5. Click **Grant admin consent for [Your Organization]** > **Yes**

---

## Step 2: Deploy Azure Container Apps

### 2.1 Create Azure Resources

```bash
# Login to Azure
az login

# Set variables (customize these)
RESOURCE_GROUP="rg-catapult"
LOCATION="westeurope"
ENVIRONMENT="catapult-env"
CONTAINER_APP_NAME="catapult-connectors"
ACR_NAME="catapultacr"  # Must be globally unique

# Create resource group
az group create --name $RESOURCE_GROUP --location $LOCATION

# Create Container Registry
az acr create \
  --resource-group $RESOURCE_GROUP \
  --name $ACR_NAME \
  --sku Basic \
  --admin-enabled true

# Get ACR credentials
ACR_PASSWORD=$(az acr credential show --name $ACR_NAME --query "passwords[0].value" -o tsv)

# Create Container Apps environment
az containerapp env create \
  --name $ENVIRONMENT \
  --resource-group $RESOURCE_GROUP \
  --location $LOCATION
```

### 2.2 Build and Push Container Image

```bash
# Navigate to project directory
cd catapult_connectors

# Build and push to ACR
az acr build \
  --registry $ACR_NAME \
  --image catapult-connectors:latest \
  --file Dockerfile .
```

### 2.3 Deploy Container App

```bash
# Create Container App
az containerapp create \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --environment $ENVIRONMENT \
  --image $ACR_NAME.azurecr.io/catapult-connectors:latest \
  --target-port 8000 \
  --ingress external \
  --registry-server $ACR_NAME.azurecr.io \
  --registry-username $ACR_NAME \
  --registry-password $ACR_PASSWORD \
  --min-replicas 1 \
  --max-replicas 10

# Get the Container App URL
CONTAINER_APP_URL=$(az containerapp show \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "properties.configuration.ingress.fqdn" -o tsv)

echo "Container App URL: https://$CONTAINER_APP_URL"
```

---

## Step 3: Configure Environment Variables

Set the required environment variables for the Container App:

```bash
# Replace with your actual values from Step 1
AZURE_TENANT_ID="<your-tenant-id>"
AZURE_CLIENT_ID="<api-app-client-id>"
AZURE_CLIENT_SECRET="<api-app-client-secret>"
AZURE_API_AUDIENCE="api://<api-app-client-id>"

# Configure the Container App
az containerapp update \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --set-env-vars \
    AZURE_TENANT_ID="$AZURE_TENANT_ID" \
    AZURE_CLIENT_ID="$AZURE_CLIENT_ID" \
    AZURE_CLIENT_SECRET="secretref:azure-client-secret" \
    AZURE_API_AUDIENCE="$AZURE_API_AUDIENCE" \
    LOG_LEVEL="info" \
    ENVIRONMENT="production"

# Set secrets separately
az containerapp secret set \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --secrets azure-client-secret="$AZURE_CLIENT_SECRET"
```

### Environment Variables Reference

| Variable | Description | Example |
|----------|-------------|---------|
| `AZURE_TENANT_ID` | Your Azure AD tenant ID | `12345678-1234-...` |
| `AZURE_CLIENT_ID` | API App registration client ID | `abcdefgh-1234-...` |
| `AZURE_CLIENT_SECRET` | API App registration client secret | `xxx~yyy~zzz` |
| `AZURE_API_AUDIENCE` | API audience for token validation | `api://abcdefgh-1234-...` |
| `LOG_LEVEL` | Logging level | `info` or `debug` |
| `ENVIRONMENT` | Environment name | `production` |

---

## Step 4: Generate OpenAPI Specification

Generate the Swagger 2.0 specification for the custom connector:

```bash
# Install dependencies locally (optional, for generation)
pip install -r requirements.txt

# Generate Swagger spec with your API client ID
python openapi/generate_swagger.py \
  --host $CONTAINER_APP_URL \
  --api-client-id $AZURE_CLIENT_ID \
  --output openapi/swagger.json
```

The generated `swagger.json` will include:
- OAuth 2.0 security scheme configured for Azure AD
- All API endpoints with proper authentication requirements
- Scope: `api://<client-id>/access_as_user`

---

## Step 5: Create Custom Connector

### 5.1 Import the Connector

1. Go to [Power Apps](https://make.powerapps.com) or [Power Automate](https://make.powerautomate.com)

2. Select your environment (must have Copilot Studio access)

3. Go to **More** > **Discover all** > **Custom connectors**

4. Click **+ New custom connector** > **Import an OpenAPI file**
   - **Connector name**: `Catapult Connectors`
   - **Import**: Select your `swagger.json` file
   - Click **Continue**

### 5.2 Configure General Settings

1. On the **General** tab:
   - **Icon background color**: `#0078D4` (or your preferred color)
   - **Description**: `API for Microsoft 365 integrations via Copilot Studio`
   - **Host**: Should be auto-populated from the swagger file

### 5.3 Configure Security (CRITICAL)

1. On the **Security** tab:
   - **Authentication type**: `OAuth 2.0`
   - **Identity Provider**: `Azure Active Directory`
   - **Client ID**: `<Connector App Client ID from Step 1.2>`
   - **Client Secret**: `<Connector App Client Secret from Step 1.2>`
   - **Resource URL**: `api://<API App Client ID from Step 1.1>`
   - **Scope**: `api://<API App Client ID>/access_as_user`
   - **Enable on-behalf-of login**: **Yes** (IMPORTANT!)

2. Click **Create connector**

3. **Copy the Redirect URL** that appears (e.g., `https://global.consent.azure-apim.net/redirect/...`)

### 5.4 Add Redirect URL to Connector App

1. Go back to [Azure Portal](https://portal.azure.com) > **App registrations**

2. Select **Catapult Connectors - Copilot Studio** (the connector app)

3. Go to **Authentication** > **Add a platform** > **Web**
   - **Redirect URIs**: Paste the redirect URL from Step 5.3
   - Click **Configure**

### 5.5 Test the Connector

1. Go back to your custom connector in Power Apps

2. Click **Test** tab

3. Click **+ New connection**

4. Sign in with your Microsoft 365 account

5. Grant permissions when prompted

6. Test an operation (e.g., `mail_get_inbox`)

---

## Step 6: Configure Copilot Studio Agent

### 6.1 Add Connector to Agent

1. Go to [Copilot Studio](https://copilotstudio.microsoft.com)

2. Select your agent (or create a new one)

3. Go to **Tools** > **Add a tool** > **Connector**

4. Search for **Catapult Connectors**

5. Select the actions you want to enable:
   - `mail_get_inbox` - List inbox messages
   - `mail_send` - Send email
   - `calendar_get_events` - List calendar events
   - `calendar_create_event` - Create events
   - etc.

### 6.2 Configure Connection Settings

1. When adding the connector tool, you'll be prompted for connection settings

2. Ensure **Credentials to use** is set to **User credentials** (default)
   - This ensures each user authenticates with their own account

### 6.3 Create Topics Using the Connector

Example topic: "Show my inbox"

```yaml
Trigger: "Show my inbox", "Check my email", "What emails do I have"

Actions:
  1. Call Catapult Connectors > mail_get_inbox
     - top: 10

  2. Display results with adaptive card
```

### 6.4 Publish the Agent

1. Click **Publish** in the top right

2. Choose your channels (Teams, Web, etc.)

---

## Step 7: Test End-to-End

### 7.1 First-Time User Experience

1. Open the Copilot agent in Teams or your chosen channel

2. Ask: "Show me my inbox"

3. The agent should:
   - Prompt the user to sign in (first time only)
   - Display OAuth consent dialog
   - After consent, show the user's emails

### 7.2 Verify in Azure

Check the Container App logs:

```bash
az containerapp logs show \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --follow
```

Look for:
- Token validation success messages
- OBO token exchange success
- Graph API call success

---

## Troubleshooting

### Common Issues

#### 1. "AADSTS65001: User consent required"

**Cause**: Admin consent not granted for the connector app.

**Solution**:
1. Go to Azure Portal > App registrations > Connector App > API permissions
2. Click "Grant admin consent for [Organization]"

#### 2. "AADSTS50013: Invalid assertion"

**Cause**: Token audience doesn't match the API app.

**Solution**:
1. Verify `AZURE_API_AUDIENCE` matches the API app's Application ID URI
2. Ensure the connector's Resource URL matches

#### 3. "Token validation failed: Invalid issuer"

**Cause**: Token is from a different tenant.

**Solution**:
1. Verify `AZURE_TENANT_ID` is correct
2. For multi-tenant apps, configure `AZURE_ALLOWED_ISSUERS`

#### 4. "OBO token exchange failed"

**Cause**: API app doesn't have the required Graph permissions.

**Solution**:
1. Go to API App > API permissions
2. Add all required Microsoft Graph delegated permissions
3. Grant admin consent

#### 5. Custom connector test fails with 401

**Cause**: Connector security misconfigured.

**Solution**:
1. Verify "Enable on-behalf-of login" is set to Yes
2. Verify Scope is correct: `api://<client-id>/access_as_user`
3. Verify redirect URL is added to connector app

### Debug Logging

Enable debug logging for more details:

```bash
az containerapp update \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --set-env-vars LOG_LEVEL="debug"
```

### Useful Azure CLI Commands

```bash
# View Container App logs
az containerapp logs show \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --tail 100

# Check Container App status
az containerapp show \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "properties.runningStatus"

# Restart Container App
az containerapp revision restart \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --revision <revision-name>

# List environment variables
az containerapp show \
  --name $CONTAINER_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "properties.template.containers[0].env"
```

---

## Security Checklist

Before going to production:

- [ ] API App has only required Graph permissions (principle of least privilege)
- [ ] Admin consent granted for both app registrations
- [ ] Client secrets have appropriate expiration dates
- [ ] Client secrets stored in Azure Container Apps secrets (not plain env vars)
- [ ] HTTPS enforced (Container Apps does this by default)
- [ ] Token validation enabled in the API
- [ ] Logging configured for audit trail
- [ ] CORS configured appropriately (if needed)

---

## CI/CD Pipeline

The `azure-pipelines.yml` file is configured for automated deployments:

- **develop branch**: Deploys to dev Container App
- **main branch**: Deploys to production Container App

Pipeline steps:
1. Install dependencies and run tests
2. Build Docker image
3. Push to Azure Container Registry
4. Update Container App with new image

---

## Quick Reference

### Key URLs

| Resource | URL |
|----------|-----|
| Container App | `https://<your-app>.azurecontainerapps.io` |
| API Docs | `https://<your-app>.azurecontainerapps.io/docs` |
| Health Check | `https://<your-app>.azurecontainerapps.io/health` |
| OpenAPI Spec | `https://<your-app>.azurecontainerapps.io/openapi.json` |

### Key IDs to Track

| Item | Value |
|------|-------|
| Azure Tenant ID | |
| API App Client ID | |
| API App Client Secret | (stored securely) |
| Connector App Client ID | |
| Connector App Client Secret | (stored securely) |
| Container App URL | |

---

## Support

For issues:
1. Check the [Troubleshooting](#troubleshooting) section
2. Review Container App logs
3. Verify Azure AD app registration configuration
4. Test the custom connector independently before testing in Copilot Studio
