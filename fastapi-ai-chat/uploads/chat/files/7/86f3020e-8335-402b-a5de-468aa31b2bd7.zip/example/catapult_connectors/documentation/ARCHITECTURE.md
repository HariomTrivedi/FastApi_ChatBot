# Architecture Documentation

## System Overview

Catapult Connectors follows a modular architecture built on Azure Functions with FastAPI as the web framework. The system acts as an API gateway that unifies access to multiple external services.

```
┌─────────────────────────────────────────────────────────────────────┐
│                     Microsoft Copilot Studio                         │
│                         (AI Agent)                                   │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ HTTP/REST
                                    ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      Azure Functions Host                            │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │                    FastAPI Application                         │  │
│  │                                                                │  │
│  │  ┌─────────────────────────────────────────────────────────┐  │  │
│  │  │                     Routers                              │  │  │
│  │  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐        │  │  │
│  │  │  │Simplicate│ │ Trello  │ │  Graph  │ │  Word   │        │  │  │
│  │  │  └─────────┘ └─────────┘ └─────────┘ └─────────┘        │  │  │
│  │  └─────────────────────────────────────────────────────────┘  │  │
│  │                            │                                   │  │
│  │  ┌─────────────────────────────────────────────────────────┐  │  │
│  │  │                     Clients                              │  │  │
│  │  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐        │  │  │
│  │  │  │Simplicate│ │ Trello  │ │  Graph  │ │  Word   │        │  │  │
│  │  │  │ Client  │ │ Client  │ │ Client  │ │ Client  │        │  │  │
│  │  │  └─────────┘ └─────────┘ └─────────┘ └─────────┘        │  │  │
│  │  └─────────────────────────────────────────────────────────┘  │  │
│  │                            │                                   │  │
│  │  ┌─────────────────────────────────────────────────────────┐  │  │
│  │  │               Shared Components                          │  │  │
│  │  │  ┌─────────┐ ┌─────────┐ ┌─────────┐                    │  │  │
│  │  │  │  Auth   │ │ Errors  │ │ Config  │                    │  │  │
│  │  │  └─────────┘ └─────────┘ └─────────┘                    │  │  │
│  │  └─────────────────────────────────────────────────────────┘  │  │
│  └───────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
                                    │
           ┌────────────────────────┼────────────────────────┐
           ▼                        ▼                        ▼
    ┌─────────────┐          ┌─────────────┐          ┌─────────────┐
    │  Simplicate │          │   Trello    │          │  Microsoft  │
    │     API     │          │    API      │          │    Graph    │
    └─────────────┘          └─────────────┘          └─────────────┘
```

## Component Layers

### 1. Entry Point Layer (`main.py`)

The entry point initializes the FastAPI application, serving as the central hub for routing and configuration.

**Key Responsibilities:**
- Initialize FastAPI application
- Configure CORS middleware
- Register all routers (Simplicate, Trello, Mail, Calendar, SharePoint, Word) with prefixes
- Set up error handlers (including custom `ConnectorError`)
- Configure OpenAPI documentation
- Manage application lifespan events (startup/shutdown logging)
- Provide health check endpoints (`/` and `/health`)

### 2. Router Layer (`connectors/*/router.py`)

Each connector has a dedicated router that defines FastAPI endpoints.

**Design Principles:**
- Each endpoint has a unique `operation_id` for Copilot Studio compatibility
- Comprehensive `summary` and `description` for auto-generated docs
- Consistent error handling via HTTPException
- Resource cleanup in `finally` blocks

**Example Pattern:**
```python
@router.get(
    "/items",
    response_model=List[Item],
    operation_id="connector_get_items",
    summary="List items",
    description="Detailed description for documentation."
)
async def get_items(...) -> List[Item]:
    client = get_client()
    try:
        return await client.get_items(...)
    finally:
        await client.close()
```

### 3. Client Layer (`connectors/*/client.py`)

Clients handle all communication with external APIs.

**Key Features:**
- Async HTTP operations using `httpx`
- Automatic token/credential management
- Response parsing into Pydantic models
- Error classification and handling
- Connection pooling and cleanup

**Client Pattern:**
```python
class ServiceClient:
    def __init__(self, auth: Optional[AuthClass] = None):
        self.auth = auth or get_auth()
        self._client: Optional[httpx.AsyncClient] = None

    async def _request(self, method: str, endpoint: str, ...) -> Any:
        # Handle authenticated requests
        pass

    async def close(self):
        if self._client:
            await self._client.aclose()
```

### 4. Models Layer (`connectors/*/models.py`)

Pydantic models define data structures for requests and responses.

**Model Categories:**
- **Base Models**: Shared fields for create/update/read
- **Create Models**: Fields required for creation
- **Update Models**: Optional fields for partial updates
- **Response Models**: Full entity representation

**Example:**
```python
class ItemBase(BaseModel):
    name: str = Field(..., description="Item name")

class ItemCreate(ItemBase):
    category_id: str

class Item(ItemBase):
    id: str
    created_at: datetime

    class Config:
        from_attributes = True
```

### 5. Shared Layer (`connectors/shared/`)

Common utilities shared across all connectors.

#### Authentication (`auth.py`)
- `SimplicateAuth`: API key + secret headers
- `TrelloAuth`: API key + token query params
- `GraphAuth`: OAuth 2.0 with Azure AD

#### Error Handling (`errors.py`)
- `ConnectorError`: Base exception class
- Specific exceptions per connector
- Standardized error response format

## Data Flow

### Request Flow

```
1. HTTP Request → Azure Functions Host
2. → ASGI Middleware → FastAPI Application
3. → Router validates request via Pydantic
4. → Client authenticates and calls external API
5. → Response parsed into Pydantic models
6. → JSON response returned to caller
```

### Authentication Flow (Microsoft Graph - On-Behalf-Of)

```
1. User interacts with Copilot Studio (authenticated via Azure AD)
2. Copilot Studio sends request to Connector API with User Access Token
3. Router extracts token and validates via `validate_token` dependency
4. GraphClient initiates On-Behalf-Of (OBO) flow using `get_user_graph_token`
5. App exchanges User Token for Graph Token via Azure AD
6. Graph Token is cached in `OBOTokenCache` for subsequent requests
7. GraphClient makes request to Microsoft Graph API with user context
```

## Design Decisions

### Why Azure Container Apps + FastAPI?

| Aspect | Decision | Rationale |
|--------|----------|-----------|
| **Runtime** | Azure Container Apps | Scalable container orchestration, serverless capabilities, standardized environment |
| **Framework** | FastAPI | Async support, automatic OpenAPI docs, Pydantic validation, high performance |
| **Server** | Gunicorn + Uvicorn | Production-grade WSGI/ASGI server setup for concurrency and stability |

### Why Separate Client and Router?

- **Separation of Concerns**: Routers handle HTTP, clients handle external APIs
- **Testability**: Clients can be unit tested in isolation
- **Reusability**: Clients can be used outside FastAPI context
- **Flexibility**: Different routers can use same client

### Why Pydantic Models?

- **Validation**: Automatic request/response validation
- **Documentation**: Auto-generated OpenAPI schemas
- **Type Safety**: IDE support and runtime checks
- **Serialization**: JSON encoding/decoding handled automatically

## Scalability Considerations

### Connection Management
- Async HTTP clients for non-blocking I/O
- Connection reuse within requests
- Proper cleanup in `finally` blocks

### Stateless Design
- No server-side session state
- All state in request/response
- Horizontal scaling friendly

### Rate Limiting
- External API rate limits respected
- Consider adding retry logic with exponential backoff
- Monitor for 429 responses

## Security Architecture

### Authentication Layers

1. **Container Level**: Azure Container Apps ingress protection (optional)
2. **Application Level**: OAuth 2.0 On-Behalf-Of flow for Graph, API Keys for other services
3. **CORS**: Configurable origin restrictions

### Credential Management

- Credentials stored in environment variables
- Azure Key Vault integration recommended for production
- Never log sensitive values

### API Security

- HTTPS enforced in production
- Input validation via Pydantic
- Output sanitization for sensitive fields
