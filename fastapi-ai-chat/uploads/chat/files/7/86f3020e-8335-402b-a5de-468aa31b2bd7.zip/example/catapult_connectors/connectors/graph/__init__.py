# Microsoft Graph Connectors (Mail, Calendar, SharePoint)
from .mail_router import router as mail_router
from .calendar_router import router as calendar_router
from .sharepoint_router import router as sharepoint_router

__all__ = ["mail_router", "calendar_router", "sharepoint_router"]
