import pytest
import respx
from httpx import Response
from datetime import date
from connectors.simplicate.client import SimplicateClient
from connectors.simplicate.models import HoursEntryCreate
from connectors.shared.auth import SimplicateAuth
from connectors.shared.errors import UnauthorizedError, NotFoundError, SimplicateError, InternalServerError

# Mock configuration
MOCK_AUTH = SimplicateAuth(
    subdomain="test-company",
    api_key="test-key",
    api_secret="test-secret"
)

@pytest.fixture
def client():
    """Create a SimplicateClient instance with mock auth."""
    return SimplicateClient(auth=MOCK_AUTH)

@pytest.mark.asyncio
class TestSimplicateClient:
    
    @respx.mock
    async def test_get_employees_success(self, client):
        """Verify fetching employees."""
        # Mock Simplicate API response
        mock_data = {
            "data": [
                {
                    "id": "emp_1",
                    "name": "Alice Smith",
                    "work_email": "alice@company.com",
                    "function": "Developer",
                    "is_active": True
                },
                {
                    "id": "emp_2",
                    "name": "Bob Jones",
                    "work_email": "bob@company.com",
                    "function": "Designer",
                    "is_active": True
                }
            ]
        }
        
        respx.get("https://test-company.simplicate.nl/api/v2/hrm/employee") \
             .mock(return_value=Response(200, json=mock_data))
             
        employees = await client.get_employees()
        
        assert len(employees) == 2
        assert employees[0].name == "Alice Smith"
        assert employees[0].email == "alice@company.com"
        assert employees[0].role == "Developer"

    @respx.mock
    async def test_get_employee_search(self, client):
        """Verify searching/filtering employees implicitly via get_employees logic or custom search logic if it existed."""
        # Note: The client uses get_employees list to find people usually, or get_employee by ID?
        # Looking at client.py, there isn't a dedicated "search_employee" method in the visible code 
        # (lines 1-487), only get_employees(is_active=True).
        # But let's test that we can parse the list correctly as that's the primary way to find people.
        
        mock_data = {
            "data": [
                {
                    "id": "emp_1",
                    "name": "Target Person",
                    "work_email": "target@company.com",
                    "function": "Target",
                    "is_active": True
                }
            ]
        }
        
        # Test the query params
        route = respx.get("https://test-company.simplicate.nl/api/v2/hrm/employee")
        route.mock(return_value=Response(200, json=mock_data))
             
        employees = await client.get_employees(is_active=True)
        
        assert len(employees) == 1
        assert employees[0].name == "Target Person"
        
        # Verify query params were sent
        assert route.calls.last.request.url.params["q[is_active]"] == "true"

    @respx.mock
    async def test_log_hours_success(self, client):
        """Verify logging hours constructs correct payload."""
        entry = HoursEntryCreate(
            project_id="proj_1",
            employee_id="emp_1",
            hours=4.0,
            entry_date=date(2023, 10, 27),
            description="Unit Testing",
            billable=True
        )
        
        # Mock POST response
        post_response = {
            "data": {
                "id": "hours_999"
            }
        }
        
        # Mock GET verification response (client fetches the entry after creating it)
        get_response = {
            "data": [{
                "id": "hours_999",
                "project": {"id": "proj_1", "name": "Project X"},
                "employee": {"id": "emp_1", "name": "Alice"},
                "hours": 4.0,
                "start_date": "2023-10-27",
                "note": "Unit Testing",
                "billable": True
            }]
        }
        
        respx.post("https://test-company.simplicate.nl/api/v2/hours/hours").mock(return_value=Response(200, json=post_response))
        respx.get("https://test-company.simplicate.nl/api/v2/hours/hours").mock(return_value=Response(200, json=get_response))
        
        result = await client.log_hours(entry)
        
        assert result.id == "hours_999"
        assert result.hours == 4.0
        assert result.project_id == "proj_1"
        assert result.employee_id == "emp_1"

    @respx.mock
    async def test_api_error_401(self, client):
        """Verify handling of 401 Unauthorized."""
        respx.get("https://test-company.simplicate.nl/api/v2/crm/organization") \
             .mock(return_value=Response(401, json={"errors": ["Unauthorized"]}))
             
        with pytest.raises(UnauthorizedError) as exc:
            await client.get_clients()
        
        assert "Simplicate API error" in str(exc.value)

    @respx.mock
    async def test_api_error_404(self, client):
        """Verify handling of 404 Not Found."""
        respx.get("https://test-company.simplicate.nl/api/v2/projects/project/invalid_id") \
             .mock(return_value=Response(404, json={"errors": ["Not found"]}))
             
        with pytest.raises(NotFoundError):
            await client.get_project("invalid_id")

    @respx.mock
    async def test_api_generic_error(self, client):
        """Verify handling of other error codes."""
        respx.get("https://test-company.simplicate.nl/api/v2/crm/organization") \
             .mock(return_value=Response(500, json={"errors": ["Server error"]}))
             
        with pytest.raises(InternalServerError):
             await client.get_clients()