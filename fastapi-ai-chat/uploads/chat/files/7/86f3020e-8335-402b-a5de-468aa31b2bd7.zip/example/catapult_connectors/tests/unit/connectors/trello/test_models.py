import pytest
from datetime import datetime
from connectors.trello.models import Board, TrelloList, Card, TodoCard, Member

def test_board_model_validation():
    """Verify Board model correctly parses valid data."""
    data = {
        "id": "board1",
        "name": "Test Board",
        "desc": "A description",
        "url": "https://trello.com/b/board1",
        "short_url": "https://trello.com/b/short",
        "closed": False,
        "pinned": True
    }
    board = Board(**data)
    assert board.id == "board1"
    assert board.name == "Test Board"
    assert board.pinned is True
    assert board.closed is False

def test_list_model_validation():
    """Verify TrelloList model correctly parses valid data."""
    data = {
        "id": "list1",
        "name": "To Do",
        "closed": False,
        "pos": 100.5,
        "board_id": "board1"
    }
    trello_list = TrelloList(**data)
    assert trello_list.id == "list1"
    assert trello_list.name == "To Do"
    assert trello_list.board_id == "board1"

def test_card_model_validation():
    """Verify Card model correctly parses valid data."""
    data = {
        "id": "card1",
        "idShort": 1,
        "name": "Test Card",
        "desc": "Card description",
        "url": "https://trello.com/c/card1",
        "shortUrl": "https://trello.com/c/short",
        "idList": "list1",
        "idBoard": "board1",
        "closed": False,
        "pos": 10,
        "due": "2023-12-31T23:59:59.999000Z",
        "dueComplete": False,
        "idMembers": ["mem1", "mem2"]
    }
    # Note: The model expects 'short_id' but validates from aliases or direct mapping if Config.from_attributes=True 
    # works with dict unpacking usually if field names match model fields.
    # Looking at Card model in previous turn:
    # id: str
    # short_id: int = Field(..., description="Short numeric ID")
    # ...
    # But when we init from API response in client.py, we do explicit mapping:
    # Card(id=item.get("id"), short_id=item.get("idShort"), ...)
    # Here in unit test we should test the model instantiation directly using model field names.
    
    model_data = {
        "id": "card1",
        "short_id": 1,
        "name": "Test Card",
        "desc": "Card description",
        "url": "https://trello.com/c/card1",
        "short_url": "https://trello.com/c/short",
        "list_id": "list1",
        "board_id": "board1",
        "closed": False,
        "pos": 10.0,
        "due": datetime(2023, 12, 31, 23, 59, 59),
        "due_complete": False,
        "member_ids": ["mem1", "mem2"]
    }
    
    card = Card(**model_data)
    assert card.id == "card1"
    assert card.short_id == 1
    assert card.member_ids == ["mem1", "mem2"]
    assert isinstance(card.due, datetime)

def test_todo_card_model():
    """Verify TodoCard model creation."""
    todo = TodoCard(
        id="card1",
        name="Urgent Task",
        due=datetime(2023, 1, 1),
        due_complete=False,
        list_name="Doing",
        board_name="Project Alpha",
        board_id="board1",
        url="http://url",
        is_overdue=True
    )
    assert todo.name == "Urgent Task"
    assert todo.is_overdue is True
    assert todo.list_name == "Doing"

def test_member_model_validation():
    """Verify Member model."""
    data = {
        "id": "mem1",
        "username": "user1",
        "full_name": "User One",
        "avatar_url": "http://avatar",
        "initials": "UO",
        "member_type": "normal"
    }
    member = Member(**data)
    assert member.username == "user1"
    assert member.initials == "UO"