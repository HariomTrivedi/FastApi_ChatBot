"""
Standardized error handling for all connectors.
Provides consistent error responses for Copilot Studio integration.
"""
from typing import Optional, Dict, Any, Type
from pydantic import BaseModel
from fastapi import Request
from fastapi.responses import JSONResponse
import logging
import httpx

logger = logging.getLogger(__name__)


class ErrorResponse(BaseModel):
    """Standardized error response format for all connectors."""
    error: str
    message: str
    details: Optional[Dict[str, Any]] = None
    connector: Optional[str] = None


class ConnectorError(Exception):
    """Base exception for all connector errors."""

    def __init__(
        self,
        status_code: int,
        error: str,
        message: str,
        details: Optional[Dict[str, Any]] = None,
        connector: Optional[str] = None
    ):
        self.status_code = status_code
        self.error = error
        self.message = message
        self.details = details
        self.connector = connector
        super().__init__(message)

    def to_response(self) -> ErrorResponse:
        """Convert exception to ErrorResponse."""
        return ErrorResponse(
            error=self.error,
            message=self.message,
            details=self.details,
            connector=self.connector
        )


# --- Standardized HTTP Errors ---

class UnauthorizedError(ConnectorError):
    """401 Unauthorized error."""
    def __init__(self, message: str = "Unauthorized", details: Optional[Dict[str, Any]] = None, connector: Optional[str] = None):
        super().__init__(
            status_code=401,
            error="UNAUTHORIZED",
            message=message,
            details=details,
            connector=connector
        )


class ForbiddenError(ConnectorError):
    """403 Forbidden error."""
    def __init__(self, message: str = "Forbidden", details: Optional[Dict[str, Any]] = None, connector: Optional[str] = None):
        super().__init__(
            status_code=403,
            error="FORBIDDEN",
            message=message,
            details=details,
            connector=connector
        )


class NotFoundError(ConnectorError):
    """404 Not Found error."""
    def __init__(self, message: str = "Not Found", details: Optional[Dict[str, Any]] = None, connector: Optional[str] = None):
        super().__init__(
            status_code=404,
            error="NOT_FOUND",
            message=message,
            details=details,
            connector=connector
        )


class TooManyRequestsError(ConnectorError):
    """429 Too Many Requests error."""
    def __init__(self, message: str = "Too Many Requests", details: Optional[Dict[str, Any]] = None, connector: Optional[str] = None):
        super().__init__(
            status_code=429,
            error="TOO_MANY_REQUESTS",
            message=message,
            details=details,
            connector=connector
        )


class ServiceUnavailableError(ConnectorError):
    """503 Service Unavailable error."""
    def __init__(self, message: str = "Service Unavailable", details: Optional[Dict[str, Any]] = None, connector: Optional[str] = None):
        super().__init__(
            status_code=503,
            error="SERVICE_UNAVAILABLE",
            message=message,
            details=details,
            connector=connector
        )


class InternalServerError(ConnectorError):
    """500 Internal Server Error."""
    def __init__(self, message: str = "Internal Server Error", details: Optional[Dict[str, Any]] = None, connector: Optional[str] = None):
        super().__init__(
            status_code=500,
            error="INTERNAL_SERVER_ERROR",
            message=message,
            details=details,
            connector=connector
        )


class NetworkError(ConnectorError):
    """Network related errors (connection reset, timeout, etc.)."""
    def __init__(self, message: str = "Network Error", details: Optional[Dict[str, Any]] = None, connector: Optional[str] = None):
        super().__init__(
            status_code=502, # Bad Gateway is often appropriate for upstream network failures
            error="NETWORK_ERROR",
            message=message,
            details=details,
            connector=connector
        )


# --- Specific Errors ---

class AuthenticationError(UnauthorizedError):
    """Error when authentication fails."""
    def __init__(self, connector: str, message: str = "Authentication failed"):
        super().__init__(message=message, connector=connector)
        self.error = "AUTHENTICATION_FAILED"


class ConfigurationError(InternalServerError):
    """Error when configuration is missing or invalid."""
    def __init__(self, connector: str, message: str = "Configuration error"):
        super().__init__(message=message, connector=connector)
        self.error = "CONFIGURATION_ERROR"


class SimplicateError(ConnectorError):
    """Error from Simplicate API."""
    def __init__(self, status_code: int, message: str, details: Optional[Dict[str, Any]] = None):
        # Fallback error code
        error = "SIMPLICATE_ERROR"
        super().__init__(
            status_code=status_code,
            error=error,
            message=message,
            details=details,
            connector="simplicate"
        )


class TrelloError(ConnectorError):
    """Error from Trello API."""
    def __init__(self, status_code: int, message: str, details: Optional[Dict[str, Any]] = None):
        # Fallback error code
        error = "TRELLO_ERROR"
        super().__init__(
            status_code=status_code,
            error=error,
            message=message,
            details=details,
            connector="trello"
        )


class GraphError(ConnectorError):
    """Error from Microsoft Graph API."""
    def __init__(self, status_code: int, message: str, details: Optional[Dict[str, Any]] = None):
        # Fallback error code
        error = "GRAPH_ERROR"
        super().__init__(
            status_code=status_code,
            error=error,
            message=message,
            details=details,
            connector="graph"
        )


async def connector_error_handler(request: Request, exc: ConnectorError) -> JSONResponse:
    """
    Global exception handler for ConnectorError.
    Register this with FastAPI app for consistent error handling.
    """
    logger.error(
        f"Connector error: {exc.connector} - {exc.error}: {exc.message}",
        extra={"details": exc.details, "status_code": exc.status_code, "connector": exc.connector}
    )

    return JSONResponse(
        status_code=exc.status_code,
        content=exc.to_response().model_dump()
    )


def handle_http_error(response_status: int, response_text: str, connector: str, details: Optional[Dict[str, Any]] = None) -> ConnectorError:
    """
    Create appropriate ConnectorError based on HTTP response.

    Args:
        response_status: HTTP status code
        response_text: Response body text
        connector: Name of the connector (simplicate, trello, graph)
        details: Optional dictionary with extra details

    Returns:
        Appropriate ConnectorError subclass
    """
    error_msg = f"{connector.title()} API error: {response_text}"
    error_details = {"raw_response": response_text}
    if details:
        error_details.update(details)

    # Map standard HTTP codes to standardized exceptions
    if response_status == 401:
        return UnauthorizedError(message=error_msg, details=error_details, connector=connector)
    elif response_status == 403:
        return ForbiddenError(message=error_msg, details=error_details, connector=connector)
    elif response_status == 404:
        return NotFoundError(message=error_msg, details=error_details, connector=connector)
    elif response_status == 429:
        return TooManyRequestsError(message=error_msg, details=error_details, connector=connector)
    elif response_status == 503:
        return ServiceUnavailableError(message=error_msg, details=error_details, connector=connector)
    elif 500 <= response_status < 600:
        return InternalServerError(message=error_msg, details=error_details, connector=connector)

    # Fallback to connector-specific or generic errors
    error_classes = {
        "simplicate": SimplicateError,
        "trello": TrelloError,
        "graph": GraphError,
    }

    error_class = error_classes.get(connector, ConnectorError)
    
    # If using base ConnectorError, we need to supply 'error' arg manually, 
    # but subclasses (SimplicateError etc) handle it in their __init__
    if error_class == ConnectorError:
        return ConnectorError(
            status_code=response_status,
            error=f"{connector.upper()}_ERROR",
            message=error_msg,
            details=error_details,
            connector=connector
        )

    return error_class(
        status_code=response_status,
        message=error_msg,
        details=error_details
    )
