"""
Trello API client for making requests to Trello.
Handles authentication, request formatting, and error handling.
"""
import httpx
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
import logging

from ..shared.auth import get_trello_auth, TrelloAuth
from ..shared.errors import TrelloError, ConfigurationError, handle_http_error, NetworkError
from ..shared.retry import async_retry
from .models import (
    Board, BoardCreate,
    TrelloList,
    Card, CardCreate, CardUpdate,
    Member, TodoCard, TodoSummary
)

logger = logging.getLogger(__name__)


class TrelloClient:
    """
    HTTP client for Trello API.

    Handles all communication with Trello's REST API including:
    - Board management
    - List management
    - Card management
    - Member queries
    """

    def __init__(self, auth: Optional[TrelloAuth] = None):
        self.auth = auth or get_trello_auth()
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._client is None:
            if not self.auth.is_configured:
                raise ConfigurationError(
                    connector="trello",
                    message="Trello API credentials not configured. Set TRELLO_API_KEY and TRELLO_API_TOKEN."
                )
            self._client = httpx.AsyncClient(
                base_url=self.auth.base_url,
                timeout=30.0
            )
        return self._client

    @async_retry()
    async def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None
    ) -> Any:
        """Make authenticated request to Trello API."""
        # Add auth params to every request
        all_params = {**self.auth.params}
        if params:
            all_params.update(params)

        try:
            response = await self.client.request(
                method=method,
                url=endpoint,
                params=all_params,
                json=json
            )

            if response.status_code >= 400:
                raise handle_http_error(
                    response_status=response.status_code,
                    response_text=response.text,
                    connector="trello",
                    details={"endpoint": endpoint, "method": method}
                )

            return response.json() if response.text else {}

        except httpx.RequestError as e:
            logger.error(f"Trello request failed: {e}")
            raise NetworkError(
                message=f"Failed to connect to Trello: {str(e)}",
                connector="trello"
            )

    # --- Board Methods ---

    async def get_boards(self, filter: Optional[str] = "open") -> List[Board]:
        """
        Get all boards for the authenticated user.

        Args:
            filter: Filter by status (open, closed, all)
        """
        params = {"filter": filter, "fields": "name,desc,url,shortUrl,closed,pinned"}
        data = await self._request("GET", "/members/me/boards", params=params)

        return [
            Board(
                id=item.get("id", ""),
                name=item.get("name", ""),
                desc=item.get("desc"),
                url=item.get("url", ""),
                short_url=item.get("shortUrl"),
                closed=item.get("closed", False),
                pinned=item.get("pinned", False)
            )
            for item in data
        ]

    async def get_board(self, board_id: str) -> Board:
        """Get a single board by ID."""
        data = await self._request("GET", f"/boards/{board_id}")
        return Board(
            id=data.get("id", ""),
            name=data.get("name", ""),
            desc=data.get("desc"),
            url=data.get("url", ""),
            short_url=data.get("shortUrl"),
            closed=data.get("closed", False),
            pinned=data.get("pinned", False)
        )

    async def create_board(self, board: BoardCreate) -> Board:
        """Create a new board."""
        params = {
            "name": board.name,
            "desc": board.desc or "",
            "defaultLists": str(board.default_lists).lower()
        }
        if board.template_id:
            params["idBoardSource"] = board.template_id

        data = await self._request("POST", "/boards", params=params)
        return await self.get_board(data.get("id", ""))

    # --- List Methods ---

    async def get_lists(self, board_id: str) -> List[TrelloList]:
        """Get all lists on a board."""
        data = await self._request("GET", f"/boards/{board_id}/lists")
        return [
            TrelloList(
                id=item.get("id", ""),
                name=item.get("name", ""),
                closed=item.get("closed", False),
                pos=item.get("pos", 0),
                board_id=board_id
            )
            for item in data
        ]

    # --- Card Methods ---

    async def get_cards(
        self,
        board_id: str,
        list_id: Optional[str] = None
    ) -> List[Card]:
        """Get cards on a board, optionally filtered by list."""
        if list_id:
            data = await self._request("GET", f"/lists/{list_id}/cards")
        else:
            data = await self._request("GET", f"/boards/{board_id}/cards")

        return [
            Card(
                id=item.get("id", ""),
                short_id=item.get("idShort", 0),
                name=item.get("name", ""),
                desc=item.get("desc"),
                url=item.get("url", ""),
                short_url=item.get("shortUrl"),
                list_id=item.get("idList", ""),
                board_id=item.get("idBoard", board_id),
                closed=item.get("closed", False),
                pos=item.get("pos", 0),
                due=item.get("due"),
                due_complete=item.get("dueComplete", False),
                labels=item.get("labels"),
                member_ids=item.get("idMembers")
            )
            for item in data
        ]

    async def get_card(self, card_id: str) -> Card:
        """Get a single card by ID."""
        data = await self._request("GET", f"/cards/{card_id}")
        return Card(
            id=data.get("id", ""),
            short_id=data.get("idShort", 0),
            name=data.get("name", ""),
            desc=data.get("desc"),
            url=data.get("url", ""),
            short_url=data.get("shortUrl"),
            list_id=data.get("idList", ""),
            board_id=data.get("idBoard", ""),
            closed=data.get("closed", False),
            pos=data.get("pos", 0),
            due=data.get("due"),
            due_complete=data.get("dueComplete", False),
            labels=data.get("labels"),
            member_ids=data.get("idMembers")
        )

    async def create_card(self, card: CardCreate) -> Card:
        """Create a new card."""
        params = {
            "idList": card.list_id,
            "name": card.name,
            "desc": card.desc or "",
            "pos": card.pos or "bottom"
        }
        if card.due:
            params["due"] = card.due.isoformat()
        if card.member_ids:
            params["idMembers"] = ",".join(card.member_ids)
        if card.label_ids:
            params["idLabels"] = ",".join(card.label_ids)

        data = await self._request("POST", "/cards", params=params)
        return await self.get_card(data.get("id", ""))

    async def update_card(self, card_id: str, update: CardUpdate) -> Card:
        """Update an existing card."""
        params = {}
        if update.name is not None:
            params["name"] = update.name
        if update.desc is not None:
            params["desc"] = update.desc
        if update.due is not None:
            params["due"] = update.due.isoformat()
        if update.due_complete is not None:
            params["dueComplete"] = str(update.due_complete).lower()
        if update.list_id is not None:
            params["idList"] = update.list_id
        if update.closed is not None:
            params["closed"] = str(update.closed).lower()

        await self._request("PUT", f"/cards/{card_id}", params=params)
        return await self.get_card(card_id)

    async def delete_card(self, card_id: str) -> bool:
        """Delete a card."""
        await self._request("DELETE", f"/cards/{card_id}")
        return True

    # --- Member Methods ---

    async def get_members(self, board_id: str) -> List[Member]:
        """Get all members of a board."""
        data = await self._request("GET", f"/boards/{board_id}/members")
        return [
            Member(
                id=item.get("id", ""),
                username=item.get("username", ""),
                full_name=item.get("fullName", ""),
                avatar_url=f"https://trello-members.s3.amazonaws.com/{item.get('id')}/{item.get('avatarHash')}/50.png" if item.get("avatarHash") else None,
                initials=item.get("initials"),
                member_type=item.get("memberType")
            )
            for item in data
        ]

    # --- Todo/Due Cards Methods ---

    async def get_todos(
        self,
        board_ids: Optional[List[str]] = None,
        member_id: Optional[str] = None
    ) -> TodoSummary:
        """
        Get all cards with due dates across boards.

        Args:
            board_ids: Optional list of board IDs to check (defaults to all)
            member_id: Optional filter by assigned member
        """
        # Get all boards if not specified
        if not board_ids:
            boards = await self.get_boards()
            board_ids = [b.id for b in boards]

        all_todos = []
        now = datetime.utcnow()
        today_end = now.replace(hour=23, minute=59, second=59)
        week_end = now + timedelta(days=7)

        overdue_count = 0
        due_today_count = 0
        due_this_week_count = 0

        for board_id in board_ids:
            board = await self.get_board(board_id)
            lists = await self.get_lists(board_id)
            list_map = {lst.id: lst.name for lst in lists}

            cards = await self.get_cards(board_id)

            for card in cards:
                if card.due and not card.closed:
                    # Filter by member if specified
                    if member_id and member_id not in (card.member_ids or []):
                        continue

                    due_dt = datetime.fromisoformat(card.due.replace("Z", "+00:00")) if isinstance(card.due, str) else card.due
                    is_overdue = due_dt < now and not card.due_complete

                    todo = TodoCard(
                        id=card.id,
                        name=card.name,
                        due=due_dt,
                        due_complete=card.due_complete,
                        list_name=list_map.get(card.list_id, "Unknown"),
                        board_name=board.name,
                        board_id=board_id,
                        url=card.url,
                        assigned_members=card.member_ids,
                        is_overdue=is_overdue
                    )
                    all_todos.append(todo)

                    if is_overdue:
                        overdue_count += 1
                    elif due_dt <= today_end:
                        due_today_count += 1
                    elif due_dt <= week_end:
                        due_this_week_count += 1

        # Sort by due date
        all_todos.sort(key=lambda t: t.due or datetime.max)

        return TodoSummary(
            total_todos=len(all_todos),
            overdue_count=overdue_count,
            due_today_count=due_today_count,
            due_this_week_count=due_this_week_count,
            cards=all_todos
        )

    async def close(self):
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None
