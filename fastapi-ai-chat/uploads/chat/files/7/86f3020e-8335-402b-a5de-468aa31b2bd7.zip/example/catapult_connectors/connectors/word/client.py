"""
Word document client for creating and manipulating .docx files.
Uses python-docx library for document operations.
"""
import base64
import io
import re
import logging
from typing import Optional, List, Dict, Any, BinaryIO

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE

from .models import (
    DocumentCreateRequest, DocumentSection, ParagraphContent, HeadingContent,
    TableContent, ImageContent, TextAlignment, HeadingLevel, FontStyle,
    DocumentInfo, TableStyle, ParagraphStyle
)

logger = logging.getLogger(__name__)


class WordClient:
    """
    Client for creating and manipulating Word documents.

    Handles:
    - Document creation from scratch
    - Template-based document generation
    - Document modification (append, replace)
    - Document analysis
    """

    # Alignment mapping
    ALIGNMENT_MAP = {
        TextAlignment.LEFT: WD_PARAGRAPH_ALIGNMENT.LEFT,
        TextAlignment.CENTER: WD_PARAGRAPH_ALIGNMENT.CENTER,
        TextAlignment.RIGHT: WD_PARAGRAPH_ALIGNMENT.RIGHT,
        TextAlignment.JUSTIFY: WD_PARAGRAPH_ALIGNMENT.JUSTIFY,
    }

    def create_document(self, request: DocumentCreateRequest) -> bytes:
        """
        Create a new Word document from structured content.

        Args:
            request: Document creation request with sections

        Returns:
            Document as bytes
        """
        doc = Document()

        # Add title if provided
        if request.title:
            doc.add_heading(request.title, level=0)

        # Process each section
        for section in request.sections:
            self._add_section(doc, section)

        return self._document_to_bytes(doc)

    def create_from_template(
        self,
        template_bytes: bytes,
        replacements: Dict[str, str]
    ) -> bytes:
        """
        Create document from template with placeholder replacements.

        Args:
            template_bytes: Template document as bytes
            replacements: Dict of placeholder -> replacement text

        Returns:
            Modified document as bytes
        """
        doc = Document(io.BytesIO(template_bytes))

        # Replace in paragraphs
        for paragraph in doc.paragraphs:
            self._replace_in_paragraph(paragraph, replacements)

        # Replace in tables
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    for paragraph in cell.paragraphs:
                        self._replace_in_paragraph(paragraph, replacements)

        # Replace in headers and footers
        for section in doc.sections:
            # Header
            if section.header:
                for paragraph in section.header.paragraphs:
                    self._replace_in_paragraph(paragraph, replacements)
            # Footer
            if section.footer:
                for paragraph in section.footer.paragraphs:
                    self._replace_in_paragraph(paragraph, replacements)

        return self._document_to_bytes(doc)

    def append_paragraph(
        self,
        document_bytes: bytes,
        content: ParagraphContent
    ) -> bytes:
        """
        Append a paragraph to existing document.

        Args:
            document_bytes: Existing document as bytes
            content: Paragraph content to append

        Returns:
            Modified document as bytes
        """
        doc = Document(io.BytesIO(document_bytes))

        paragraph = doc.add_paragraph()

        # Add text with optional styling
        if content.font_style:
            run = paragraph.add_run(content.text)
            self._apply_font_style(run, content.font_style)
        else:
            paragraph.add_run(content.text)

        # Apply paragraph style
        if content.style:
            paragraph.style = content.style.value

        # Apply alignment
        if content.alignment:
            paragraph.alignment = self.ALIGNMENT_MAP.get(content.alignment)

        return self._document_to_bytes(doc)

    def append_table(
        self,
        document_bytes: bytes,
        content: TableContent
    ) -> bytes:
        """
        Append a table to existing document.

        Args:
            document_bytes: Existing document as bytes
            content: Table content to append

        Returns:
            Modified document as bytes
        """
        doc = Document(io.BytesIO(document_bytes))

        # Create table with header row + data rows
        num_rows = len(content.rows) + 1
        num_cols = len(content.headers)

        table = doc.add_table(rows=num_rows, cols=num_cols)

        # Apply style if specified
        if content.style:
            try:
                # Remove spaces for style name
                style_name = content.style.value.replace(" ", "")
                table.style = style_name
            except Exception:
                # Fall back to default
                table.style = "Table Grid"

        # Add headers
        header_cells = table.rows[0].cells
        for idx, header_text in enumerate(content.headers):
            header_cells[idx].text = header_text
            # Make header bold
            for paragraph in header_cells[idx].paragraphs:
                for run in paragraph.runs:
                    run.bold = True

        # Add data rows
        for row_idx, row_data in enumerate(content.rows, start=1):
            row_cells = table.rows[row_idx].cells
            for col_idx, cell_text in enumerate(row_data):
                if col_idx < num_cols:
                    row_cells[col_idx].text = str(cell_text)

        return self._document_to_bytes(doc)

    def replace_text(
        self,
        document_bytes: bytes,
        find_text: str,
        replace_text: str,
        match_case: bool = True
    ) -> tuple[bytes, int]:
        """
        Find and replace text in document.

        Args:
            document_bytes: Document as bytes
            find_text: Text to find
            replace_text: Replacement text
            match_case: Case-sensitive matching

        Returns:
            Tuple of (modified document bytes, replacement count)
        """
        doc = Document(io.BytesIO(document_bytes))
        count = 0

        # Replace in paragraphs
        for paragraph in doc.paragraphs:
            replaced = self._replace_text_in_paragraph(
                paragraph, find_text, replace_text, match_case
            )
            count += replaced

        # Replace in tables
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    for paragraph in cell.paragraphs:
                        replaced = self._replace_text_in_paragraph(
                            paragraph, find_text, replace_text, match_case
                        )
                        count += replaced

        return self._document_to_bytes(doc), count

    def get_document_info(self, document_bytes: bytes) -> DocumentInfo:
        """
        Analyze document and return information.

        Args:
            document_bytes: Document as bytes

        Returns:
            DocumentInfo with statistics
        """
        doc = Document(io.BytesIO(document_bytes))

        # Count paragraphs
        paragraph_count = len(doc.paragraphs)

        # Count tables
        table_count = len(doc.tables)

        # Count inline shapes (images)
        image_count = len(doc.inline_shapes)

        # Count words
        word_count = 0
        for paragraph in doc.paragraphs:
            word_count += len(paragraph.text.split())

        # Collect styles used
        styles_used = set()
        for paragraph in doc.paragraphs:
            if paragraph.style:
                styles_used.add(paragraph.style.name)

        return DocumentInfo(
            paragraph_count=paragraph_count,
            table_count=table_count,
            image_count=image_count,
            word_count=word_count,
            styles_used=list(styles_used)
        )

    def extract_text(self, document_bytes: bytes) -> str:
        """
        Extract all text from document.

        Args:
            document_bytes: Document as bytes

        Returns:
            Plain text content
        """
        doc = Document(io.BytesIO(document_bytes))
        full_text = []

        for paragraph in doc.paragraphs:
            full_text.append(paragraph.text)

        # Also extract from tables
        for table in doc.tables:
            for row in table.rows:
                row_text = []
                for cell in row.cells:
                    row_text.append(cell.text)
                full_text.append("\t".join(row_text))

        return "\n".join(full_text)

    # --- Private Helper Methods ---

    def _add_section(self, doc: Document, section: DocumentSection):
        """Add a section to the document based on its type."""
        section_type = section.type.lower()
        content = section.content

        if section_type == "paragraph":
            self._add_paragraph(doc, ParagraphContent(**content))

        elif section_type == "heading":
            heading = HeadingContent(**content)
            doc.add_heading(heading.text, level=heading.level.value)

        elif section_type == "table":
            self._add_table(doc, TableContent(**content))

        elif section_type == "image":
            self._add_image(doc, ImageContent(**content))

        elif section_type == "page_break":
            doc.add_page_break()

        elif section_type == "list_bullet":
            items = content.get("items", [])
            for item in items:
                doc.add_paragraph(item, style="List Bullet")

        elif section_type == "list_number":
            items = content.get("items", [])
            for item in items:
                doc.add_paragraph(item, style="List Number")

        else:
            logger.warning(f"Unknown section type: {section_type}")

    def _add_paragraph(self, doc: Document, content: ParagraphContent):
        """Add a paragraph with optional styling."""
        if content.style:
            paragraph = doc.add_paragraph(style=content.style.value)
        else:
            paragraph = doc.add_paragraph()

        # Add text with font styling
        if content.font_style:
            run = paragraph.add_run(content.text)
            self._apply_font_style(run, content.font_style)
        else:
            paragraph.add_run(content.text)

        # Apply alignment
        if content.alignment:
            paragraph.alignment = self.ALIGNMENT_MAP.get(content.alignment)

    def _add_table(self, doc: Document, content: TableContent):
        """Add a table to the document."""
        num_rows = len(content.rows) + 1  # +1 for header
        num_cols = len(content.headers)

        table = doc.add_table(rows=num_rows, cols=num_cols)

        # Apply style
        if content.style:
            try:
                style_name = content.style.value.replace(" ", "")
                table.style = style_name
            except Exception:
                table.style = "Table Grid"
        else:
            table.style = "Table Grid"

        # Add headers (bold)
        for idx, header in enumerate(content.headers):
            cell = table.rows[0].cells[idx]
            cell.text = header
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.bold = True

        # Add data rows
        for row_idx, row_data in enumerate(content.rows, start=1):
            for col_idx, cell_text in enumerate(row_data):
                if col_idx < num_cols:
                    table.rows[row_idx].cells[col_idx].text = str(cell_text)

    def _add_image(self, doc: Document, content: ImageContent):
        """Add an image to the document."""
        # Decode base64 image
        image_bytes = base64.b64decode(content.base64_data)
        image_stream = io.BytesIO(image_bytes)

        # Determine dimensions
        width = Inches(content.width_inches) if content.width_inches else None
        height = Inches(content.height_inches) if content.height_inches else None

        # Add picture
        if width and height:
            doc.add_picture(image_stream, width=width, height=height)
        elif width:
            doc.add_picture(image_stream, width=width)
        elif height:
            doc.add_picture(image_stream, height=height)
        else:
            doc.add_picture(image_stream)

    def _apply_font_style(self, run, style: FontStyle):
        """Apply font styling to a run."""
        if style.bold:
            run.bold = True
        if style.italic:
            run.italic = True
        if style.underline:
            run.underline = True
        if style.size_pt:
            run.font.size = Pt(style.size_pt)
        if style.font_name:
            run.font.name = style.font_name
        if style.color_hex:
            # Convert hex to RGB
            hex_color = style.color_hex.lstrip("#")
            r = int(hex_color[0:2], 16)
            g = int(hex_color[2:4], 16)
            b = int(hex_color[4:6], 16)
            run.font.color.rgb = RGBColor(r, g, b)

    def _replace_in_paragraph(self, paragraph, replacements: Dict[str, str]):
        """Replace placeholders in a paragraph."""
        for placeholder, replacement in replacements.items():
            if placeholder in paragraph.text:
                # Simple replacement - may break formatting for complex cases
                inline = paragraph.runs
                for run in inline:
                    if placeholder in run.text:
                        run.text = run.text.replace(placeholder, replacement)

    def _replace_text_in_paragraph(
        self,
        paragraph,
        find_text: str,
        replace_text: str,
        match_case: bool
    ) -> int:
        """Replace text in paragraph and return count of replacements."""
        count = 0
        for run in paragraph.runs:
            if match_case:
                if find_text in run.text:
                    count += run.text.count(find_text)
                    run.text = run.text.replace(find_text, replace_text)
            else:
                if find_text.lower() in run.text.lower():
                    # Case-insensitive replace
                    pattern = re.compile(re.escape(find_text), re.IGNORECASE)
                    matches = pattern.findall(run.text)
                    count += len(matches)
                    run.text = pattern.sub(replace_text, run.text)
        return count

    def _document_to_bytes(self, doc: Document) -> bytes:
        """Convert Document to bytes."""
        buffer = io.BytesIO()
        doc.save(buffer)
        buffer.seek(0)
        return buffer.getvalue()
