"""
Catapult Connectors API - Azure Container Apps.

This module provides a FastAPI application exposing REST APIs for
Simplicate, Trello, and Microsoft Graph integrations.
Designed for consumption by Microsoft Copilot Studio.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from connectors.simplicate.router import router as simplicate_router
from connectors.trello.router import router as trello_router
from connectors.graph.mail_router import router as mail_router
from connectors.graph.calendar_router import router as calendar_router
from connectors.graph.sharepoint_router import router as sharepoint_router
from connectors.word.router import router as word_router
from connectors.shared.errors import ConnectorError, connector_error_handler
from connectors.shared.logging_config import configure_logging
import logging


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler for startup/shutdown."""
    # Startup
    configure_logging()
    logging.info("Application starting up...")
    yield
    # Shutdown - cleanup resources if needed
    logging.info("Application shutting down...")


# Create FastAPI application
app = FastAPI(
    title="Catapult Connectors API",
    description="""
    Central API backend for Microsoft Copilot Studio agents.

    Provides unified access to:
    - **Simplicate CRM**: Clients, projects, hours, and capacity management
    - **Trello**: Boards, lists, cards, and todo tracking
    - **Microsoft Graph**: Outlook mail, calendar, and SharePoint/OneDrive
    - **Word Documents**: Create, modify, and analyze .docx files

    All endpoints are designed for OpenAPI/Swagger integration with Copilot Studio.
    """,
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan
)

# CORS middleware for cross-origin requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register custom error handler
app.add_exception_handler(ConnectorError, connector_error_handler)

# Include routers with prefixes and tags
app.include_router(
    simplicate_router,
    prefix="/simplicate",
    tags=["Simplicate CRM"]
)

app.include_router(
    trello_router,
    prefix="/trello",
    tags=["Trello"]
)

app.include_router(
    mail_router,
    prefix="/mail",
    tags=["Outlook Mail"]
)

app.include_router(
    calendar_router,
    prefix="/calendar",
    tags=["Outlook Calendar"]
)

app.include_router(
    sharepoint_router,
    prefix="/sharepoint",
    tags=["SharePoint/OneDrive"]
)

app.include_router(
    word_router,
    prefix="/word",
    tags=["Word Documents"]
)


@app.get(
    "/",
    operation_id="root_health_check",
    summary="Health check",
    description="Basic health check endpoint. Returns API status and version.",
    tags=["System"]
)
async def root():
    """Root endpoint for health checks."""
    return {
        "status": "healthy",
        "service": "Catapult Connectors API",
        "version": "1.0.0"
    }


@app.get(
    "/health",
    operation_id="detailed_health_check",
    summary="Detailed health check",
    description="Detailed health check with connector status.",
    tags=["System"]
)
async def health_check():
    """Detailed health check endpoint."""
    return {
        "status": "healthy",
        "connectors": {
            "simplicate": "available",
            "trello": "available",
            "graph_mail": "available",
            "graph_calendar": "available",
            "graph_sharepoint": "available",
            "word": "available"
        }
    }
