# Testing Strategy

This document outlines the testing strategy for the Catapult Connectors API. The goal is to ensure reliability, security, and maintainability across all connector modules and shared utilities.

## Testing Framework: `pytest`

We have chosen [`pytest`](https://docs.pytest.org/) as the primary testing framework for this project.

### Justification
- **Async Support**: Native support for asynchronous testing via `pytest-asyncio`, which is critical for our `httpx` and FastAPI-based codebase.
- **Fixtures**: Powerful fixture system allows for clean setup/teardown of database states, mock clients, and authentication contexts.
- **Scalability**: Easily handles everything from simple unit tests to complex integration tests.
- **Ecosystem**: Extensive plugin ecosystem (e.g., `pytest-cov` for coverage, `pytest-mock` for easier mocking).
- **Readability**: Minimal boilerplate compared to standard library `unittest`.

## Test Directory Structure

The `tests/` directory will mirror the project's structure to ensure intuitive navigation and scalability.

```text
tests/
├── conftest.py              # Global fixtures (app instance, mock settings)
├── unit/                    # Unit tests (isolated logic)
│   ├── shared/              # Tests for connectors/shared/
│   │   ├── test_auth.py
│   │   ├── test_retry.py
│   │   └── test_errors.py
│   └── connectors/          # Tests for individual connector logic
│       ├── simplicate/
│       │   ├── test_client.py
│       │   └── test_models.py
│       ├── trello/
│       │   ├── test_client.py
│       │   └── test_models.py
│       └── graph/
│           ├── test_client.py
│           └── test_models.py
└── integration/             # Integration tests (component interactions)
    ├── test_api_health.py   # Root/Health endpoint tests
    ├── connectors/
    │   ├── test_simplicate_api.py
    │   ├── test_trello_api.py
    │   └── test_graph_api.py
    └── test_auth_flow.py    # OBO and token validation tests
```

## Unit Testing Strategy

Unit tests focus on individual functions and classes in isolation.

### Approach
- **Isolated Testing**: Test `Client` methods and `Router` logic without making real network calls.
- **Mocking External Services**: Use `pytest-mock` (or `unittest.mock`) and `respx` to mock `httpx` responses. This ensures tests are fast and deterministic.
- **Pydantic Validation**: Verify that models correctly parse valid data and raise errors for invalid data.
- **Error Handling**: Explicitly test that `ConnectorError` and its subclasses are raised correctly under various failure scenarios (401, 404, 500, etc.).

### Example: Mocking a Client Request
```python
@pytest.mark.asyncio
async def test_get_boards_success(trello_client, respx_mock):
    respx_mock.get("https://api.trello.com/1/members/me/boards").mock(
        return_value=httpx.Response(200, json=[{"id": "1", "name": "Test Board"}])
    )
    boards = await trello_client.get_boards()
    assert len(boards) == 1
    assert boards[0].name == "Test Board"
```

## Integration Testing Strategy

Integration tests verify that different layers of the application work together correctly (Router -> Client -> Shared Utils).

### Approach
- **FastAPI `TestClient`**: Use `httpx.AsyncClient` against the FastAPI `app` instance.
- **Dependency Overrides**: Use FastAPI's `app.dependency_overrides` to mock the `validate_token` dependency, allowing us to simulate authenticated users without real JWTs.
- **Mocked Backend APIs**: While these are integration tests, we still mock the *external* APIs (Simplicate, Trello, Graph) to avoid side effects and dependency on external service availability.
- **End-to-End Flows**: Test full request/response cycles, including header propagation and error response formatting.

## Key Areas of Focus

1.  **Authentication & OBO Flow**:
    - Validation of tokens in `connectors/shared/dependencies.py`.
    - Token exchange logic in `connectors/shared/auth.py` (OBO flow).
    - Cache hits/misses in `OBOTokenCache`.

2.  **Error Transformation**:
    - Ensuring external API errors (e.g., Trello 429) are correctly mapped to our standardized `ErrorResponse` format.
    - Global exception handler verification.

3.  **Resilience (Retry Logic)**:
    - Verifying that the `@async_retry` decorator correctly retries on transient failures and eventually raises the final error.

4.  **Complex Data Mapping**:
    - Connectors like `Trello` and `Graph` that aggregate data from multiple endpoints (e.g., `get_todos` in Trello client).

5.  **Word Document Generation**:
    - Verification of `.docx` creation logic in `connectors/word/` without necessarily checking the binary content (focusing on structure and model mapping).

## Running Tests

Tests should be executable via a simple command:

```bash
# Run all tests
pytest

# Run with coverage report
pytest --cov=connectors tests/
```

## Continuous Integration

Integration of these tests into `azure-pipelines.yml` to ensure every PR is validated before merging.
