"""
Pydantic models for Simplicate API data structures.
These models define request/response schemas for the Simplicate connector endpoints.
"""
from typing import Optional, List, Dict, Any
from datetime import date, datetime
from pydantic import BaseModel, Field
from enum import Enum


class ProjectStatus(str, Enum):
    """Simplicate project status options."""
    ACTIVE = "active"
    COMPLETED = "completed"
    ON_HOLD = "on_hold"
    DRAFT = "draft"


class ProjectType(str, Enum):
    """Simplicate project types."""
    BRANDING = "branding"
    WEB_DEVELOPMENT = "web_development"
    CAMPAIGN = "campaign"
    CONTENT = "content"
    FULL_SERVICE = "full_service"
    OTHER = "other"


class CapacityStatus(str, Enum):
    """Team capacity status indicators."""
    GREEN = "GREEN"   # Available
    YELLOW = "YELLOW"  # Limited availability
    RED = "RED"       # No availability


# --- Client/Organization Models ---

class ClientBase(BaseModel):
    """Base model for Simplicate client/organization."""
    name: str = Field(..., description="Client/organization name")
    email: Optional[str] = Field(None, description="Primary email address")
    phone: Optional[str] = Field(None, description="Phone number")
    website: Optional[str] = Field(None, description="Website URL")
    industry: Optional[str] = Field(None, description="Industry sector")


class ClientCreate(ClientBase):
    """Model for creating a new client."""
    pass


class Client(ClientBase):
    """Full client model with ID and metadata."""
    id: str = Field(..., description="Unique client identifier")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp")
    is_active: bool = Field(True, description="Whether client is active")
    match_confidence: Optional[float] = Field(None, description="Search match confidence (0-1)")

    class Config:
        from_attributes = True


class ClientSearchResult(BaseModel):
    """Search result for client lookup."""
    clients: List[Client]
    total_count: int
    query: str


# --- Project Models ---

class ProjectBase(BaseModel):
    """Base model for Simplicate project."""
    name: str = Field(..., description="Project name")
    project_type: Optional[ProjectType] = Field(None, description="Type of project")
    description: Optional[str] = Field(None, description="Project description")
    start_date: Optional[date] = Field(None, description="Project start date")
    end_date: Optional[date] = Field(None, description="Expected end date")
    budget_hours: Optional[float] = Field(None, description="Budgeted hours")
    budget_amount: Optional[float] = Field(None, description="Budget amount in EUR")


class ProjectCreate(ProjectBase):
    """Model for creating a new project."""
    client_id: str = Field(..., description="ID of the client this project belongs to")
    team_members: Optional[List[str]] = Field(None, description="List of employee IDs")


class Project(ProjectBase):
    """Full project model with ID and metadata."""
    id: str = Field(..., description="Unique project identifier")
    client_id: str = Field(..., description="Associated client ID")
    client_name: Optional[str] = Field(None, description="Client name for display")
    status: ProjectStatus = Field(ProjectStatus.DRAFT, description="Project status")
    hours_logged: Optional[float] = Field(None, description="Total hours logged")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp")
    simplicate_url: Optional[str] = Field(None, description="Direct URL to project in Simplicate")

    class Config:
        from_attributes = True


class ProjectUpdate(BaseModel):
    """Model for updating an existing project."""
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[ProjectStatus] = None
    end_date: Optional[date] = None
    budget_hours: Optional[float] = None
    budget_amount: Optional[float] = None


# --- Hours/Time Tracking Models ---

class HoursEntryBase(BaseModel):
    """Base model for time entry."""
    project_id: str = Field(..., description="Project ID for this time entry")
    employee_id: str = Field(..., description="Employee who logged the hours")
    hours: float = Field(..., ge=0, description="Number of hours logged")
    entry_date: date = Field(..., description="Date of the time entry")
    description: Optional[str] = Field(None, description="Description of work done")
    billable: bool = Field(True, description="Whether hours are billable")


class HoursEntryCreate(HoursEntryBase):
    """Model for creating a new time entry."""
    pass


class HoursEntry(HoursEntryBase):
    """Full time entry model with ID and metadata."""
    id: str = Field(..., description="Unique time entry identifier")
    employee_name: Optional[str] = Field(None, description="Employee name for display")
    project_name: Optional[str] = Field(None, description="Project name for display")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp")

    class Config:
        from_attributes = True


# --- Employee/Capacity Models ---

class Employee(BaseModel):
    """Simplicate employee/team member."""
    id: str = Field(..., description="Unique employee identifier")
    name: str = Field(..., description="Full name")
    email: Optional[str] = Field(None, description="Email address")
    role: Optional[str] = Field(None, description="Job role/title")
    department: Optional[str] = Field(None, description="Department")
    is_active: bool = Field(True, description="Whether employee is active")
    avatar_url: Optional[str] = Field(None, description="Profile picture URL")

    class Config:
        from_attributes = True


class EmployeeCapacity(BaseModel):
    """Capacity information for a single employee."""
    employee_id: str
    employee_name: str
    role: Optional[str]
    total_hours: float = Field(..., description="Total available hours in period")
    booked_hours: float = Field(..., description="Hours already booked")
    available_hours: float = Field(..., description="Remaining available hours")
    utilization_pct: float = Field(..., description="Utilization percentage (0-100)")
    status: CapacityStatus = Field(..., description="Capacity status indicator")


class CapacityCheck(BaseModel):
    """Team capacity check result."""
    start_date: date
    end_date: date
    employees: List[EmployeeCapacity]
    overall_status: CapacityStatus = Field(..., description="Overall team capacity status")
    total_available_hours: float
    total_booked_hours: float
    suggested_team: Optional[List[str]] = Field(None, description="Suggested available team members")


# --- API Response Wrappers ---

class PaginatedResponse(BaseModel):
    """Generic paginated response."""
    data: List[Any]
    total_count: int
    limit: int
    offset: int
    has_more: bool
