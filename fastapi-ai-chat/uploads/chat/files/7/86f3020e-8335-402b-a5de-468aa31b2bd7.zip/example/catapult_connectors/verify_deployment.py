import sys
import os
import importlib
import logging
from typing import List

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(message)s'
)
logger = logging.getLogger(__name__)

def print_header(title: str):
    print(f"\n{'='*len(title)}\n{title}\n{'='*len(title)}")

def check_dependencies():
    print_header("Checking Core Dependencies")
    
    # List of modules to check as requested
    # Note: 'azure.functions' is requested, but might not be in requirements.txt for Container Apps
    required_modules = [
        ('fastapi', 'FastAPI'),
        ('pydantic', 'Pydantic'),
        ('azure.functions', 'Azure Functions (azure-functions)'), 
    ]
    
    for module_name, display_name in required_modules:
        try:
            importlib.import_module(module_name)
            logger.info(f"✅ Found {display_name}")
        except ImportError:
            if module_name == 'azure.functions':
                 logger.warning(f"⚠️  Missing {display_name} - This is expected if running on Container Apps instead of Azure Functions.")
            else:
                 logger.error(f"❌ Missing {display_name} - Please check requirements.txt")

def check_environment_vars():
    print_header("Checking Environment Variables")
    
    # Based on connectors/shared/config.py
    # These are key variables that should likely be present for a functional deployment
    critical_vars = [
        "SIMPLICATE_SUBDOMAIN",
        "SIMPLICATE_API_KEY",
        "SIMPLICATE_API_SECRET",
        "TRELLO_API_KEY",
        "TRELLO_API_TOKEN",
        "AZURE_TENANT_ID",
        "AZURE_CLIENT_ID",
        "AZURE_CLIENT_SECRET",
    ]
    
    missing_count = 0
    for var in critical_vars:
        # Check both the specific var and potential variations if needed, 
        # but BaseSettings usually looks for exact matches (case-insensitive)
        val = os.environ.get(var) or os.environ.get(var.lower())
        
        if val:
            # Mask secret values in output
            masked = val[:4] + "*" * 4 if len(val) > 4 else "****"
            logger.info(f"✅ {var} is set")
        else:
            logger.warning(f"⚠️  {var} is not set")
            missing_count += 1
            
    if missing_count > 0:
        logger.info(f"\nNote: {missing_count} environment variables are missing. This is normal for local development if not using a .env file or local.settings.json, but ensure these are set in the deployment environment.")

def check_imports():
    print_header("Checking Application Imports")
    
    # 1. Check Main Application Module
    # The requirement specifically asks for function_app.py
    try:
        import function_app
        logger.info("✅ Successfully imported function_app.py")
    except ImportError:
        logger.warning("⚠️  Could not import 'function_app'. This matches the requirement to check for it.")
        # Fallback check for main.py (Container Apps)
        try:
            import main
            logger.info("✅ Found 'main.py' instead - This appears to be the entry point for this environment.")
        except ImportError:
            logger.error("❌ Could not import 'main.py' either. Ensure the entry point exists.")
    except Exception as e:
        logger.error(f"❌ Error while importing entry point: {e}")

    # 2. Check Connectors/Routers
    routers = [
        "connectors.simplicate.router",
        "connectors.trello.router",
        "connectors.graph.mail_router",
        "connectors.graph.calendar_router",
        "connectors.graph.sharepoint_router",
        "connectors.word.router",
    ]
    
    for module_path in routers:
        try:
            importlib.import_module(module_path)
            logger.info(f"✅ Successfully imported {module_path.split('.')[-2]} router")
        except ImportError as e:
            logger.error(f"❌ Failed to import {module_path}: {e}")
        except Exception as e:
            logger.error(f"❌ unexpected error importing {module_path}: {e}")

def check_config_loading():
    print_header("Checking Configuration Loading")
    try:
        # Add current directory to path to ensure imports work if running from root
        sys.path.append(os.getcwd())
        
        from connectors.shared.config import Settings
        
        # Attempt to instantiate settings
        # This validates that pydantic can parse the environment/defaults
        settings = Settings()
        
        logger.info(f"✅ Settings object instantiated successfully")
        logger.info(f"   - Environment: {settings.environment}")
        logger.info(f"   - Log Level: {settings.log_level}")
        logger.info(f"   - Auth Mode: {settings.auth_mode}")
        
    except Exception as e:
        logger.error(f"❌ Failed to load Settings: {e}")

if __name__ == "__main__":
    try:
        check_dependencies()
        check_environment_vars()
        check_imports()
        check_config_loading()
        print("\nDeployment verification finished.")
    except KeyboardInterrupt:
        print("\nVerification cancelled.")
    except Exception as e:
        print(f"\nAn unexpected error occurred during verification: {e}")