# Testing Guide

This directory contains the test suite for the Catapult Connectors. We use `pytest` as our testing framework.

## Key Libraries

- **`pytest`**: The primary test runner.
- **`pytest-asyncio`**: Provides support for asynchronous tests (coroutines).
- **`respx`**: Used for mocking HTTP requests, essential for testing API clients without making real network calls.
- **`pytest-mock`**: A thin wrapper around the standard `unittest.mock` library, making it easier to patch objects in tests.

## Directory Structure

The tests are organized into unit and integration tests:

```text
tests/
├── conftest.py              # Global fixtures (e.g., event loop, common mocks)
├── unit/                    # Unit tests (focus on isolated logic)
│   ├── connectors/          # Tests for specific connector logic (clients, models)
│   │   ├── graph/
│   │   ├── simplicate/
│   │   ├── trello/
│   │   └── word/
│   └── shared/              # Tests for shared utilities (auth, config, errors, retry)
└── integration/             # Integration tests (focus on API endpoints and component interaction)
    └── test_api.py          # General API tests
```

## Running Tests

### Prerequisites

Ensure you have the project dependencies installed. The testing libraries are included in `requirements.txt`.

```bash
pip install -r requirements.txt
```

### Common Commands

**Run all tests:**
```bash
pytest
```

**Run unit tests only:**
```bash
pytest tests/unit
```

**Run integration tests only:**
```bash
pytest tests/integration
```

**Run a specific test file:**
```bash
pytest tests/unit/connectors/trello/test_client.py
```

**Run a specific test function:**
```bash
pytest tests/unit/shared/test_retry.py::test_retry_success
```

**Run with verbose output:**
(Useful for seeing which individual tests are passing)
```bash
pytest -v
```

**Run with coverage report:**
```bash
pytest --cov=connectors --cov-report=term-missing
```

## Writing Tests

*   **Async Tests:** Mark async tests with `@pytest.mark.asyncio`.
*   **Mocking:** Use `respx` for HTTP clients and `mocker` (from `pytest-mock`) for other dependencies.
*   **Fixtures:** Check `tests/conftest.py` for available global fixtures.