"""
FastAPI dependencies for authentication and authorization.

Provides token validation for incoming requests from Copilot Studio
custom connectors using OAuth 2.0 / Microsoft Entra ID.
"""
from fastapi import Depends, HTTPException, status, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional
from dataclasses import dataclass
import httpx
import logging
import time
from functools import lru_cache

from jose import jwt, JWTError, jwk
from jose.exceptions import JWKError

from .config import get_settings

logger = logging.getLogger(__name__)

# HTTP Bearer security scheme
security = HTTPBearer(
    scheme_name="OAuth2",
    description="Bearer token from Copilot Studio (Azure AD OAuth 2.0)"
)


@dataclass
class UserContext:
    """
    Validated user context from incoming token.

    Contains the user's identity information and the original token
    needed for On-Behalf-Of (OBO) token exchange.
    """
    token: str  # Original access token for OBO exchange
    user_id: str  # User's Object ID (oid claim)
    tenant_id: str  # Tenant ID (tid claim)
    name: Optional[str] = None  # Display name
    email: Optional[str] = None  # Email / UPN (preferred_username)
    scopes: list[str] = None  # Granted scopes (scp claim)

    def __post_init__(self):
        if self.scopes is None:
            self.scopes = []


class JWKSCache:
    """
    Cache for JSON Web Key Sets (JWKS) used to validate tokens.

    Caches the JWKS to avoid fetching on every request.
    """

    def __init__(self, cache_ttl: int = 3600):
        self._cache: dict[str, dict] = {}
        self._cache_time: dict[str, float] = {}
        self._cache_ttl = cache_ttl

    async def get_jwks(self, tenant_id: str) -> dict:
        """
        Get JWKS for a tenant, fetching if not cached or expired.
        """
        cache_key = tenant_id
        current_time = time.time()

        # Check if cached and not expired
        if cache_key in self._cache:
            if current_time - self._cache_time.get(cache_key, 0) < self._cache_ttl:
                return self._cache[cache_key]

        # Fetch fresh JWKS
        jwks_url = f"https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys"

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(jwks_url, timeout=10.0)
                response.raise_for_status()
                jwks = response.json()

            self._cache[cache_key] = jwks
            self._cache_time[cache_key] = current_time
            logger.debug(f"Fetched JWKS for tenant {tenant_id}")
            return jwks

        except httpx.HTTPError as e:
            logger.error(f"Failed to fetch JWKS: {e}")
            # Return cached value if available (even if expired)
            if cache_key in self._cache:
                logger.warning("Using expired JWKS cache due to fetch failure")
                return self._cache[cache_key]
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Unable to validate token: JWKS fetch failed"
            )


# Singleton JWKS cache
_jwks_cache = JWKSCache()


def _get_signing_key(jwks: dict, token: str) -> dict:
    """
    Extract the correct signing key from JWKS based on token's kid header.
    """
    try:
        unverified_header = jwt.get_unverified_header(token)
        kid = unverified_header.get("kid")

        if not kid:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token missing 'kid' header"
            )

        for key in jwks.get("keys", []):
            if key.get("kid") == kid:
                return key

        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Unable to find signing key for kid: {kid}"
        )

    except JWTError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid token header: {str(e)}"
        )


async def validate_token(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> UserContext:
    """
    Validate incoming Bearer token from Copilot Studio.

    This FastAPI dependency:
    1. Extracts the Bearer token from the Authorization header
    2. Fetches/caches the JWKS for signature validation
    3. Validates the token signature, audience, and issuer
    4. Extracts user claims
    5. Returns a UserContext for use in OBO token exchange

    Raises:
        HTTPException: 401 if token is invalid or missing
    """
    token = credentials.credentials
    settings = get_settings()

    if not settings.is_obo_configured:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="OBO authentication not configured. Check Azure AD settings."
        )

    try:
        # First, decode without verification to get the tenant ID
        unverified_claims = jwt.get_unverified_claims(token)
        tenant_id = unverified_claims.get("tid")

        if not tenant_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token missing tenant ID (tid) claim"
            )

        # Validate tenant (for single-tenant apps)
        if settings.azure_tenant_id and tenant_id != settings.azure_tenant_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token from unauthorized tenant"
            )

        # Fetch JWKS for token validation
        jwks = await _jwks_cache.get_jwks(tenant_id)
        signing_key = _get_signing_key(jwks, token)

        # Build RSA key for verification
        rsa_key = jwk.construct(signing_key)

        # Determine expected audience
        audience = settings.api_audience

        # Determine expected issuers
        issuers = settings.token_issuers
        if not issuers:
            issuers = [
                f"https://sts.windows.net/{tenant_id}/",
                f"https://login.microsoftonline.com/{tenant_id}/v2.0"
            ]

        # Validate and decode token
        claims = jwt.decode(
            token,
            rsa_key.to_pem().decode("utf-8"),
            algorithms=["RS256"],
            audience=audience,
            issuer=issuers,
            options={
                "verify_exp": True,
                "verify_iat": True,
                "verify_nbf": True,
            }
        )

        # Extract user information
        user_id = claims.get("oid")  # Object ID
        if not user_id:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token missing user object ID (oid) claim"
            )

        # Extract scopes (scp claim for v1 tokens, or from roles for v2)
        scopes_str = claims.get("scp", "")
        scopes = scopes_str.split(" ") if scopes_str else []

        return UserContext(
            token=token,
            user_id=user_id,
            tenant_id=tenant_id,
            name=claims.get("name"),
            email=claims.get("preferred_username") or claims.get("upn"),
            scopes=scopes
        )

    except JWTError as e:
        logger.warning(f"Token validation failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Invalid token: {str(e)}",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except JWKError as e:
        logger.error(f"JWK error during token validation: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token signature validation failed",
            headers={"WWW-Authenticate": "Bearer"},
        )


async def get_optional_user_context(
    request: Request,
) -> Optional[UserContext]:
    """
    Optional token validation - returns None if no token provided.

    Useful for endpoints that support both authenticated and anonymous access.
    """
    auth_header = request.headers.get("Authorization")

    if not auth_header or not auth_header.startswith("Bearer "):
        return None

    try:
        token = auth_header.split(" ", 1)[1]
        credentials = HTTPAuthorizationCredentials(
            scheme="Bearer",
            credentials=token
        )
        return await validate_token(credentials)
    except HTTPException:
        return None


# Alias for cleaner import
CurrentUser = UserContext
