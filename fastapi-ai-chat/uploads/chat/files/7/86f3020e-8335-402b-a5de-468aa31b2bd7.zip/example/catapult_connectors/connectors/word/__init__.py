"""Word document connector for creating and manipulating .docx files."""
from .client import WordClient
from .router import router

__all__ = ["WordClient", "router"]
