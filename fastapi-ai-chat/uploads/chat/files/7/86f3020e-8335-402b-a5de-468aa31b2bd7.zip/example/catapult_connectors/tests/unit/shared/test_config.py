import os
import pytest
from connectors.shared.config import Settings, get_settings

@pytest.fixture
def clear_settings_cache():
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()

def test_settings_load_defaults(clear_settings_cache):
    """Test that settings load with default values."""
    settings = get_settings()
    assert settings.environment == "development"
    assert settings.log_level == "INFO"
    assert settings.auth_mode == "obo"

def test_settings_load_from_env(monkeypatch, clear_settings_cache):
    """Test loading settings from environment variables."""
    monkeypatch.setenv("SIMPLICATE_SUBDOMAIN", "test_sub")
    monkeypatch.setenv("SIMPLICATE_API_KEY", "test_key")
    monkeypatch.setenv("SIMPLICATE_API_SECRET", "test_secret")
    
    settings = get_settings()
    
    assert settings.simplicate_subdomain == "test_sub"
    assert settings.simplicate_api_key == "test_key"
    assert settings.simplicate_api_secret == "test_secret"

def test_api_audience_default(monkeypatch, clear_settings_cache):
    """Test default API audience generation."""
    monkeypatch.setenv("AZURE_CLIENT_ID", "client-id")
    monkeypatch.delenv("AZURE_API_AUDIENCE", raising=False)
    
    settings = get_settings()
    assert settings.api_audience == "api://client-id"

def test_api_audience_explicit(monkeypatch, clear_settings_cache):
    """Test explicit API audience setting."""
    monkeypatch.setenv("AZURE_API_AUDIENCE", "custom-audience")
    
    settings = get_settings()
    assert settings.api_audience == "custom-audience"

def test_token_issuers_default(monkeypatch, clear_settings_cache):
    """Test default token issuers generation."""
    monkeypatch.setenv("AZURE_TENANT_ID", "tenant-id")
    monkeypatch.delenv("AZURE_ALLOWED_ISSUERS", raising=False)
    
    settings = get_settings()
    expected_issuer = "https://sts.windows.net/tenant-id/"
    assert expected_issuer in settings.token_issuers

def test_token_issuers_explicit(monkeypatch, clear_settings_cache):
    """Test explicit token issuers setting."""
    monkeypatch.setenv("AZURE_ALLOWED_ISSUERS", "issuer1,issuer2")
    
    settings = get_settings()
    assert settings.token_issuers == ["issuer1", "issuer2"]

def test_is_obo_configured_true(monkeypatch, clear_settings_cache):
    """Test OBO configuration check - valid case."""
    monkeypatch.setenv("AZURE_TENANT_ID", "tid")
    monkeypatch.setenv("AZURE_CLIENT_ID", "cid")
    monkeypatch.setenv("AZURE_CLIENT_SECRET", "secret")
    monkeypatch.delenv("AZURE_API_AUDIENCE", raising=False)
    
    settings = get_settings()
    assert settings.is_obo_configured is True

def test_is_obo_configured_false(monkeypatch, clear_settings_cache):
    """Test OBO configuration check - invalid case."""
    # Ensure at least one required var is missing
    monkeypatch.delenv("AZURE_CLIENT_SECRET", raising=False)
    # We might need to ensure others are unset too if .env is present
    # But Settings checks logic, if secret is empty string, it fails check
    monkeypatch.setenv("AZURE_CLIENT_SECRET", "")
    
    settings = get_settings()
    assert settings.is_obo_configured is False