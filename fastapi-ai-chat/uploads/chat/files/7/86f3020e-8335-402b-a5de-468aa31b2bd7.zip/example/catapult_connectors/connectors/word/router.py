"""
FastAPI router for Word document connector endpoints.
Provides endpoints for creating, modifying, and analyzing Word documents.
Includes SharePoint integration for editing and saving documents directly to SharePoint.
"""
import base64
from datetime import datetime
from fastapi import APIRouter, Body
from typing import Optional

from ..shared.errors import InternalServerError
from ..graph.client import GraphClient
from .client import WordClient
from .models import (
    DocumentCreateRequest, DocumentFromTemplateRequest,
    AppendParagraphRequest, AppendTableRequest, ReplaceTextRequest,
    DocumentResponse, DocumentInfo, OperationResult, ParagraphContent, TableContent,
    # SharePoint integration models
    SharePointSaveRequest, SharePointAppendParagraphRequest,
    SharePointAppendTableRequest, SharePointReplaceTextRequest,
    SharePointFromTemplateRequest, SharePointDocumentResult
)

router = APIRouter()


def get_client() -> WordClient:
    """Get Word client instance."""
    return WordClient()


def get_graph_client() -> GraphClient:
    """Get Graph client instance for SharePoint operations."""
    return GraphClient()


@router.post(
    "/create",
    response_model=DocumentResponse,
    operation_id="word_create_document",
    summary="Create Word document",
    description="""
    Create a new Word document from structured content.

    Supports adding:
    - Title and headings (levels 1-6)
    - Paragraphs with styling (bold, italic, colors)
    - Tables with headers and data
    - Bullet and numbered lists
    - Images (base64 encoded)
    - Page breaks

    Returns the document as a base64 encoded .docx file.
    """
)
async def create_document(
    request: DocumentCreateRequest = Body(..., description="Document content structure")
) -> DocumentResponse:
    """Create a new Word document."""
    client = get_client()

    try:
        doc_bytes = client.create_document(request)
        doc_base64 = base64.b64encode(doc_bytes).decode("utf-8")

        # Generate filename
        title_slug = request.title.replace(" ", "_")[:30] if request.title else "document"
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{title_slug}_{timestamp}.docx"

        return DocumentResponse(
            document_base64=doc_base64,
            filename=filename,
            size_bytes=len(doc_bytes)
        )
    except Exception as e:
        raise InternalServerError(
            message=f"Failed to create document: {str(e)}",
            connector="word"
        )


@router.post(
    "/from-template",
    response_model=DocumentResponse,
    operation_id="word_from_template",
    summary="Create document from template",
    description="""
    Create a Word document by filling in a template with placeholder replacements.

    Upload a .docx template (base64 encoded) containing placeholders like {{name}}, {{date}}, etc.
    Provide a dictionary of replacements to fill in the template.

    Placeholders are replaced in:
    - All paragraphs
    - Table cells
    - Headers and footers
    """
)
async def create_from_template(
    request: DocumentFromTemplateRequest = Body(..., description="Template and replacements")
) -> DocumentResponse:
    """Create document from template."""
    client = get_client()

    try:
        # Decode template
        template_bytes = base64.b64decode(request.template_base64)

        # Process template
        doc_bytes = client.create_from_template(template_bytes, request.replacements)
        doc_base64 = base64.b64encode(doc_bytes).decode("utf-8")

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"document_from_template_{timestamp}.docx"

        return DocumentResponse(
            document_base64=doc_base64,
            filename=filename,
            size_bytes=len(doc_bytes)
        )
    except Exception as e:
        raise InternalServerError(
            message=f"Failed to process template: {str(e)}",
            connector="word"
        )


@router.post(
    "/append-paragraph",
    response_model=DocumentResponse,
    operation_id="word_append_paragraph",
    summary="Append paragraph to document",
    description="Add a new paragraph to the end of an existing Word document."
)
async def append_paragraph(
    request: AppendParagraphRequest = Body(..., description="Document and paragraph to append")
) -> DocumentResponse:
    """Append paragraph to existing document."""
    client = get_client()

    try:
        # Decode document
        doc_bytes = base64.b64decode(request.document_base64)

        # Append paragraph
        modified_bytes = client.append_paragraph(doc_bytes, request.paragraph)
        doc_base64 = base64.b64encode(modified_bytes).decode("utf-8")

        return DocumentResponse(
            document_base64=doc_base64,
            filename="modified_document.docx",
            size_bytes=len(modified_bytes)
        )
    except Exception as e:
        raise InternalServerError(
            message=f"Failed to append paragraph: {str(e)}",
            connector="word"
        )


@router.post(
    "/append-table",
    response_model=DocumentResponse,
    operation_id="word_append_table",
    summary="Append table to document",
    description="Add a new table to the end of an existing Word document."
)
async def append_table(
    request: AppendTableRequest = Body(..., description="Document and table to append")
) -> DocumentResponse:
    """Append table to existing document."""
    client = get_client()

    try:
        # Decode document
        doc_bytes = base64.b64decode(request.document_base64)

        # Append table
        modified_bytes = client.append_table(doc_bytes, request.table)
        doc_base64 = base64.b64encode(modified_bytes).decode("utf-8")

        return DocumentResponse(
            document_base64=doc_base64,
            filename="modified_document.docx",
            size_bytes=len(modified_bytes)
        )
    except Exception as e:
        raise InternalServerError(
            message=f"Failed to append table: {str(e)}",
            connector="word"
        )


@router.post(
    "/replace-text",
    response_model=OperationResult,
    operation_id="word_replace_text",
    summary="Find and replace text",
    description="Find and replace text throughout a Word document, including in tables."
)
async def replace_text(
    request: ReplaceTextRequest = Body(..., description="Document and replacement details")
) -> OperationResult:
    """Find and replace text in document."""
    client = get_client()

    try:
        # Decode document
        doc_bytes = base64.b64decode(request.document_base64)

        # Replace text
        modified_bytes, count = client.replace_text(
            doc_bytes,
            request.find_text,
            request.replace_text,
            request.match_case
        )
        doc_base64 = base64.b64encode(modified_bytes).decode("utf-8")

        return OperationResult(
            success=True,
            message=f"Replaced {count} occurrence(s) of '{request.find_text}'",
            document_base64=doc_base64
        )
    except Exception as e:
        raise InternalServerError(
            message=f"Failed to replace text: {str(e)}",
            connector="word"
        )


@router.post(
    "/analyze",
    response_model=DocumentInfo,
    operation_id="word_analyze_document",
    summary="Analyze document",
    description="Get information about a Word document including paragraph count, table count, word count, and styles used."
)
async def analyze_document(
    document_base64: str = Body(..., embed=True, description="Base64 encoded .docx file")
) -> DocumentInfo:
    """Analyze a Word document."""
    client = get_client()

    try:
        doc_bytes = base64.b64decode(document_base64)
        return client.get_document_info(doc_bytes)
    except Exception as e:
        raise InternalServerError(
            message=f"Failed to analyze document: {str(e)}",
            connector="word"
        )


@router.post(
    "/extract-text",
    operation_id="word_extract_text",
    summary="Extract text from document",
    description="Extract all plain text content from a Word document, including table contents."
)
async def extract_text(
    document_base64: str = Body(..., embed=True, description="Base64 encoded .docx file")
) -> dict:
    """Extract text from a Word document."""
    client = get_client()

    try:
        doc_bytes = base64.b64decode(document_base64)
        text = client.extract_text(doc_bytes)

        return {
            "text": text,
            "character_count": len(text),
            "word_count": len(text.split())
        }
    except Exception as e:
        raise InternalServerError(
            message=f"Failed to extract text: {str(e)}",
            connector="word"
        )


# ==================== SHAREPOINT INTEGRATION ====================

@router.post(
    "/sharepoint/save",
    response_model=SharePointDocumentResult,
    operation_id="word_sharepoint_save",
    summary="Save document to SharePoint",
    description="""
    Create a Word document and save it directly to SharePoint.

    This is an atomic operation that:
    1. Creates the Word document from the provided structure
    2. Uploads it to the specified SharePoint location
    3. Returns the SharePoint item details
    """
)
async def sharepoint_save(
    request: SharePointSaveRequest = Body(..., description="Document and SharePoint location")
) -> SharePointDocumentResult:
    """Create and save a Word document to SharePoint."""
    word_client = get_client()
    graph_client = get_graph_client()

    try:
        # Create the Word document
        doc_bytes = word_client.create_document(request.document)

        # Ensure filename has .docx extension
        file_name = request.file_name
        if not file_name.lower().endswith('.docx'):
            file_name = f"{file_name}.docx"

        # Upload to SharePoint
        drive_item = await graph_client.upload_file(
            drive_id=request.drive_id,
            folder_path=request.folder_path,
            file_name=file_name,
            content=doc_bytes
        )

        return SharePointDocumentResult(
            success=True,
            message=f"Document saved to SharePoint: {file_name}",
            item_id=drive_item.id,
            item_name=drive_item.name,
            web_url=drive_item.web_url,
            size_bytes=drive_item.size
        )
    except Exception as e:
        raise InternalServerError(
            message=f"Failed to save document to SharePoint: {str(e)}",
            connector="word"
        )
    finally:
        await graph_client.close()


@router.post(
    "/sharepoint/append-paragraph",
    response_model=SharePointDocumentResult,
    operation_id="word_sharepoint_append_paragraph",
    summary="Append paragraph to SharePoint document",
    description="""
    Atomically append a paragraph to a Word document stored in SharePoint.

    This operation:
    1. Downloads the document from SharePoint
    2. Appends the paragraph
    3. Uploads the modified document back
    """
)
async def sharepoint_append_paragraph(
    request: SharePointAppendParagraphRequest = Body(..., description="Document location and paragraph")
) -> SharePointDocumentResult:
    """Append paragraph to SharePoint document."""
    word_client = get_client()
    graph_client = get_graph_client()

    try:
        # Download the document
        doc_bytes = await graph_client.download_file(request.drive_id, request.item_id)

        # Get item metadata for the filename
        item = await graph_client.get_item(request.drive_id, request.item_id)

        # Append paragraph
        modified_bytes = word_client.append_paragraph(doc_bytes, request.paragraph)

        # Get parent path for upload
        parent_path = item.parent_path.replace(f"/drives/{request.drive_id}/root:", "") if item.parent_path else ""
        if parent_path.startswith("/"):
            parent_path = parent_path[1:]

        # Upload back to SharePoint
        drive_item = await graph_client.upload_file(
            drive_id=request.drive_id,
            folder_path=parent_path,
            file_name=item.name,
            content=modified_bytes
        )

        return SharePointDocumentResult(
            success=True,
            message="Paragraph appended successfully",
            item_id=drive_item.id,
            item_name=drive_item.name,
            web_url=drive_item.web_url,
            size_bytes=drive_item.size
        )
    except Exception as e:
        raise InternalServerError(
            message=f"Failed to append paragraph: {str(e)}",
            connector="word"
        )
    finally:
        await graph_client.close()


@router.post(
    "/sharepoint/append-table",
    response_model=SharePointDocumentResult,
    operation_id="word_sharepoint_append_table",
    summary="Append table to SharePoint document",
    description="""
    Atomically append a table to a Word document stored in SharePoint.

    This operation:
    1. Downloads the document from SharePoint
    2. Appends the table
    3. Uploads the modified document back
    """
)
async def sharepoint_append_table(
    request: SharePointAppendTableRequest = Body(..., description="Document location and table")
) -> SharePointDocumentResult:
    """Append table to SharePoint document."""
    word_client = get_client()
    graph_client = get_graph_client()

    try:
        # Download the document
        doc_bytes = await graph_client.download_file(request.drive_id, request.item_id)

        # Get item metadata
        item = await graph_client.get_item(request.drive_id, request.item_id)

        # Append table
        modified_bytes = word_client.append_table(doc_bytes, request.table)

        # Get parent path
        parent_path = item.parent_path.replace(f"/drives/{request.drive_id}/root:", "") if item.parent_path else ""
        if parent_path.startswith("/"):
            parent_path = parent_path[1:]

        # Upload back
        drive_item = await graph_client.upload_file(
            drive_id=request.drive_id,
            folder_path=parent_path,
            file_name=item.name,
            content=modified_bytes
        )

        return SharePointDocumentResult(
            success=True,
            message="Table appended successfully",
            item_id=drive_item.id,
            item_name=drive_item.name,
            web_url=drive_item.web_url,
            size_bytes=drive_item.size
        )
    except Exception as e:
        raise InternalServerError(
            message=f"Failed to append table: {str(e)}",
            connector="word"
        )
    finally:
        await graph_client.close()


@router.post(
    "/sharepoint/replace-text",
    response_model=SharePointDocumentResult,
    operation_id="word_sharepoint_replace_text",
    summary="Find and replace text in SharePoint document",
    description="""
    Atomically find and replace text in a Word document stored in SharePoint.

    This operation:
    1. Downloads the document from SharePoint
    2. Performs find/replace operation
    3. Uploads the modified document back
    """
)
async def sharepoint_replace_text(
    request: SharePointReplaceTextRequest = Body(..., description="Document location and replacement details")
) -> SharePointDocumentResult:
    """Find and replace text in SharePoint document."""
    word_client = get_client()
    graph_client = get_graph_client()

    try:
        # Download the document
        doc_bytes = await graph_client.download_file(request.drive_id, request.item_id)

        # Get item metadata
        item = await graph_client.get_item(request.drive_id, request.item_id)

        # Replace text
        modified_bytes, count = word_client.replace_text(
            doc_bytes,
            request.find_text,
            request.replace_text,
            request.match_case
        )

        # Get parent path
        parent_path = item.parent_path.replace(f"/drives/{request.drive_id}/root:", "") if item.parent_path else ""
        if parent_path.startswith("/"):
            parent_path = parent_path[1:]

        # Upload back
        drive_item = await graph_client.upload_file(
            drive_id=request.drive_id,
            folder_path=parent_path,
            file_name=item.name,
            content=modified_bytes
        )

        return SharePointDocumentResult(
            success=True,
            message=f"Replaced {count} occurrence(s) of '{request.find_text}'",
            item_id=drive_item.id,
            item_name=drive_item.name,
            web_url=drive_item.web_url,
            size_bytes=drive_item.size
        )
    except Exception as e:
        raise InternalServerError(
            message=f"Failed to replace text: {str(e)}",
            connector="word"
        )
    finally:
        await graph_client.close()


@router.post(
    "/sharepoint/from-template",
    response_model=SharePointDocumentResult,
    operation_id="word_sharepoint_from_template",
    summary="Create document from SharePoint template",
    description="""
    Fill a Word template stored in SharePoint with placeholder values and save the result.

    This operation:
    1. Downloads the template from SharePoint
    2. Replaces all placeholders (e.g., {{name}}, {{date}})
    3. Saves the filled document to the specified SharePoint location

    The original template is not modified.
    """
)
async def sharepoint_from_template(
    request: SharePointFromTemplateRequest = Body(..., description="Template location, replacements, and output location")
) -> SharePointDocumentResult:
    """Create document from SharePoint template."""
    word_client = get_client()
    graph_client = get_graph_client()

    try:
        # Download the template
        template_bytes = await graph_client.download_file(
            request.template_drive_id,
            request.template_item_id
        )

        # Process template with replacements
        doc_bytes = word_client.create_from_template(template_bytes, request.replacements)

        # Ensure filename has .docx extension
        file_name = request.output_file_name
        if not file_name.lower().endswith('.docx'):
            file_name = f"{file_name}.docx"

        # Upload to output location
        drive_item = await graph_client.upload_file(
            drive_id=request.output_drive_id,
            folder_path=request.output_folder_path,
            file_name=file_name,
            content=doc_bytes
        )

        return SharePointDocumentResult(
            success=True,
            message=f"Document created from template: {file_name}",
            item_id=drive_item.id,
            item_name=drive_item.name,
            web_url=drive_item.web_url,
            size_bytes=drive_item.size
        )
    except Exception as e:
        raise InternalServerError(
            message=f"Failed to create document from template: {str(e)}",
            connector="word"
        )
    finally:
        await graph_client.close()
