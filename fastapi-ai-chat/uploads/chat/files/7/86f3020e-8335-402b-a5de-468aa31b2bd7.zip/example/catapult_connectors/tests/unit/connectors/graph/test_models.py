import pytest
from datetime import datetime
from connectors.graph.models import (
    EmailAddress, MessageCreate, MessageImportance,
    EventCreate, DateTimeTimeZone, ShowAs,
    DriveItem, DriveItemType, AvailabilityResult,
    ScheduleItem
)

def test_email_address_model():
    """Test EmailAddress model validation."""
    # Valid
    email = EmailAddress(address="test@example.com", name="Test User")
    assert email.address == "test@example.com"
    assert email.name == "Test User"
    
    # Missing required field
    with pytest.raises(ValueError):
        EmailAddress(name="Test User")

def test_message_create_model():
    """Test MessageCreate model validation and defaults."""
    msg = MessageCreate(
        subject="Test Subject",
        body_content="Hello World",
        to_recipients=["test@example.com"],
        importance=MessageImportance.HIGH
    )
    assert msg.subject == "Test Subject"
    assert msg.importance == "high"
    assert msg.to_recipients == ["test@example.com"]
    assert msg.body_content_type == "HTML"  # Default
    assert msg.save_to_sent_items is True   # Default
    
    # Test serialization
    data = msg.model_dump()
    assert data["subject"] == "Test Subject"
    assert data["importance"] == "high"

def test_event_create_model():
    """Test EventCreate model validation."""
    event = EventCreate(
        subject="Meeting",
        start=DateTimeTimeZone(date_time="2023-01-01T10:00:00", time_zone="UTC"),
        end=DateTimeTimeZone(date_time="2023-01-01T11:00:00", time_zone="UTC"),
        location="Room 1",
        show_as=ShowAs.FREE
    )
    assert event.subject == "Meeting"
    assert event.start.time_zone == "UTC"
    assert event.location == "Room 1"
    assert event.show_as == "free"
    assert event.is_all_day is False # Default

def test_drive_item_model():
    """Test DriveItem model validation (SharePoint/OneDrive)."""
    item = DriveItem(
        id="123",
        name="test.txt",
        item_type=DriveItemType.FILE,
        size=1024,
        web_url="http://sharepoint/test.txt"
    )
    assert item.id == "123"
    assert item.item_type == "file"
    assert item.size == 1024
    
    folder = DriveItem(
        id="456",
        name="Documents",
        item_type=DriveItemType.FOLDER
    )
    assert folder.item_type == "folder"
    assert folder.size is None

def test_availability_result_model():
    """Test availability result parsing."""
    result = AvailabilityResult(
        schedule_id="user@example.com",
        availability_view="000011110000",
        schedule_items=[
            ScheduleItem(
                status="busy",
                start=DateTimeTimeZone(date_time="2023-01-01T09:00", time_zone="UTC"),
                end=DateTimeTimeZone(date_time="2023-01-01T10:00", time_zone="UTC")
            )
        ]
    )
    assert result.schedule_id == "user@example.com"
    assert len(result.schedule_items) == 1
    assert result.schedule_items[0].status == "busy"