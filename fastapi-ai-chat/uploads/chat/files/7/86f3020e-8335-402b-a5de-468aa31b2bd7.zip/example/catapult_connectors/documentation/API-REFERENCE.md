# API Reference

## Base URL

- **Local Development**: `http://localhost:8000`
- **Production**: `https://[container-app-url]`

## Authentication

Authentication varies by environment and endpoint.

### System Authentication
Service-to-service calls may be protected by Azure Container Apps ingress.

### User Authentication (Graph Connectors)
Endpoints interacting with Microsoft Graph (`/mail`, `/calendar`, `/sharepoint`, `/word/sharepoint/*`) use the On-Behalf-Of (OBO) flow.

You must provide a bearer token from Copilot Studio (Azure AD User Token):

```http
Authorization: Bearer <user_access_token>
```

---

## System Endpoints

### Health Check

```http
GET /
```

Returns basic API status.

**Response:**
```json
{
  "status": "healthy",
  "service": "Catapult Connectors API",
  "version": "1.0.0"
}
```

### Detailed Health Check

```http
GET /health
```

Returns status of all connectors.

---

## Simplicate CRM (`/simplicate`)

### Clients

#### List Clients
```http
GET /simplicate/clients?limit=100&offset=0
```

#### Search Clients
```http
GET /simplicate/clients/search?query=acme
```

#### Get Client
```http
GET /simplicate/clients/{client_id}
```

### Projects

#### List Projects
```http
GET /simplicate/projects?client_id=xxx&status=active&limit=100
```

#### Get Project
```http
GET /simplicate/projects/{project_id}
```

#### Create Project
```http
POST /simplicate/projects
Content-Type: application/json

{
  "name": "Website Redesign",
  "client_id": "client:123",
  "description": "Complete website overhaul",
  "start_date": "2025-01-15",
  "budget_hours": 120
}
```

#### Update Project
```http
PUT /simplicate/projects/{project_id}
Content-Type: application/json

{
  "status": "completed",
  "end_date": "2025-03-15"
}
```

### Time Tracking

#### Get Hours
```http
GET /simplicate/hours?project_id=xxx&start_date=2025-01-01&end_date=2025-01-31
```

#### Log Hours
```http
POST /simplicate/hours
Content-Type: application/json

{
  "project_id": "project:123",
  "employee_id": "employee:456",
  "hours": 4.5,
  "date": "2025-01-15",
  "description": "Development work",
  "billable": true
}
```

### Employees & Capacity

#### List Employees
```http
GET /simplicate/employees?limit=100
```

#### Check Capacity
```http
GET /simplicate/capacity?start_date=2025-01-15&end_date=2025-01-31&roles=developer,designer
```

**Response:**
```json
{
  "start_date": "2025-01-15",
  "end_date": "2025-01-31",
  "overall_status": "GREEN",
  "employees": [
    {
      "employee_id": "emp:123",
      "employee_name": "John Doe",
      "utilization_pct": 65.5,
      "status": "GREEN"
    }
  ],
  "suggested_team": ["John Doe", "Jane Smith"]
}
```

---

## Trello (`/trello`)

### Boards

#### List Boards
```http
GET /trello/boards?filter=open
```

#### Get Board
```http
GET /trello/boards/{board_id}
```

#### Create Board
```http
POST /trello/boards
Content-Type: application/json

{
  "name": "Project Tasks",
  "desc": "Task tracking for the project",
  "default_lists": true
}
```

### Lists

#### Get Lists
```http
GET /trello/boards/{board_id}/lists
```

### Cards

#### Get Cards
```http
GET /trello/boards/{board_id}/cards?list_id=xxx
```

#### Get Card
```http
GET /trello/cards/{card_id}
```

#### Create Card
```http
POST /trello/cards
Content-Type: application/json

{
  "list_id": "list:123",
  "name": "Implement feature X",
  "desc": "Detailed description...",
  "due": "2025-01-20T17:00:00Z",
  "member_ids": ["member:456"]
}
```

#### Update Card
```http
PUT /trello/cards/{card_id}
Content-Type: application/json

{
  "due_complete": true,
  "list_id": "list:done"
}
```

#### Delete Card
```http
DELETE /trello/cards/{card_id}
```

### Todos

#### Get Todos (cards with due dates)
```http
GET /trello/todos?board_ids=id1,id2&member_id=xxx
```

**Response:**
```json
{
  "total_todos": 15,
  "overdue_count": 2,
  "due_today_count": 3,
  "due_this_week_count": 5,
  "cards": [...]
}
```

---

## Outlook Mail (`/mail`)

### Inbox

#### Get Inbox
```http
GET /mail/inbox?user_id=user@domain.com&top=25&skip=0&filter=isRead eq false
```

#### Get Message
```http
GET /mail/messages/{message_id}?user_id=user@domain.com
```

### Send Mail

#### Send Email
```http
POST /mail/send?user_id=user@domain.com
Content-Type: application/json

{
  "subject": "Meeting Tomorrow",
  "body_content": "<p>Hello,</p><p>Reminder about our meeting.</p>",
  "body_content_type": "HTML",
  "to_recipients": ["recipient@domain.com"],
  "cc_recipients": ["cc@domain.com"],
  "importance": "high"
}
```

#### Forward Message
```http
POST /mail/messages/{message_id}/forward?user_id=user@domain.com
Content-Type: application/json

{
  "to_recipients": ["forward@domain.com"],
  "comment": "FYI - see below"
}
```

### Message Management

#### Update Message (mark as read)
```http
PATCH /mail/messages/{message_id}?user_id=user@domain.com
Content-Type: application/json

{
  "is_read": true,
  "categories": ["Important"]
}
```

#### Get Mail Folders
```http
GET /mail/folders?user_id=user@domain.com
```

---

## Outlook Calendar (`/calendar`)

### Events

#### List Events
```http
GET /calendar/events?user_id=user@domain.com&top=25
```

#### Get Calendar View (date range)
```http
GET /calendar/view?user_id=user@domain.com&start_datetime=2025-01-15T00:00:00&end_datetime=2025-01-22T00:00:00
```

#### Get Event
```http
GET /calendar/events/{event_id}?user_id=user@domain.com
```

#### Create Event
```http
POST /calendar/events?user_id=user@domain.com
Content-Type: application/json

{
  "subject": "Team Meeting",
  "start": {
    "date_time": "2025-01-15T14:00:00",
    "time_zone": "Europe/Amsterdam"
  },
  "end": {
    "date_time": "2025-01-15T15:00:00",
    "time_zone": "Europe/Amsterdam"
  },
  "location": "Conference Room A",
  "attendees": ["colleague@domain.com"],
  "is_online_meeting": true,
  "show_as": "busy"
}
```

#### Update Event
```http
PATCH /calendar/events/{event_id}?user_id=user@domain.com
Content-Type: application/json

{
  "subject": "Updated: Team Meeting",
  "location": "Conference Room B"
}
```

#### Delete Event
```http
DELETE /calendar/events/{event_id}?user_id=user@domain.com
```

### Availability

#### Check Availability
```http
POST /calendar/availability
Content-Type: application/json

{
  "schedules": ["user1@domain.com", "user2@domain.com"],
  "start_datetime": "2025-01-15T08:00:00",
  "end_datetime": "2025-01-15T18:00:00",
  "timezone": "Europe/Amsterdam"
}
```

---

## SharePoint/OneDrive (`/sharepoint`)

### Sites

#### List Sites
```http
GET /sharepoint/sites?search=marketing
```

#### Get Drives (Document Libraries)
```http
GET /sharepoint/sites/{site_id}/drives
```

### Files & Folders

#### List Items
```http
GET /sharepoint/drives/{drive_id}/items?folder_path=Projects/ClientA
```

#### Get Item Metadata
```http
GET /sharepoint/drives/{drive_id}/items/{item_id}
```

#### Upload File
```http
POST /sharepoint/upload?drive_id=xxx&folder_path=Documents&file_name=report.pdf
Content-Type: multipart/form-data

[file content]
```

#### Download File
```http
GET /sharepoint/download/{drive_id}/{item_id}
```

#### Create Folder
```http
POST /sharepoint/folders?drive_id=xxx
Content-Type: application/json

{
  "parent_path": "Projects",
  "folder_name": "NewProject"
}
```

### Search

#### Search Files
```http
GET /sharepoint/search?drive_id=xxx&query=report
```

---

## Word Documents (`/word`)

### Create Document

#### Create from Structure
```http
POST /word/create
Content-Type: application/json

{
  "title": "Project Report",
  "sections": [
    {
      "type": "heading",
      "content": {"text": "Executive Summary", "level": 1}
    },
    {
      "type": "paragraph",
      "content": {
        "text": "This report summarizes the project outcomes.",
        "alignment": "justify"
      }
    },
    {
      "type": "table",
      "content": {
        "headers": ["Metric", "Value", "Target"],
        "rows": [
          ["Revenue", "$150,000", "$140,000"],
          ["Users", "5,000", "4,500"]
        ],
        "style": "Light Grid Accent 1"
      }
    },
    {
      "type": "list_bullet",
      "content": {
        "items": ["First point", "Second point", "Third point"]
      }
    },
    {
      "type": "page_break",
      "content": {}
    }
  ]
}
```

**Response:**
```json
{
  "document_base64": "UEsDBBQAAAA...",
  "filename": "Project_Report_20250115_143022.docx",
  "size_bytes": 12456
}
```

### SharePoint Integration

#### Save to SharePoint
Creates a document and saves it directly to a SharePoint library.

```http
POST /word/sharepoint/save
Content-Type: application/json

{
  "document": { ...document_structure... },
  "drive_id": "b!...",
  "folder_path": "Reports/2025",
  "file_name": "Q1_Report.docx"
}
```

#### Append Paragraph (SharePoint)
Appends a paragraph to an existing document in SharePoint.

```http
POST /word/sharepoint/append-paragraph
Content-Type: application/json

{
  "drive_id": "b!...",
  "item_id": "01ABCD...",
  "paragraph": {
    "text": "Appendix: Additional data...",
    "style": "Normal"
  }
}
```

### Document Modification (Base64)

#### Append Paragraph
```http
POST /word/append-paragraph
Content-Type: application/json

{
  "document_base64": "UEsDBBQAAAA...",
  "paragraph": { "text": "New conclusion paragraph." }
}
```

#### Replace Text
```http
POST /word/replace-text
Content-Type: application/json

{
  "document_base64": "UEsDBBQAAAA...",
  "find_text": "{{Company_Name}}",
  "replace_text": "Acme Corp"
}
```

#### Extract Text
```http
POST /word/extract-text
Content-Type: application/json

{
  "document_base64": "UEsDBBQAAAA..."
}
```
}
```

#### Create from Template
```http
POST /word/from-template
Content-Type: application/json

{
  "template_base64": "UEsDBBQAAAA...",
  "replacements": {
    "{{client_name}}": "Acme Corporation",
    "{{project_name}}": "Website Redesign",
    "{{date}}": "January 15, 2025",
    "{{total_amount}}": "$25,000"
  }
}
```

### Modify Document

#### Append Paragraph
```http
POST /word/append-paragraph
Content-Type: application/json

{
  "document_base64": "UEsDBBQAAAA...",
  "paragraph": {
    "text": "Additional content added at the end.",
    "style": "Normal",
    "font_style": {
      "bold": false,
      "italic": true
    }
  }
}
```

#### Append Table
```http
POST /word/append-table
Content-Type: application/json

{
  "document_base64": "UEsDBBQAAAA...",
  "table": {
    "headers": ["Column 1", "Column 2"],
    "rows": [["Data 1", "Data 2"]],
    "style": "Table Grid"
  }
}
```

#### Find and Replace
```http
POST /word/replace-text
Content-Type: application/json

{
  "document_base64": "UEsDBBQAAAA...",
  "find_text": "old text",
  "replace_text": "new text",
  "match_case": true
}
```

### Analyze Document

#### Get Document Info
```http
POST /word/analyze
Content-Type: application/json

{
  "document_base64": "UEsDBBQAAAA..."
}
```

**Response:**
```json
{
  "paragraph_count": 45,
  "table_count": 3,
  "image_count": 2,
  "word_count": 1250,
  "styles_used": ["Normal", "Heading 1", "Heading 2", "List Bullet"]
}
```

#### Extract Text
```http
POST /word/extract-text
Content-Type: application/json

{
  "document_base64": "UEsDBBQAAAA..."
}
```

**Response:**
```json
{
  "text": "Full document text content...",
  "character_count": 8500,
  "word_count": 1250
}
```

---

## Error Responses

All errors follow a consistent format:

```json
{
  "error": "ERROR_CODE",
  "message": "Human-readable error message",
  "details": {
    "additional": "context"
  },
  "connector": "connector_name"
}
```

### Common Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `UNAUTHORIZED` | 401 | Invalid or missing credentials |
| `FORBIDDEN` | 403 | Insufficient permissions |
| `NOT_FOUND` | 404 | Resource not found |
| `RATE_LIMITED` | 429 | Too many requests |
| `CONFIGURATION_ERROR` | 500 | Missing configuration |
| `SERVER_ERROR` | 500 | Internal server error |
