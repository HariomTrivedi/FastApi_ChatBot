import pytest
import io
import base64
from docx import Document
from connectors.word.client import WordClient
from connectors.word.models import (
    DocumentCreateRequest, DocumentSection, ParagraphContent, HeadingContent,
    TableContent, ImageContent, FontStyle, TextAlignment
)

# Helpers for testing
def get_document_from_bytes(doc_bytes: bytes) -> Document:
    """Helper to parse bytes back into a Document object."""
    return Document(io.BytesIO(doc_bytes))

def create_simple_docx_bytes(text="content") -> bytes:
    """Helper to create a simple DOCX file in memory and return bytes."""
    doc = Document()
    doc.add_paragraph(text)
    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()

class TestWordClient:

    @pytest.fixture
    def client(self):
        return WordClient()

    def test_create_document_basic(self, client):
        """Test creating a simple document with a title and paragraph."""
        request = DocumentCreateRequest(
            title="My Test Doc",
            sections=[
                DocumentSection(
                    type="paragraph",
                    content=ParagraphContent(text="Hello World").model_dump()
                )
            ]
        )
        
        doc_bytes = client.create_document(request)
        assert doc_bytes is not None
        
        # Verify content
        doc = get_document_from_bytes(doc_bytes)
        # Title is added as a heading level 0
        assert doc.paragraphs[0].text == "My Test Doc"
        assert doc.paragraphs[0].style.name == "Title"
        
        # Section paragraph
        assert doc.paragraphs[1].text == "Hello World"

    def test_create_document_with_table(self, client):
        """Test creating a document with a table."""
        request = DocumentCreateRequest(
            sections=[
                DocumentSection(
                    type="table",
                    content=TableContent(
                        headers=["H1", "H2"],
                        rows=[["R1C1", "R1C2"], ["R2C1", "R2C2"]]
                    ).model_dump()
                )
            ]
        )
        
        doc_bytes = client.create_document(request)
        doc = get_document_from_bytes(doc_bytes)
        
        assert len(doc.tables) == 1
        table = doc.tables[0]
        
        # Check headers
        assert table.rows[0].cells[0].text == "H1"
        assert table.rows[0].cells[1].text == "H2"
        
        # Check data
        assert table.rows[1].cells[0].text == "R1C1"
        assert table.rows[2].cells[1].text == "R2C2"

    def test_create_from_template(self, client):
        """Test replacing placeholders in a template."""
        # Create a template in memory
        doc = Document()
        doc.add_paragraph("Hello {{name}}, welcome to {{place}}.")
        buffer = io.BytesIO()
        doc.save(buffer)
        template_bytes = buffer.getvalue()
        
        replacements = {
            "{{name}}": "Alice",
            "{{place}}": "Wonderland"
        }
        
        result_bytes = client.create_from_template(template_bytes, replacements)
        doc = get_document_from_bytes(result_bytes)
        
        assert "Hello Alice, welcome to Wonderland." in doc.paragraphs[0].text

    def test_append_paragraph(self, client):
        """Test appending a paragraph to an existing document."""
        initial_bytes = create_simple_docx_bytes("Initial")
        
        content = ParagraphContent(
            text="Appended Text",
            font_style=FontStyle(bold=True)
        )
        
        result_bytes = client.append_paragraph(initial_bytes, content)
        doc = get_document_from_bytes(result_bytes)
        
        assert len(doc.paragraphs) == 2
        assert doc.paragraphs[0].text == "Initial"
        assert doc.paragraphs[1].text == "Appended Text"
        # Check bold - run level
        assert doc.paragraphs[1].runs[0].bold is True

    def test_extract_text(self, client):
        """Test extracting text from a document."""
        doc = Document()
        doc.add_paragraph("Para 1")
        doc.add_paragraph("Para 2")
        table = doc.add_table(rows=1, cols=2)
        table.rows[0].cells[0].text = "Cell 1"
        table.rows[0].cells[1].text = "Cell 2"
        
        buffer = io.BytesIO()
        doc.save(buffer)
        doc_bytes = buffer.getvalue()
        
        text = client.extract_text(doc_bytes)
        
        assert "Para 1" in text
        assert "Para 2" in text
        assert "Cell 1" in text
        assert "Cell 2" in text

    def test_unknown_section_type(self, client, caplog):
        """Test that unknown section types are logged but don't crash."""
        request = DocumentCreateRequest(
            sections=[
                DocumentSection(
                    type="unknown_type",
                    content={"some": "data"}
                )
            ]
        )
        
        # Should not raise exception
        client.create_document(request)
        
        # Check logs
        assert "Unknown section type: unknown_type" in caplog.text

    def test_replace_text_case_sensitive(self, client):
        """Test finding and replacing text."""
        doc = Document()
        doc.add_paragraph("The quick brown fox.")
        buffer = io.BytesIO()
        doc.save(buffer)
        doc_bytes = buffer.getvalue()
        
        new_bytes, count = client.replace_text(doc_bytes, "fox", "dog", match_case=True)
        
        assert count == 1
        doc = get_document_from_bytes(new_bytes)
        assert "The quick brown dog." in doc.paragraphs[0].text

    def test_get_document_info(self, client):
        """Test analyzing document info."""
        doc = Document()
        doc.add_paragraph("One two three")
        doc.add_table(rows=2, cols=2)
        buffer = io.BytesIO()
        doc.save(buffer)
        doc_bytes = buffer.getvalue()
        
        info = client.get_document_info(doc_bytes)
        
        assert info.paragraph_count == 1
        assert info.table_count == 1
        assert info.word_count == 3