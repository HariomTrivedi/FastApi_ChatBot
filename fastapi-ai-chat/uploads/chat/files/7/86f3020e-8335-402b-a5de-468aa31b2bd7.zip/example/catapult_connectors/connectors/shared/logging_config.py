"""
Standardized logging configuration for Catapult Connectors.
Provides JSON formatting for better observability in cloud environments.
"""
import logging
import json
import sys
from datetime import datetime
from typing import Any, Dict

from .config import get_settings


class JsonFormatter(logging.Formatter):
    """
    Formatter that outputs JSON strings.
    """

    def format(self, record: logging.LogRecord) -> str:
        """Format the log record as a JSON string."""
        log_record = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "name": record.name,
            "message": record.getMessage(),
            "service": "catapult-connectors",
            "environment": get_settings().environment,
        }

        # Add exception info if present
        if record.exc_info:
            log_record["exception"] = self.formatException(record.exc_info)

        # Add extra fields from the record
        # This handles explicit 'extra' dicts passed to logger calls
        if hasattr(record, "details"):
             log_record["details"] = record.details
        
        # Merge any other extra attributes that aren't standard LogRecord attributes
        # This is a bit more aggressive but catches other extras
        standard_attrs = {
            'args', 'asctime', 'created', 'exc_info', 'exc_text', 'filename',
            'funcName', 'levelname', 'levelno', 'lineno', 'module',
            'msecs', 'message', 'msg', 'name', 'pathname', 'process',
            'processName', 'relativeCreated', 'stack_info', 'thread', 'threadName',
            'taskName'
        }
        
        for key, value in record.__dict__.items():
            if key not in standard_attrs and key not in log_record:
                # Basic serialization check
                try:
                    json.dumps(value)
                    log_record[key] = value
                except (TypeError, OverflowError):
                    log_record[key] = str(value)

        return json.dumps(log_record)


def configure_logging() -> None:
    """
    Configure the root logger with JSON formatting and level from settings.
    """
    settings = get_settings()
    
    # Get the numeric level from the string setting
    log_level = getattr(logging, settings.log_level.upper(), logging.INFO)
    
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    
    # Remove existing handlers to avoid duplicates (e.g. from Azure Functions default setup)
    # Be careful not to remove handlers if they are critical, but typically we want to override format
    # For Azure Functions, stdout is captured.
    
    # Create console handler
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(log_level)
    
    # Set formatter
    formatter = JsonFormatter()
    handler.setFormatter(formatter)
    
    # Update handlers
    # We clear existing handlers to ensure we control the output format
    if root_logger.handlers:
        root_logger.handlers.clear()
        
    root_logger.addHandler(handler)
    
    # Set levels for some noisy libraries
    logging.getLogger("azure").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)

    logging.info("Logging configured with JSON format", extra={"log_level": settings.log_level})