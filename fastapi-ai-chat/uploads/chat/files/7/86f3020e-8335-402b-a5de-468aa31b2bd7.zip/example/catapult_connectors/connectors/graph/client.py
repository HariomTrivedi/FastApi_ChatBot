"""
Microsoft Graph API client for Mail, Calendar, and SharePoint operations.

Supports two authentication modes:
- On-Behalf-Of (OBO): Per-user access via Copilot Studio tokens
- App-only: Service principal for system-level access (legacy)
"""
import httpx
from typing import Optional, List, Dict, Any
from datetime import datetime, date
import logging

from ..shared.auth import get_graph_auth, GraphAuth
from ..shared.errors import GraphError, ConfigurationError, handle_http_error, NetworkError
from ..shared.retry import async_retry
from .models import (
    # Mail
    Message, MessageCreate, MessageUpdate, MailFolder, EmailAddress,
    DraftCreate, DraftUpdate, MoveMessageRequest, FolderCreate, FolderUpdate,
    # Calendar
    Event, EventCreate, EventUpdate, DateTimeTimeZone, AvailabilityResult, ScheduleItem,
    # SharePoint
    Site, Drive, DriveItem, DriveItemType, SearchResult
)

logger = logging.getLogger(__name__)


class GraphClient:
    """
    HTTP client for Microsoft Graph API.

    Handles all communication with Microsoft Graph including:
    - Outlook Mail operations
    - Calendar event management
    - SharePoint/OneDrive file operations

    Supports two authentication modes:
    - OBO (On-Behalf-Of): Uses user's token from Copilot Studio
    - App-only: Uses service principal (legacy mode)

    For per-user access, pass user_token to constructor or individual methods.
    """

    def __init__(
        self,
        auth: Optional[GraphAuth] = None,
        user_token: Optional[str] = None
    ):
        """
        Initialize Graph client.

        Args:
            auth: GraphAuth instance (optional, uses default if not provided)
            user_token: User's access token from Copilot Studio for OBO flow.
                       When provided, all requests use the user's context.
        """
        self.auth = auth or get_graph_auth()
        self.user_token = user_token
        self._client: Optional[httpx.AsyncClient] = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client with auth headers."""
        if self._client is None:
            if not self.auth.is_configured:
                raise ConfigurationError(
                    connector="graph",
                    message="Microsoft Graph credentials not configured. Set AZURE_TENANT_ID, AZURE_CLIENT_ID, and AZURE_CLIENT_SECRET."
                )
            # Get headers with user token if available (OBO flow)
            headers = await self.auth.get_headers(user_assertion=self.user_token)
            self._client = httpx.AsyncClient(
                base_url=self.auth.base_url,
                headers=headers,
                timeout=30.0
            )
        return self._client

    @async_retry()
    async def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None
    ) -> Any:
        """Make authenticated request to Microsoft Graph."""
        client = await self._get_client()

        try:
            response = await client.request(
                method=method,
                url=endpoint,
                params=params,
                json=json
            )

            if response.status_code >= 400:
                raise handle_http_error(
                    response_status=response.status_code,
                    response_text=response.text,
                    connector="graph",
                    details={"endpoint": endpoint, "method": method}
                )

            return response.json() if response.text else {}

        except httpx.RequestError as e:
            logger.error(f"Graph request failed: {e}")
            raise NetworkError(
                message=f"Failed to connect to Microsoft Graph: {str(e)}",
                connector="graph"
            )

    # ==================== MAIL OPERATIONS ====================

    async def get_inbox(
        self,
        user_id: str,
        top: int = 25,
        skip: int = 0,
        filter: Optional[str] = None
    ) -> List[Message]:
        """
        Get messages from user's inbox.

        Args:
            user_id: User email or ID
            top: Number of messages to return
            skip: Skip first N messages
            filter: OData filter expression
        """
        params = {
            "$top": top,
            "$skip": skip,
            "$orderby": "receivedDateTime desc",
            "$select": "id,subject,bodyPreview,from,toRecipients,receivedDateTime,isRead,importance,hasAttachments,categories,webLink"
        }
        if filter:
            params["$filter"] = filter

        data = await self._request("GET", f"/users/{user_id}/mailFolders/inbox/messages", params=params)

        messages = []
        for item in data.get("value", []):
            from_addr = item.get("from", {}).get("emailAddress", {})
            messages.append(Message(
                id=item.get("id", ""),
                subject=item.get("subject"),
                body_preview=item.get("bodyPreview"),
                from_address=EmailAddress(
                    address=from_addr.get("address", ""),
                    name=from_addr.get("name")
                ) if from_addr else None,
                to_recipients=[
                    EmailAddress(
                        address=r.get("emailAddress", {}).get("address", ""),
                        name=r.get("emailAddress", {}).get("name")
                    )
                    for r in item.get("toRecipients", [])
                ],
                received_datetime=item.get("receivedDateTime"),
                is_read=item.get("isRead", False),
                importance=item.get("importance"),
                has_attachments=item.get("hasAttachments", False),
                categories=item.get("categories"),
                web_link=item.get("webLink")
            ))
        return messages

    async def get_message(self, user_id: str, message_id: str) -> Message:
        """Get a specific message by ID."""
        data = await self._request("GET", f"/users/{user_id}/messages/{message_id}")
        from_addr = data.get("from", {}).get("emailAddress", {})

        return Message(
            id=data.get("id", ""),
            subject=data.get("subject"),
            body_preview=data.get("bodyPreview"),
            from_address=EmailAddress(
                address=from_addr.get("address", ""),
                name=from_addr.get("name")
            ) if from_addr else None,
            received_datetime=data.get("receivedDateTime"),
            sent_datetime=data.get("sentDateTime"),
            is_read=data.get("isRead", False),
            importance=data.get("importance"),
            has_attachments=data.get("hasAttachments", False),
            categories=data.get("categories"),
            web_link=data.get("webLink")
        )

    async def send_mail(self, user_id: str, message: MessageCreate) -> bool:
        """Send an email."""
        payload = {
            "message": {
                "subject": message.subject,
                "body": {
                    "contentType": message.body_content_type,
                    "content": message.body_content
                },
                "toRecipients": [
                    {"emailAddress": {"address": addr}}
                    for addr in message.to_recipients
                ],
                "importance": message.importance.value
            },
            "saveToSentItems": str(message.save_to_sent_items).lower()
        }

        if message.cc_recipients:
            payload["message"]["ccRecipients"] = [
                {"emailAddress": {"address": addr}}
                for addr in message.cc_recipients
            ]

        await self._request("POST", f"/users/{user_id}/sendMail", json=payload)
        return True

    async def forward_message(
        self,
        user_id: str,
        message_id: str,
        to_recipients: List[str],
        comment: Optional[str] = None
    ) -> bool:
        """Forward a message."""
        payload = {
            "toRecipients": [
                {"emailAddress": {"address": addr}}
                for addr in to_recipients
            ]
        }
        if comment:
            payload["comment"] = comment

        await self._request("POST", f"/users/{user_id}/messages/{message_id}/forward", json=payload)
        return True

    async def update_message(
        self,
        user_id: str,
        message_id: str,
        update: MessageUpdate
    ) -> Message:
        """Update a message (read status, categories)."""
        payload = {}
        if update.is_read is not None:
            payload["isRead"] = update.is_read
        if update.categories is not None:
            payload["categories"] = update.categories

        await self._request("PATCH", f"/users/{user_id}/messages/{message_id}", json=payload)
        return await self.get_message(user_id, message_id)

    async def get_mail_folders(self, user_id: str) -> List[MailFolder]:
        """Get user's mail folders."""
        data = await self._request("GET", f"/users/{user_id}/mailFolders")
        return [
            MailFolder(
                id=item.get("id", ""),
                display_name=item.get("displayName", ""),
                parent_folder_id=item.get("parentFolderId"),
                total_item_count=item.get("totalItemCount", 0),
                unread_item_count=item.get("unreadItemCount", 0),
                child_folder_count=item.get("childFolderCount", 0)
            )
            for item in data.get("value", [])
        ]

    # ==================== DRAFT OPERATIONS ====================

    async def get_drafts(
        self,
        user_id: str,
        top: int = 25,
        skip: int = 0
    ) -> List[Message]:
        """
        Get draft messages from user's Drafts folder.

        Args:
            user_id: User email or ID
            top: Number of drafts to return
            skip: Skip first N drafts
        """
        params = {
            "$top": top,
            "$skip": skip,
            "$orderby": "lastModifiedDateTime desc",
            "$select": "id,subject,bodyPreview,toRecipients,lastModifiedDateTime,importance,hasAttachments"
        }

        data = await self._request("GET", f"/users/{user_id}/mailFolders/drafts/messages", params=params)

        messages = []
        for item in data.get("value", []):
            messages.append(Message(
                id=item.get("id", ""),
                subject=item.get("subject"),
                body_preview=item.get("bodyPreview"),
                to_recipients=[
                    EmailAddress(
                        address=r.get("emailAddress", {}).get("address", ""),
                        name=r.get("emailAddress", {}).get("name")
                    )
                    for r in item.get("toRecipients", [])
                ],
                received_datetime=item.get("lastModifiedDateTime"),
                importance=item.get("importance"),
                has_attachments=item.get("hasAttachments", False)
            ))
        return messages

    async def create_draft(self, user_id: str, draft: DraftCreate) -> Message:
        """
        Create a draft email (not sent).

        Args:
            user_id: User email or ID
            draft: Draft content
        """
        payload = {
            "subject": draft.subject,
            "body": {
                "contentType": draft.body_content_type,
                "content": draft.body_content
            },
            "toRecipients": [
                {"emailAddress": {"address": addr}}
                for addr in draft.to_recipients
            ],
            "importance": draft.importance.value
        }

        if draft.cc_recipients:
            payload["ccRecipients"] = [
                {"emailAddress": {"address": addr}}
                for addr in draft.cc_recipients
            ]

        data = await self._request("POST", f"/users/{user_id}/messages", json=payload)
        return await self.get_message(user_id, data.get("id", ""))

    async def update_draft(
        self,
        user_id: str,
        draft_id: str,
        update: DraftUpdate
    ) -> Message:
        """
        Update a draft email.

        Args:
            user_id: User email or ID
            draft_id: Draft message ID
            update: Fields to update
        """
        payload = {}

        if update.subject is not None:
            payload["subject"] = update.subject
        if update.body_content is not None:
            payload["body"] = {
                "contentType": update.body_content_type or "HTML",
                "content": update.body_content
            }
        if update.to_recipients is not None:
            payload["toRecipients"] = [
                {"emailAddress": {"address": addr}}
                for addr in update.to_recipients
            ]
        if update.cc_recipients is not None:
            payload["ccRecipients"] = [
                {"emailAddress": {"address": addr}}
                for addr in update.cc_recipients
            ]

        await self._request("PATCH", f"/users/{user_id}/messages/{draft_id}", json=payload)
        return await self.get_message(user_id, draft_id)

    async def send_draft(self, user_id: str, draft_id: str) -> bool:
        """
        Send a draft email.

        Args:
            user_id: User email or ID
            draft_id: Draft message ID to send
        """
        await self._request("POST", f"/users/{user_id}/messages/{draft_id}/send")
        return True

    # ==================== FOLDER OPERATIONS ====================

    async def create_mail_folder(
        self,
        user_id: str,
        folder: FolderCreate
    ) -> MailFolder:
        """
        Create a new mail folder.

        Args:
            user_id: User email or ID
            folder: Folder creation details
        """
        payload = {"displayName": folder.display_name}

        if folder.parent_folder_id:
            # Create as child of existing folder
            endpoint = f"/users/{user_id}/mailFolders/{folder.parent_folder_id}/childFolders"
        else:
            # Create at root level
            endpoint = f"/users/{user_id}/mailFolders"

        data = await self._request("POST", endpoint, json=payload)

        return MailFolder(
            id=data.get("id", ""),
            display_name=data.get("displayName", ""),
            parent_folder_id=data.get("parentFolderId"),
            total_item_count=data.get("totalItemCount", 0),
            unread_item_count=data.get("unreadItemCount", 0),
            child_folder_count=data.get("childFolderCount", 0)
        )

    async def update_mail_folder(
        self,
        user_id: str,
        folder_id: str,
        update: FolderUpdate
    ) -> MailFolder:
        """
        Update/rename a mail folder.

        Args:
            user_id: User email or ID
            folder_id: Folder ID to update
            update: New folder properties
        """
        payload = {"displayName": update.display_name}

        data = await self._request("PATCH", f"/users/{user_id}/mailFolders/{folder_id}", json=payload)

        return MailFolder(
            id=data.get("id", ""),
            display_name=data.get("displayName", ""),
            parent_folder_id=data.get("parentFolderId"),
            total_item_count=data.get("totalItemCount", 0),
            unread_item_count=data.get("unreadItemCount", 0),
            child_folder_count=data.get("childFolderCount", 0)
        )

    async def delete_mail_folder(self, user_id: str, folder_id: str) -> bool:
        """
        Delete a mail folder.

        Args:
            user_id: User email or ID
            folder_id: Folder ID to delete
        """
        await self._request("DELETE", f"/users/{user_id}/mailFolders/{folder_id}")
        return True

    async def get_child_folders(
        self,
        user_id: str,
        folder_id: str
    ) -> List[MailFolder]:
        """
        Get child folders of a mail folder.

        Args:
            user_id: User email or ID
            folder_id: Parent folder ID
        """
        data = await self._request("GET", f"/users/{user_id}/mailFolders/{folder_id}/childFolders")

        return [
            MailFolder(
                id=item.get("id", ""),
                display_name=item.get("displayName", ""),
                parent_folder_id=item.get("parentFolderId"),
                total_item_count=item.get("totalItemCount", 0),
                unread_item_count=item.get("unreadItemCount", 0),
                child_folder_count=item.get("childFolderCount", 0)
            )
            for item in data.get("value", [])
        ]

    async def move_message(
        self,
        user_id: str,
        message_id: str,
        destination_folder_id: str
    ) -> Message:
        """
        Move a message to another folder.

        Args:
            user_id: User email or ID
            message_id: Message ID to move
            destination_folder_id: Target folder ID
        """
        payload = {"destinationId": destination_folder_id}

        data = await self._request("POST", f"/users/{user_id}/messages/{message_id}/move", json=payload)
        return await self.get_message(user_id, data.get("id", ""))

    # ==================== CALENDAR OPERATIONS ====================

    async def get_events(
        self,
        user_id: str,
        top: int = 25,
        skip: int = 0
    ) -> List[Event]:
        """Get calendar events."""
        params = {
            "$top": top,
            "$skip": skip,
            "$orderby": "start/dateTime",
            "$select": "id,subject,body,start,end,location,organizer,attendees,showAs,isCancelled,isOnlineMeeting,onlineMeetingUrl,webLink"
        }

        data = await self._request("GET", f"/users/{user_id}/calendar/events", params=params)
        return self._parse_events(data.get("value", []))

    async def get_calendar_view(
        self,
        user_id: str,
        start_datetime: str,
        end_datetime: str
    ) -> List[Event]:
        """Get events in a date range."""
        params = {
            "startDateTime": start_datetime,
            "endDateTime": end_datetime,
            "$orderby": "start/dateTime"
        }

        data = await self._request("GET", f"/users/{user_id}/calendarView", params=params)
        return self._parse_events(data.get("value", []))

    async def get_event(self, user_id: str, event_id: str) -> Event:
        """Get a specific event."""
        data = await self._request("GET", f"/users/{user_id}/events/{event_id}")
        return self._parse_events([data])[0]

    async def create_event(self, user_id: str, event: EventCreate) -> Event:
        """Create a calendar event."""
        payload = {
            "subject": event.subject,
            "start": {
                "dateTime": event.start.date_time,
                "timeZone": event.start.time_zone
            },
            "end": {
                "dateTime": event.end.date_time,
                "timeZone": event.end.time_zone
            },
            "isAllDay": event.is_all_day,
            "showAs": event.show_as.value,
            "isOnlineMeeting": event.is_online_meeting
        }

        if event.body_content:
            payload["body"] = {
                "contentType": "HTML",
                "content": event.body_content
            }

        if event.location:
            payload["location"] = {"displayName": event.location}

        if event.attendees:
            payload["attendees"] = [
                {
                    "emailAddress": {"address": addr},
                    "type": "required"
                }
                for addr in event.attendees
            ]

        if event.reminder_minutes:
            payload["reminderMinutesBeforeStart"] = event.reminder_minutes

        data = await self._request("POST", f"/users/{user_id}/calendar/events", json=payload)
        return await self.get_event(user_id, data.get("id", ""))

    async def update_event(
        self,
        user_id: str,
        event_id: str,
        update: EventUpdate
    ) -> Event:
        """Update a calendar event."""
        payload = {}

        if update.subject is not None:
            payload["subject"] = update.subject
        if update.body_content is not None:
            payload["body"] = {"contentType": "HTML", "content": update.body_content}
        if update.start is not None:
            payload["start"] = {"dateTime": update.start.date_time, "timeZone": update.start.time_zone}
        if update.end is not None:
            payload["end"] = {"dateTime": update.end.date_time, "timeZone": update.end.time_zone}
        if update.location is not None:
            payload["location"] = {"displayName": update.location}
        if update.is_cancelled is not None:
            payload["isCancelled"] = update.is_cancelled

        await self._request("PATCH", f"/users/{user_id}/events/{event_id}", json=payload)
        return await self.get_event(user_id, event_id)

    async def delete_event(self, user_id: str, event_id: str) -> bool:
        """Delete a calendar event."""
        await self._request("DELETE", f"/users/{user_id}/events/{event_id}")
        return True

    async def check_availability(
        self,
        schedules: List[str],
        start_datetime: str,
        end_datetime: str,
        timezone: str = "UTC"
    ) -> List[AvailabilityResult]:
        """Check free/busy availability for users."""
        payload = {
            "schedules": schedules,
            "startTime": {
                "dateTime": start_datetime,
                "timeZone": timezone
            },
            "endTime": {
                "dateTime": end_datetime,
                "timeZone": timezone
            },
            "availabilityViewInterval": 30
        }

        data = await self._request("POST", "/me/calendar/getSchedule", json=payload)

        results = []
        for item in data.get("value", []):
            results.append(AvailabilityResult(
                schedule_id=item.get("scheduleId", ""),
                availability_view=item.get("availabilityView", ""),
                schedule_items=[
                    ScheduleItem(
                        status=si.get("status", ""),
                        subject=si.get("subject"),
                        location=si.get("location", {}).get("displayName") if si.get("location") else None,
                        start=DateTimeTimeZone(
                            date_time=si.get("start", {}).get("dateTime", ""),
                            time_zone=si.get("start", {}).get("timeZone", "UTC")
                        ) if si.get("start") else None,
                        end=DateTimeTimeZone(
                            date_time=si.get("end", {}).get("dateTime", ""),
                            time_zone=si.get("end", {}).get("timeZone", "UTC")
                        ) if si.get("end") else None
                    )
                    for si in item.get("scheduleItems", [])
                ]
            ))
        return results

    def _parse_events(self, items: List[dict]) -> List[Event]:
        """Parse event data from Graph API response."""
        events = []
        for item in items:
            organizer = item.get("organizer", {}).get("emailAddress", {})
            events.append(Event(
                id=item.get("id", ""),
                subject=item.get("subject", ""),
                body_content=item.get("body", {}).get("content"),
                start=DateTimeTimeZone(
                    date_time=item.get("start", {}).get("dateTime", ""),
                    time_zone=item.get("start", {}).get("timeZone", "UTC")
                ),
                end=DateTimeTimeZone(
                    date_time=item.get("end", {}).get("dateTime", ""),
                    time_zone=item.get("end", {}).get("timeZone", "UTC")
                ),
                location=item.get("location", {}).get("displayName") if item.get("location") else None,
                is_all_day=item.get("isAllDay", False),
                web_link=item.get("webLink"),
                organizer=EmailAddress(
                    address=organizer.get("address", ""),
                    name=organizer.get("name")
                ) if organizer else None,
                attendees=item.get("attendees"),
                show_as=item.get("showAs"),
                is_cancelled=item.get("isCancelled", False),
                is_online_meeting=item.get("isOnlineMeeting", False),
                online_meeting_url=item.get("onlineMeeting", {}).get("joinUrl") if item.get("onlineMeeting") else None,
                created_datetime=item.get("createdDateTime"),
                last_modified_datetime=item.get("lastModifiedDateTime")
            ))
        return events

    # ==================== SHAREPOINT OPERATIONS ====================

    async def get_sites(self, search: Optional[str] = None) -> List[Site]:
        """Get SharePoint sites."""
        if search:
            data = await self._request("GET", f"/sites?search={search}")
        else:
            data = await self._request("GET", "/sites?$top=100")

        return [
            Site(
                id=item.get("id", ""),
                name=item.get("name", ""),
                display_name=item.get("displayName"),
                web_url=item.get("webUrl", ""),
                created_datetime=item.get("createdDateTime")
            )
            for item in data.get("value", [])
        ]

    async def get_drives(self, site_id: str) -> List[Drive]:
        """Get document libraries for a site."""
        data = await self._request("GET", f"/sites/{site_id}/drives")

        return [
            Drive(
                id=item.get("id", ""),
                name=item.get("name", ""),
                drive_type=item.get("driveType", ""),
                web_url=item.get("webUrl"),
                quota_used=item.get("quota", {}).get("used"),
                quota_total=item.get("quota", {}).get("total")
            )
            for item in data.get("value", [])
        ]

    async def list_items(
        self,
        drive_id: str,
        folder_path: Optional[str] = None
    ) -> List[DriveItem]:
        """List files and folders in a drive or folder."""
        if folder_path:
            endpoint = f"/drives/{drive_id}/root:/{folder_path}:/children"
        else:
            endpoint = f"/drives/{drive_id}/root/children"

        data = await self._request("GET", endpoint)
        return self._parse_drive_items(data.get("value", []))

    async def get_item(self, drive_id: str, item_id: str) -> DriveItem:
        """Get file or folder metadata."""
        data = await self._request("GET", f"/drives/{drive_id}/items/{item_id}")
        return self._parse_drive_items([data])[0]

    async def upload_file(
        self,
        drive_id: str,
        folder_path: str,
        file_name: str,
        content: bytes
    ) -> DriveItem:
        """Upload a file (small files < 4MB)."""
        endpoint = f"/drives/{drive_id}/root:/{folder_path}/{file_name}:/content"
        client = await self._get_client()

        response = await client.put(
            endpoint,
            content=content,
            headers={"Content-Type": "application/octet-stream"}
        )

        if response.status_code >= 400:
            raise GraphError(
                status_code=response.status_code,
                message=f"Failed to upload file: {response.text}"
            )

        return self._parse_drive_items([response.json()])[0]

    async def download_file(self, drive_id: str, item_id: str) -> bytes:
        """Download file content."""
        client = await self._get_client()
        response = await client.get(f"/drives/{drive_id}/items/{item_id}/content")

        if response.status_code >= 400:
            raise GraphError(
                status_code=response.status_code,
                message=f"Failed to download file: {response.text}"
            )

        return response.content

    async def create_folder(
        self,
        drive_id: str,
        parent_path: str,
        folder_name: str
    ) -> DriveItem:
        """Create a new folder."""
        if parent_path:
            endpoint = f"/drives/{drive_id}/root:/{parent_path}:/children"
        else:
            endpoint = f"/drives/{drive_id}/root/children"

        payload = {
            "name": folder_name,
            "folder": {},
            "@microsoft.graph.conflictBehavior": "rename"
        }

        data = await self._request("POST", endpoint, json=payload)
        return self._parse_drive_items([data])[0]

    async def search_files(
        self,
        drive_id: str,
        query: str
    ) -> List[SearchResult]:
        """Search for files in a drive."""
        data = await self._request("GET", f"/drives/{drive_id}/root/search(q='{query}')")

        results = []
        for item in data.get("value", []):
            results.append(SearchResult(
                id=item.get("id", ""),
                name=item.get("name", ""),
                item_type=DriveItemType.FILE if item.get("file") else DriveItemType.FOLDER,
                web_url=item.get("webUrl", ""),
                parent_path=item.get("parentReference", {}).get("path")
            ))
        return results

    def _parse_drive_items(self, items: List[dict]) -> List[DriveItem]:
        """Parse drive items from Graph API response."""
        result = []
        for item in items:
            result.append(DriveItem(
                id=item.get("id", ""),
                name=item.get("name", ""),
                item_type=DriveItemType.FILE if item.get("file") else DriveItemType.FOLDER,
                size=item.get("size"),
                mime_type=item.get("file", {}).get("mimeType") if item.get("file") else None,
                web_url=item.get("webUrl"),
                created_datetime=item.get("createdDateTime"),
                last_modified_datetime=item.get("lastModifiedDateTime"),
                created_by=item.get("createdBy", {}).get("user", {}).get("displayName"),
                last_modified_by=item.get("lastModifiedBy", {}).get("user", {}).get("displayName"),
                parent_path=item.get("parentReference", {}).get("path")
            ))
        return result

    async def close(self):
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None
