import pytest
import respx
from httpx import Response
from datetime import datetime, timedelta
from connectors.trello.client import TrelloClient
from connectors.shared.auth import TrelloAuth
from connectors.shared.errors import UnauthorizedError, NetworkError

# Mock configuration
MOCK_AUTH = TrelloAuth(
    api_key="test-key",
    api_token="test-token"
)

@pytest.fixture
def client():
    """Create a TrelloClient instance with mock auth."""
    return TrelloClient(auth=MOCK_AUTH)

@pytest.mark.asyncio
class TestTrelloClient:

    @respx.mock
    async def test_get_boards(self, client):
        """Verify fetching boards."""
        mock_data = [
            {"id": "b1", "name": "Board 1", "url": "http://board1", "closed": False},
            {"id": "b2", "name": "Board 2", "url": "http://board2", "closed": True}
        ]
        
        respx.get("https://api.trello.com/1/members/me/boards").mock(return_value=Response(200, json=mock_data))
        
        boards = await client.get_boards()
        assert len(boards) == 2
        assert boards[0].name == "Board 1"
        assert boards[1].closed is True

    @respx.mock
    async def test_get_todos_aggregation(self, client):
        """
        Verify complex logic for aggregating todos:
        1. Fetch boards
        2. Fetch lists for each board
        3. Fetch cards for each board
        4. Filter and map cards to board/list names
        5. Calculate overdue/due stats
        """
        # 1. Mock Boards
        boards_data = [
            {"id": "b1", "name": "Work Board", "url": "http://b1"},
            {"id": "b2", "name": "Home Board", "url": "http://b2"}
        ]
        respx.get("https://api.trello.com/1/members/me/boards").mock(return_value=Response(200, json=boards_data))
        
        # 2. Mock individual board fetches (called inside loop)
        respx.get("https://api.trello.com/1/boards/b1").mock(return_value=Response(200, json=boards_data[0]))
        respx.get("https://api.trello.com/1/boards/b2").mock(return_value=Response(200, json=boards_data[1]))

        # 3. Mock Lists
        lists_b1 = [{"id": "l1", "name": "To Do", "pos": 1}, {"id": "l2", "name": "Done", "pos": 2}]
        lists_b2 = [{"id": "l3", "name": "Backlog", "pos": 1}]
        
        respx.get("https://api.trello.com/1/boards/b1/lists").mock(return_value=Response(200, json=lists_b1))
        respx.get("https://api.trello.com/1/boards/b2/lists").mock(return_value=Response(200, json=lists_b2))

        # 4. Mock Cards
        now = datetime.utcnow()
        overdue_date = (now - timedelta(days=1)).isoformat()
        future_date = (now + timedelta(days=2)).isoformat()
        
        cards_b1 = [
            {
                "id": "c1", "name": "Overdue Task", "idList": "l1", "idBoard": "b1", 
                "due": overdue_date, "dueComplete": False, "url": "http://c1"
            },
            {
                "id": "c2", "name": "Completed Task", "idList": "l1", "idBoard": "b1", 
                "due": overdue_date, "dueComplete": True, "url": "http://c2"
            },
            {
                "id": "c3", "name": "No Due Date", "idList": "l1", "idBoard": "b1", 
                "due": None, "url": "http://c3"
            }
        ]
        
        cards_b2 = [
            {
                "id": "c4", "name": "Future Task", "idList": "l3", "idBoard": "b2", 
                "due": future_date, "dueComplete": False, "url": "http://c4"
            }
        ]

        respx.get("https://api.trello.com/1/boards/b1/cards").mock(return_value=Response(200, json=cards_b1))
        respx.get("https://api.trello.com/1/boards/b2/cards").mock(return_value=Response(200, json=cards_b2))

        # Execute
        summary = await client.get_todos()

        # Verify
        # Expected todos:
        # c1 (overdue) -> included
        # c2 (complete) -> included because get_todos filters by 'closed' (archived), not 'dueComplete'.
        # c3 (no due date) -> excluded
        # c4 (future) -> included
        assert summary.total_todos == 3
        assert summary.overdue_count == 1
        
        # Verify c1 details
        t1 = next(t for t in summary.cards if t.id == "c1")
        assert t1.name == "Overdue Task"
        assert t1.list_name == "To Do"
        assert t1.board_name == "Work Board"
        assert t1.is_overdue is True

        # Verify c4 details
        t2 = next(t for t in summary.cards if t.id == "c4")
        assert t2.name == "Future Task"
        assert t2.list_name == "Backlog"
        assert t2.board_name == "Home Board"
        assert t2.is_overdue is False

    @respx.mock
    async def test_get_todos_filtered_by_member(self, client):
        """Verify filtering todos by member ID."""
        # Setup minimal mocks for one board
        boards_data = [{"id": "b1", "name": "B1", "url": "u"}]
        respx.get("https://api.trello.com/1/members/me/boards").mock(return_value=Response(200, json=boards_data))
        respx.get("https://api.trello.com/1/boards/b1").mock(return_value=Response(200, json=boards_data[0]))
        respx.get("https://api.trello.com/1/boards/b1/lists").mock(return_value=Response(200, json=[]))
        
        future_date = (datetime.utcnow() + timedelta(days=1)).isoformat()
        cards = [
            {"id": "c1", "name": "My Task", "idMembers": ["me"], "due": future_date, "url": "u"},
            {"id": "c2", "name": "Other Task", "idMembers": ["other"], "due": future_date, "url": "u"}
        ]
        respx.get("https://api.trello.com/1/boards/b1/cards").mock(return_value=Response(200, json=cards))

        # Test filtering
        summary = await client.get_todos(member_id="me")
        
        assert len(summary.cards) == 1
        assert summary.cards[0].name == "My Task"

    @respx.mock
    async def test_auth_error(self, client):
        """Verify 401 raises UnauthorizedError."""
        respx.get("https://api.trello.com/1/members/me/boards").mock(return_value=Response(401, text="Unauthorized"))
        
        with pytest.raises(UnauthorizedError):
            await client.get_boards()