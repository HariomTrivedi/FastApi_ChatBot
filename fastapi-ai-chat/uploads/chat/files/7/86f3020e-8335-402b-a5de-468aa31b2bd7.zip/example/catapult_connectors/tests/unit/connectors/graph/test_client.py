import pytest
import respx
from httpx import Response
from unittest.mock import AsyncMock, Mock

from connectors.graph.client import GraphClient
from connectors.graph.models import (
    MessageCreate, EventCreate, DateTimeTimeZone,
    MessageImportance, ShowAs, EmailAddress
)
from connectors.shared.errors import GraphError, NetworkError, NotFoundError, InternalServerError
from connectors.shared.auth import GraphAuth

@pytest.fixture
def mock_auth():
    """Mock GraphAuth to avoid real credential checks."""
    auth = Mock(spec=GraphAuth)
    auth.is_configured = True
    auth.base_url = "https://graph.microsoft.com/v1.0"
    auth.get_headers = AsyncMock(return_value={"Authorization": "Bearer mock_token"})
    return auth

@pytest.fixture
def client(mock_auth):
    """Create GraphClient with mock auth."""
    return GraphClient(auth=mock_auth, user_token="mock_user_token")

@pytest.mark.asyncio
async def test_send_mail(client, respx_mock):
    """Test sending an email."""
    user_id = "test@example.com"
    endpoint = f"https://graph.microsoft.com/v1.0/users/{user_id}/sendMail"
    
    # Mock the API response
    respx_mock.post(endpoint).mock(return_value=Response(202))
    
    message = MessageCreate(
        subject="Test Email",
        body_content="Hello",
        to_recipients=["recipient@example.com"],
        importance=MessageImportance.NORMAL
    )
    
    result = await client.send_mail(user_id, message)
    
    assert result is True
    assert respx_mock.calls.call_count == 1
    request = respx_mock.calls.last.request
    assert request.method == "POST"
    
    # Verify payload
    import json
    payload = json.loads(request.content)
    assert payload["message"]["subject"] == "Test Email"
    assert payload["message"]["toRecipients"][0]["emailAddress"]["address"] == "recipient@example.com"

@pytest.mark.asyncio
async def test_create_event(client, respx_mock):
    """Test creating a calendar event."""
    user_id = "test@example.com"
    endpoint = f"https://graph.microsoft.com/v1.0/users/{user_id}/calendar/events"
    
    # Mock response data
    response_data = {
        "id": "event_123",
        "subject": "Team Meeting",
        "start": {"dateTime": "2023-01-01T10:00:00", "timeZone": "UTC"},
        "end": {"dateTime": "2023-01-01T11:00:00", "timeZone": "UTC"},
        "location": {"displayName": "Room A"}
    }
    
    # Mock both the create call and the subsequent get call (if any - GraphClient.create_event calls get_event internally)
    # The implementation returns: return await self.get_event(user_id, data.get("id", ""))
    
    respx_mock.post(endpoint).mock(return_value=Response(201, json=response_data))
    respx_mock.get(f"https://graph.microsoft.com/v1.0/users/{user_id}/events/event_123").mock(
        return_value=Response(200, json=response_data)
    )
    
    event = EventCreate(
        subject="Team Meeting",
        start=DateTimeTimeZone(date_time="2023-01-01T10:00:00", time_zone="UTC"),
        end=DateTimeTimeZone(date_time="2023-01-01T11:00:00", time_zone="UTC"),
        location="Room A",
        show_as=ShowAs.BUSY
    )
    
    result = await client.create_event(user_id, event)
    
    assert result.id == "event_123"
    assert result.subject == "Team Meeting"
    assert result.location == "Room A"

@pytest.mark.asyncio
async def test_search_files(client, respx_mock):
    """Test searching for files in SharePoint/OneDrive."""
    drive_id = "drive_123"
    query = "contract"
    # Note: URL encoding in respx might need care. The client does: f"/drives/{drive_id}/root/search(q='{query}')"
    # which results in .../search(q='contract')
    endpoint = f"https://graph.microsoft.com/v1.0/drives/{drive_id}/root/search(q='{query}')"
    
    response_data = {
        "value": [
            {
                "id": "file_1",
                "name": "Contract.pdf",
                "webUrl": "http://site/Contract.pdf",
                "file": {"mimeType": "application/pdf"}
            }
        ]
    }
    
    respx_mock.get(endpoint).mock(return_value=Response(200, json=response_data))
    
    results = await client.search_files(drive_id, query)
    
    assert len(results) == 1
    assert results[0].name == "Contract.pdf"
    assert results[0].item_type == "file"

@pytest.mark.asyncio
async def test_error_handling_4xx(client, respx_mock):
    """Test error handling for 4xx responses."""
    user_id = "test@example.com"
    message_id = "msg_123"
    endpoint = f"https://graph.microsoft.com/v1.0/users/{user_id}/messages/{message_id}"
    
    respx_mock.get(endpoint).mock(return_value=Response(404, json={"error": "Not Found"}))
    
    with pytest.raises(NotFoundError) as excinfo:
        await client.get_message(user_id, message_id)
    
    assert excinfo.value.status_code == 404

@pytest.mark.asyncio
async def test_error_handling_5xx(client, respx_mock):
    """Test error handling for 5xx responses (should trigger retry logic if configured, or raise GraphError)."""
    # The client uses @async_retry decorator.
    # To test the exception raised after retries, we mock it returning 500 consistently.
    
    user_id = "test@example.com"
    endpoint = f"https://graph.microsoft.com/v1.0/users/{user_id}/mailFolders"
    
    respx_mock.get(endpoint).mock(return_value=Response(500, text="Internal Server Error"))
    
    # Depending on retry configuration, this might take a while or we can mock sleep.
    # For unit test speed, we might want to check if retries happen or if it just fails eventually.
    # The default retry config might have delays.
    # Ideally, we should patch the retry mechanism or just accept it takes a moment (if backoff is small)
    # Or, we can assert that GraphError is raised eventually.
    
    with pytest.raises(InternalServerError) as excinfo:
        await client.get_mail_folders(user_id)
        
    assert excinfo.value.status_code == 500

@pytest.mark.asyncio
async def test_get_inbox_filter(client, respx_mock):
    """Test get_inbox with filter parameters."""
    user_id = "test@example.com"
    endpoint = f"https://graph.microsoft.com/v1.0/users/{user_id}/mailFolders/inbox/messages"
    
    respx_mock.get(endpoint).mock(return_value=Response(200, json={"value": []}))
    
    await client.get_inbox(user_id, filter="isRead eq false")
    
    request = respx_mock.calls.last.request
    assert "filter=isRead+eq+false" in str(request.url) or "filter=isRead%20eq%20false" in str(request.url)
