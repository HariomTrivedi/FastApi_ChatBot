"""
Retry mechanism for handling transient failures in API connectors.
Implements exponential backoff with jitter.
"""
import asyncio
import functools
import logging
import random
from typing import Callable, Type, Tuple, Optional, Any

from .config import get_settings
from .errors import (
    NetworkError,
    TooManyRequestsError,
    ServiceUnavailableError,
    InternalServerError,
)

logger = logging.getLogger(__name__)


def async_retry(
    max_retries: Optional[int] = None,
    delay: Optional[float] = None,
    backoff: Optional[float] = None,
    jitter: Optional[float] = None,
    exceptions: Tuple[Type[Exception], ...] = (
        NetworkError,
        TooManyRequestsError,
        ServiceUnavailableError,
        InternalServerError,
    ),
) -> Callable:
    """
    Decorator for async functions to retry on specific exceptions.

    Args:
        max_retries: Maximum number of retries (default from config).
        delay: Initial delay in seconds (default from config).
        backoff: Multiplier for exponential backoff (default from config).
        jitter: Random jitter factor (default from config).
        exceptions: Tuple of exceptions to catch and retry.
    """
    settings = get_settings()
    
    _max_retries = max_retries if max_retries is not None else settings.default_max_retries
    _delay = delay if delay is not None else settings.default_retry_delay
    _backoff = backoff if backoff is not None else settings.default_retry_backoff
    _jitter = jitter if jitter is not None else settings.default_retry_jitter

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            current_delay = _delay
            last_exception = None
            
            for attempt in range(1, _max_retries + 2):
                try:
                    return await func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    
                    if attempt > _max_retries:
                        logger.error(
                            f"Max retries reached for {func.__name__}. Last error: {e}",
                            extra={"attempt": attempt, "max_retries": _max_retries}
                        )
                        raise

                    # Calculate delay with jitter
                    # delay * backoff^(attempt-1) * (1 + random(-jitter, jitter))
                    jitter_factor = 1 + random.uniform(-_jitter, _jitter)
                    sleep_time = current_delay * jitter_factor
                    
                    logger.warning(
                        f"Retry attempt {attempt}/{_max_retries} for {func.__name__} due to {type(e).__name__}: {e}. Sleeping for {sleep_time:.2f}s",
                        extra={
                            "attempt": attempt,
                            "max_retries": _max_retries,
                            "sleep_time": sleep_time,
                            "error": str(e)
                        }
                    )
                    
                    await asyncio.sleep(sleep_time)
                    current_delay *= _backoff
            
            # Should not be reached if exceptions are raised correctly above
            if last_exception:
                raise last_exception
                
        return wrapper
    return decorator