"""
Authentication utilities for external API connections.

Supports:
- Simplicate CRM (API Key + Secret)
- Trello (API Key + Token)
- Microsoft Graph (OAuth 2.0 with On-Behalf-Of flow for per-user access)
"""
import os
import time
import logging
from typing import Optional, Dict, Any
from azure.identity import ClientSecretCredential, DefaultAzureCredential
from functools import lru_cache
import httpx

from .config import get_settings

logger = logging.getLogger(__name__)


class SimplicateAuth:
    """
    API Key + Secret authentication for Simplicate CRM.

    Simplicate uses custom headers for authentication:
    - Authentication-Key: API key
    - Authentication-Secret: API secret
    """

    def __init__(
        self,
        subdomain: Optional[str] = None,
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None
    ):
        self.subdomain = subdomain or os.environ.get("SIMPLICATE_SUBDOMAIN", "")
        self.api_key = api_key or os.environ.get("SIMPLICATE_API_KEY", "")
        self.api_secret = api_secret or os.environ.get("SIMPLICATE_API_SECRET", "")

    @property
    def is_configured(self) -> bool:
        """Check if all required credentials are set."""
        return bool(self.subdomain and self.api_key and self.api_secret)

    @property
    def headers(self) -> Dict[str, str]:
        """Get authentication headers for Simplicate API requests."""
        return {
            "Authentication-Key": self.api_key,
            "Authentication-Secret": self.api_secret,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    @property
    def base_url(self) -> str:
        """Get the base URL for Simplicate API."""
        return f"https://{self.subdomain}.simplicate.nl/api/v2"


class TrelloAuth:
    """
    API Key + Token authentication for Trello.

    Trello uses query parameters for authentication:
    - key: API key
    - token: API token (obtained via OAuth or manual generation)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        api_token: Optional[str] = None
    ):
        self.api_key = api_key or os.environ.get("TRELLO_API_KEY", "")
        self.api_token = api_token or os.environ.get("TRELLO_API_TOKEN", "")

    @property
    def is_configured(self) -> bool:
        """Check if all required credentials are set."""
        return bool(self.api_key and self.api_token)

    @property
    def params(self) -> Dict[str, str]:
        """Get authentication query parameters for Trello API requests."""
        return {
            "key": self.api_key,
            "token": self.api_token,
        }

    @property
    def base_url(self) -> str:
        """Get the base URL for Trello API."""
        return "https://api.trello.com/1"


class OBOTokenCache:
    """
    Cache for On-Behalf-Of tokens to avoid repeated token exchanges.

    Caches tokens per user with TTL based on token expiration.
    """

    def __init__(self, default_ttl: int = 3300):  # 55 minutes
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._default_ttl = default_ttl

    def get(self, cache_key: str) -> Optional[str]:
        """Get cached token if valid."""
        if cache_key not in self._cache:
            return None

        entry = self._cache[cache_key]
        if time.time() >= entry["expires_at"]:
            del self._cache[cache_key]
            return None

        return entry["token"]

    def set(self, cache_key: str, token: str, expires_in: int = None):
        """Cache a token with TTL."""
        ttl = expires_in if expires_in else self._default_ttl
        self._cache[cache_key] = {
            "token": token,
            "expires_at": time.time() + ttl - 60  # 1 minute buffer
        }

    def invalidate(self, cache_key: str):
        """Remove a token from cache."""
        self._cache.pop(cache_key, None)

    def clear(self):
        """Clear all cached tokens."""
        self._cache.clear()


class GraphAuth:
    """
    OAuth 2.0 authentication for Microsoft Graph API.

    Supports two modes:
    1. On-Behalf-Of (OBO) flow - for per-user access via Copilot Studio
    2. App-only (service principal) - for system-level access (legacy)

    OBO flow exchanges a user's access token (from Copilot Studio) for a
    Microsoft Graph token, allowing the API to act on behalf of the user.
    """

    # Default Graph scopes for OBO exchange
    DEFAULT_GRAPH_SCOPES = [
        "https://graph.microsoft.com/Mail.Read",
        "https://graph.microsoft.com/Mail.Send",
        "https://graph.microsoft.com/Calendars.ReadWrite",
        "https://graph.microsoft.com/Files.Read.All",
        "https://graph.microsoft.com/Sites.Read.All",
        "https://graph.microsoft.com/User.Read",
    ]

    # App-only scope
    APP_ONLY_SCOPE = ["https://graph.microsoft.com/.default"]

    def __init__(
        self,
        tenant_id: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None
    ):
        settings = get_settings()
        self.tenant_id = tenant_id or settings.azure_tenant_id
        self.client_id = client_id or settings.azure_client_id
        self.client_secret = client_secret or settings.azure_client_secret
        self._credential = None
        self._obo_cache = OBOTokenCache()

    @property
    def is_configured(self) -> bool:
        """Check if all required credentials are set."""
        return bool(self.tenant_id and self.client_id and self.client_secret)

    @property
    def credential(self) -> ClientSecretCredential:
        """Get Azure credential for app-only authentication (legacy)."""
        if self._credential is None:
            if self.client_secret:
                self._credential = ClientSecretCredential(
                    tenant_id=self.tenant_id,
                    client_id=self.client_id,
                    client_secret=self.client_secret
                )
            else:
                # Fallback to DefaultAzureCredential for local development
                self._credential = DefaultAzureCredential()
        return self._credential

    async def get_token(self) -> str:
        """
        Get access token for Microsoft Graph API (app-only mode).

        This is the legacy method for service principal authentication.
        For per-user access, use get_user_graph_token() instead.
        """
        token = self.credential.get_token(*self.APP_ONLY_SCOPE)
        return token.token

    async def get_user_graph_token(
        self,
        user_assertion: str,
        scopes: list[str] = None,
        user_id: str = None
    ) -> str:
        """
        Exchange user token for Microsoft Graph token via OBO flow.

        This method:
        1. Takes the access token from Copilot Studio (user_assertion)
        2. Exchanges it with Azure AD for a Microsoft Graph token
        3. Caches the result to avoid repeated exchanges

        Args:
            user_assertion: Access token received from Copilot Studio
            scopes: Graph API scopes needed (defaults to common scopes)
            user_id: User's object ID for caching (optional)

        Returns:
            Access token for Microsoft Graph API with user's context

        Raises:
            Exception: If OBO token exchange fails
        """
        if scopes is None:
            scopes = self.DEFAULT_GRAPH_SCOPES

        # Check cache first (using assertion hash + scopes as key)
        scope_key = ",".join(sorted(scopes))
        cache_key = f"{hash(user_assertion)}:{scope_key}"

        cached_token = self._obo_cache.get(cache_key)
        if cached_token:
            logger.debug("Using cached OBO token")
            return cached_token

        # Perform OBO token exchange
        token_url = f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token"

        data = {
            "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "assertion": user_assertion,
            "scope": " ".join(scopes),
            "requested_token_use": "on_behalf_of",
        }

        async with httpx.AsyncClient() as client:
            response = await client.post(
                token_url,
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=30.0
            )

            if response.status_code != 200:
                error_data = response.json()
                error_desc = error_data.get("error_description", "Unknown error")
                error_code = error_data.get("error", "unknown")

                logger.error(f"OBO token exchange failed: {error_code} - {error_desc}")

                # Provide helpful error messages
                if "AADSTS65001" in error_desc:
                    raise Exception(
                        "User consent required. The user must grant permission to "
                        "access Microsoft Graph resources. This usually happens on first use."
                    )
                elif "AADSTS50013" in error_desc:
                    raise Exception(
                        "Invalid assertion. The incoming token may have expired or "
                        "the audience doesn't match the API app registration."
                    )
                elif "AADSTS700024" in error_desc:
                    raise Exception(
                        "Client assertion validation failed. Check that the API app "
                        "registration has the correct permissions and admin consent."
                    )

                raise Exception(f"OBO token exchange failed: {error_code} - {error_desc}")

            token_data = response.json()
            access_token = token_data["access_token"]
            expires_in = token_data.get("expires_in", 3600)

            # Cache the token
            self._obo_cache.set(cache_key, access_token, expires_in)

            logger.debug(f"OBO token exchange successful, expires in {expires_in}s")
            return access_token

    async def get_headers(self, user_assertion: str = None) -> Dict[str, str]:
        """
        Get authorization headers for Microsoft Graph API requests.

        Args:
            user_assertion: If provided, uses OBO flow for user context.
                           If None, uses app-only authentication.

        Returns:
            Dictionary with Authorization header and content type headers
        """
        if user_assertion:
            token = await self.get_user_graph_token(user_assertion)
        else:
            token = await self.get_token()

        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    @property
    def base_url(self) -> str:
        """Get the base URL for Microsoft Graph API."""
        return "https://graph.microsoft.com/v1.0"

    def clear_cache(self):
        """Clear the OBO token cache."""
        self._obo_cache.clear()


# Cached auth instances
@lru_cache()
def get_simplicate_auth() -> SimplicateAuth:
    """Get cached Simplicate auth instance."""
    return SimplicateAuth()


@lru_cache()
def get_trello_auth() -> TrelloAuth:
    """Get cached Trello auth instance."""
    return TrelloAuth()


@lru_cache()
def get_graph_auth() -> GraphAuth:
    """Get cached Graph auth instance."""
    return GraphAuth()
