import pytest
from fastapi.testclient import TestClient
from unittest.mock import MagicMock, patch, AsyncMock
from datetime import datetime

from main import app
from connectors.shared.dependencies import validate_token, UserContext
from connectors.graph.models import Message, Event, SearchResult, DriveItem, DateTimeTimeZone, EmailAddress
from connectors.simplicate.models import Employee, HoursEntry, CapacityCheck, CapacityStatus
from connectors.trello.models import TodoSummary, TodoCard
from connectors.word.models import DocumentResponse

# --- Fixtures ---

@pytest.fixture
def mock_user_context():
    return UserContext(
        token="mock_token",
        user_id="mock_user_id",
        tenant_id="mock_tenant_id",
        name="Mock User",
        email="mock@example.com",
        scopes=["User.Read"]
    )

@pytest.fixture
def client(mock_user_context):
    # Override auth dependency to bypass validation
    app.dependency_overrides[validate_token] = lambda: mock_user_context
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides = {}

# --- Graph / Mail Tests ---

def test_graph_send_mail(client):
    with patch("connectors.graph.mail_router.GraphClient") as MockClient:
        # Configure Mock
        mock_instance = MockClient.return_value
        mock_instance.send_mail = AsyncMock(return_value=True)
        mock_instance.close = AsyncMock()

        payload = {
            "subject": "Integration Test Email",
            "body_content": "This is a test email.",
            "to_recipients": ["test@example.com"],
            "importance": "normal"
        }

        response = client.post("/mail/send", json=payload)

        assert response.status_code == 200
        assert response.json() == {"success": True, "message": "Email sent successfully"}
        mock_instance.send_mail.assert_called_once()

# --- Graph / Calendar Tests ---

def test_graph_create_event(client):
    with patch("connectors.graph.calendar_router.GraphClient") as MockClient:
        mock_instance = MockClient.return_value
        
        # Mock response object
        mock_event = Event(
            id="evt_123",
            subject="Integration Test Event",
            start=DateTimeTimeZone(date_time="2025-01-01T10:00:00", time_zone="UTC"),
            end=DateTimeTimeZone(date_time="2025-01-01T11:00:00", time_zone="UTC")
        )
        mock_instance.create_event = AsyncMock(return_value=mock_event)
        mock_instance.close = AsyncMock()

        payload = {
            "subject": "Integration Test Event",
            "start": {
                "date_time": "2025-01-01T10:00:00",
                "time_zone": "UTC"
            },
            "end": {
                "date_time": "2025-01-01T11:00:00",
                "time_zone": "UTC"
            }
        }

        response = client.post("/calendar/events", json=payload)

        assert response.status_code == 200
        data = response.json()
        assert data["id"] == "evt_123"
        assert data["subject"] == "Integration Test Event"
        mock_instance.create_event.assert_called_once()

# --- Graph / SharePoint Tests ---

def test_graph_sharepoint_search(client):
    with patch("connectors.graph.sharepoint_router.GraphClient") as MockClient:
        mock_instance = MockClient.return_value
        
        mock_results = [
            SearchResult(
                id="item_1",
                name="Test Document.docx",
                item_type="file",
                web_url="https://sharepoint.com/doc",
                snippet="Test snippet"
            )
        ]
        mock_instance.search_files = AsyncMock(return_value=mock_results)
        mock_instance.close = AsyncMock()

        response = client.get("/sharepoint/search", params={"drive_id": "drive_123", "query": "Test"})

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["name"] == "Test Document.docx"
        mock_instance.search_files.assert_called_once()

# --- Simplicate Tests ---

def test_simplicate_get_employees(client):
    with patch("connectors.simplicate.router.SimplicateClient") as MockClient:
        mock_instance = MockClient.return_value
        
        mock_employees = [
            Employee(
                id="emp_1",
                name="John Doe",
                email="john@example.com",
                is_active=True
            )
        ]
        mock_instance.get_employees = AsyncMock(return_value=mock_employees)
        mock_instance.close = AsyncMock()

        response = client.get("/simplicate/employees")

        assert response.status_code == 200
        data = response.json()
        assert len(data) == 1
        assert data[0]["name"] == "John Doe"
        mock_instance.get_employees.assert_called_once()

def test_simplicate_log_hours(client):
    with patch("connectors.simplicate.router.SimplicateClient") as MockClient:
        mock_instance = MockClient.return_value
        
        mock_entry = HoursEntry(
            id="hours_1",
            project_id="proj_1",
            employee_id="emp_1",
            hours=4.5,
            entry_date=datetime.now().date(),
            description="Working on integration tests"
        )
        mock_instance.log_hours = AsyncMock(return_value=mock_entry)
        mock_instance.close = AsyncMock()

        payload = {
            "project_id": "proj_1",
            "employee_id": "emp_1",
            "hours": 4.5,
            "entry_date": "2025-01-01",
            "description": "Working on integration tests"
        }

        response = client.post("/simplicate/hours", json=payload)

        assert response.status_code == 200
        data = response.json()
        assert data["hours"] == 4.5
        mock_instance.log_hours.assert_called_once()

# --- Trello Tests ---

def test_trello_get_todos(client):
    with patch("connectors.trello.router.TrelloClient") as MockClient:
        mock_instance = MockClient.return_value
        
        mock_summary = TodoSummary(
            total_todos=5,
            overdue_count=1,
            due_today_count=2,
            due_this_week_count=2,
            cards=[
                TodoCard(
                    id="card_1",
                    name="Fix bug",
                    due=datetime.now(),
                    list_name="To Do",
                    board_name="Dev Board",
                    is_overdue=True,
                    board_id="board_123",
                    due_complete=False,
                    url="https://trello.com/c/123"
                )
            ]
        )
        mock_instance.get_todos = AsyncMock(return_value=mock_summary)
        mock_instance.close = AsyncMock()

        response = client.get("/trello/todos")

        assert response.status_code == 200
        data = response.json()
        assert data["total_todos"] == 5
        assert data["overdue_count"] == 1
        mock_instance.get_todos.assert_called_once()

# --- Word Tests ---

def test_word_create_document(client):
    with patch("connectors.word.router.WordClient") as MockClient:
        mock_instance = MockClient.return_value
        
        # Mock create_document returning bytes
        mock_instance.create_document = MagicMock(return_value=b"fake_docx_content")

        payload = {
            "title": "Integration Test Doc",
            "sections": [
                {
                    "type": "paragraph",
                    "content": {
                        "text": "Hello World"
                    }
                }
            ]
        }

        response = client.post("/word/create", json=payload)

        assert response.status_code == 200
        data = response.json()
        assert "document_base64" in data
        assert "filename" in data
        assert data["size_bytes"] == len(b"fake_docx_content")
        mock_instance.create_document.assert_called_once()
