"""
Pydantic models for Trello API data structures.
These models define request/response schemas for the Trello connector endpoints.
"""
from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel, Field


# --- Board Models ---

class BoardBase(BaseModel):
    """Base model for Trello board."""
    name: str = Field(..., description="Board name")
    desc: Optional[str] = Field(None, description="Board description")


class BoardCreate(BoardBase):
    """Model for creating a new board."""
    template_id: Optional[str] = Field(None, description="Template board ID to copy from")
    default_lists: bool = Field(True, description="Create default lists (To Do, Doing, Done)")


class Board(BoardBase):
    """Full board model with metadata."""
    id: str = Field(..., description="Unique board identifier")
    url: str = Field(..., description="Direct URL to board")
    short_url: Optional[str] = Field(None, description="Short URL to board")
    closed: bool = Field(False, description="Whether board is archived")
    pinned: bool = Field(False, description="Whether board is pinned")

    class Config:
        from_attributes = True


# --- List Models ---

class TrelloList(BaseModel):
    """Trello list (column) model."""
    id: str = Field(..., description="Unique list identifier")
    name: str = Field(..., description="List name")
    closed: bool = Field(False, description="Whether list is archived")
    pos: float = Field(..., description="Position in board")
    board_id: Optional[str] = Field(None, description="Parent board ID")

    class Config:
        from_attributes = True


# --- Card Models ---

class CardBase(BaseModel):
    """Base model for Trello card."""
    name: str = Field(..., description="Card title")
    desc: Optional[str] = Field(None, description="Card description (markdown supported)")
    due: Optional[datetime] = Field(None, description="Due date")
    due_complete: bool = Field(False, description="Whether due date is marked complete")


class CardCreate(CardBase):
    """Model for creating a new card."""
    list_id: str = Field(..., description="List ID to add card to")
    member_ids: Optional[List[str]] = Field(None, description="Member IDs to assign")
    label_ids: Optional[List[str]] = Field(None, description="Label IDs to add")
    pos: Optional[str] = Field("bottom", description="Position: top, bottom, or numeric")


class CardUpdate(BaseModel):
    """Model for updating a card."""
    name: Optional[str] = Field(None, description="New card title")
    desc: Optional[str] = Field(None, description="New description")
    due: Optional[datetime] = Field(None, description="New due date")
    due_complete: Optional[bool] = Field(None, description="Mark due date complete")
    list_id: Optional[str] = Field(None, description="Move to different list")
    closed: Optional[bool] = Field(None, description="Archive the card")


class Card(CardBase):
    """Full card model with metadata."""
    id: str = Field(..., description="Unique card identifier")
    short_id: int = Field(..., description="Short numeric ID")
    url: str = Field(..., description="Direct URL to card")
    short_url: Optional[str] = Field(None, description="Short URL to card")
    list_id: str = Field(..., description="Parent list ID")
    board_id: str = Field(..., description="Parent board ID")
    closed: bool = Field(False, description="Whether card is archived")
    pos: float = Field(..., description="Position in list")
    labels: Optional[List[dict]] = Field(None, description="Applied labels")
    member_ids: Optional[List[str]] = Field(None, description="Assigned member IDs")

    class Config:
        from_attributes = True


# --- Member Models ---

class Member(BaseModel):
    """Trello member/user model."""
    id: str = Field(..., description="Unique member identifier")
    username: str = Field(..., description="Username")
    full_name: str = Field(..., description="Full display name")
    avatar_url: Optional[str] = Field(None, description="Avatar image URL")
    initials: Optional[str] = Field(None, description="Initials")
    member_type: Optional[str] = Field(None, description="Member type (admin, normal)")

    class Config:
        from_attributes = True


# --- Todo/Due Cards Models ---

class TodoCard(BaseModel):
    """Card with due date for todo tracking."""
    id: str
    name: str
    due: Optional[datetime]
    due_complete: bool
    list_name: str
    board_name: str
    board_id: str
    url: str
    assigned_members: Optional[List[str]] = None
    is_overdue: bool = False


class TodoSummary(BaseModel):
    """Summary of todos across boards."""
    total_todos: int
    overdue_count: int
    due_today_count: int
    due_this_week_count: int
    cards: List[TodoCard]
