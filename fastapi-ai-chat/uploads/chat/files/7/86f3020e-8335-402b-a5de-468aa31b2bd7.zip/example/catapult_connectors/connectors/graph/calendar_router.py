"""
FastAPI router for Outlook Calendar connector endpoints.

Uses Microsoft Graph API with On-Behalf-Of (OBO) authentication,
allowing per-user access to calendar via Copilot Studio.
"""
from fastapi import APIRouter, Query, Path, Body, Depends
from typing import Optional, List

from .client import GraphClient
from .models import Event, EventCreate, EventUpdate, AvailabilityResult
from ..shared.dependencies import validate_token, UserContext

router = APIRouter()


@router.get(
    "/events",
    response_model=List[Event],
    operation_id="calendar_get_events",
    summary="List calendar events",
    description="Get your upcoming calendar events. Returns events sorted by start time."
)
async def get_events(
    top: int = Query(25, ge=1, le=100, description="Number of events to return"),
    skip: int = Query(0, ge=0, description="Number of events to skip"),
    user: UserContext = Depends(validate_token)
) -> List[Event]:
    """Get calendar events for the authenticated user."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.get_events("me", top=top, skip=skip)
    finally:
        await client.close()


@router.get(
    "/view",
    response_model=List[Event],
    operation_id="calendar_get_view",
    summary="Get events in date range",
    description="Get all your calendar events within a specific date/time range. Use ISO 8601 format for dates."
)
async def get_calendar_view(
    start_datetime: str = Query(..., description="Start datetime (ISO 8601, e.g., 2025-01-15T09:00:00)"),
    end_datetime: str = Query(..., description="End datetime (ISO 8601, e.g., 2025-01-15T18:00:00)"),
    user: UserContext = Depends(validate_token)
) -> List[Event]:
    """Get events in a date range."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.get_calendar_view("me", start_datetime, end_datetime)
    finally:
        await client.close()


@router.get(
    "/events/{event_id}",
    response_model=Event,
    operation_id="calendar_get_event",
    summary="Get event by ID",
    description="Retrieve a specific calendar event by its unique ID."
)
async def get_event(
    event_id: str = Path(..., description="Event ID"),
    user: UserContext = Depends(validate_token)
) -> Event:
    """Get a specific event."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.get_event("me", event_id)
    finally:
        await client.close()


@router.post(
    "/events",
    response_model=Event,
    operation_id="calendar_create_event",
    summary="Create calendar event",
    description="Create a new calendar event. Can include attendees, location, and optionally create a Teams meeting."
)
async def create_event(
    event: EventCreate = Body(..., description="Event details"),
    user: UserContext = Depends(validate_token)
) -> Event:
    """Create a calendar event."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.create_event("me", event)
    finally:
        await client.close()


@router.patch(
    "/events/{event_id}",
    response_model=Event,
    operation_id="calendar_update_event",
    summary="Update calendar event",
    description="Update an existing calendar event's details, time, or location."
)
async def update_event(
    event_id: str = Path(..., description="Event ID to update"),
    update: EventUpdate = Body(..., description="Properties to update"),
    user: UserContext = Depends(validate_token)
) -> Event:
    """Update a calendar event."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.update_event("me", event_id, update)
    finally:
        await client.close()


@router.delete(
    "/events/{event_id}",
    operation_id="calendar_delete_event",
    summary="Delete calendar event",
    description="Delete a calendar event. This action cannot be undone."
)
async def delete_event(
    event_id: str = Path(..., description="Event ID to delete"),
    user: UserContext = Depends(validate_token)
) -> dict:
    """Delete a calendar event."""
    client = GraphClient(user_token=user.token)
    try:
        await client.delete_event("me", event_id)
        return {"success": True, "message": "Event deleted"}
    finally:
        await client.close()


@router.post(
    "/availability",
    response_model=List[AvailabilityResult],
    operation_id="calendar_check_availability",
    summary="Check free/busy times",
    description="Check availability/free-busy status for one or more users in a time range. Returns schedule items and availability view."
)
async def check_availability(
    schedules: List[str] = Body(..., description="List of email addresses to check"),
    start_datetime: str = Body(..., description="Start datetime (ISO 8601)"),
    end_datetime: str = Body(..., description="End datetime (ISO 8601)"),
    timezone: str = Body("UTC", description="Timezone for the request"),
    user: UserContext = Depends(validate_token)
) -> List[AvailabilityResult]:
    """Check availability for users."""
    client = GraphClient(user_token=user.token)
    try:
        return await client.check_availability(schedules, start_datetime, end_datetime, timezone)
    finally:
        await client.close()
