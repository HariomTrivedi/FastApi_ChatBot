"""
FastAPI router for Trello connector endpoints.
All endpoints are documented for Copilot Studio OpenAPI integration.
"""
from fastapi import APIRouter, Query, Path, Body
from typing import Optional, List

from .client import TrelloClient
from .models import (
    Board, BoardCreate,
    TrelloList,
    Card, CardCreate, CardUpdate,
    Member, TodoSummary
)

router = APIRouter()


def get_client() -> TrelloClient:
    """Get Trello client instance."""
    return TrelloClient()


# --- Board Endpoints ---

@router.get(
    "/boards",
    response_model=List[Board],
    operation_id="trello_get_boards",
    summary="List all boards",
    description="Get all Trello boards accessible to the authenticated user. Use to find existing project boards."
)
async def get_boards(
    filter: str = Query("open", description="Filter: open, closed, or all")
) -> List[Board]:
    """Get all boards."""
    client = get_client()
    try:
        return await client.get_boards(filter=filter)
    finally:
        await client.close()


@router.get(
    "/boards/{board_id}",
    response_model=Board,
    operation_id="trello_get_board",
    summary="Get board by ID",
    description="Retrieve a specific Trello board by its unique ID."
)
async def get_board(
    board_id: str = Path(..., description="Unique board identifier")
) -> Board:
    """Get a single board."""
    client = get_client()
    try:
        return await client.get_board(board_id)
    finally:
        await client.close()


@router.post(
    "/boards",
    response_model=Board,
    operation_id="trello_create_board",
    summary="Create new board",
    description="Create a new Trello board. Optionally copy from a template board."
)
async def create_board(
    board: BoardCreate = Body(..., description="Board details")
) -> Board:
    """Create a new board."""
    client = get_client()
    try:
        return await client.create_board(board)
    finally:
        await client.close()


# --- List Endpoints ---

@router.get(
    "/boards/{board_id}/lists",
    response_model=List[TrelloList],
    operation_id="trello_get_lists",
    summary="Get lists on board",
    description="Get all lists (columns) on a specific board."
)
async def get_lists(
    board_id: str = Path(..., description="Board ID to get lists from")
) -> List[TrelloList]:
    """Get all lists on a board."""
    client = get_client()
    try:
        return await client.get_lists(board_id)
    finally:
        await client.close()


# --- Card Endpoints ---

@router.get(
    "/boards/{board_id}/cards",
    response_model=List[Card],
    operation_id="trello_get_cards",
    summary="Get cards on board",
    description="Get all cards on a specific board, optionally filtered by list."
)
async def get_cards(
    board_id: str = Path(..., description="Board ID to get cards from"),
    list_id: Optional[str] = Query(None, description="Optional list ID to filter cards")
) -> List[Card]:
    """Get all cards on a board."""
    client = get_client()
    try:
        return await client.get_cards(board_id, list_id=list_id)
    finally:
        await client.close()


@router.get(
    "/cards/{card_id}",
    response_model=Card,
    operation_id="trello_get_card",
    summary="Get card by ID",
    description="Retrieve a specific card by its unique ID."
)
async def get_card(
    card_id: str = Path(..., description="Unique card identifier")
) -> Card:
    """Get a single card."""
    client = get_client()
    try:
        return await client.get_card(card_id)
    finally:
        await client.close()


@router.post(
    "/cards",
    response_model=Card,
    operation_id="trello_create_card",
    summary="Create new card",
    description="Create a new card on a Trello list. Can assign members and set due dates."
)
async def create_card(
    card: CardCreate = Body(..., description="Card details including list_id")
) -> Card:
    """Create a new card."""
    client = get_client()
    try:
        return await client.create_card(card)
    finally:
        await client.close()


@router.put(
    "/cards/{card_id}",
    response_model=Card,
    operation_id="trello_update_card",
    summary="Update card",
    description="Update an existing card's details. Can move between lists, update due date, etc."
)
async def update_card(
    card_id: str = Path(..., description="Card ID to update"),
    update: CardUpdate = Body(..., description="Fields to update")
) -> Card:
    """Update a card."""
    client = get_client()
    try:
        return await client.update_card(card_id, update)
    finally:
        await client.close()


@router.delete(
    "/cards/{card_id}",
    operation_id="trello_delete_card",
    summary="Delete card",
    description="Permanently delete a card. Use update with closed=true to archive instead."
)
async def delete_card(
    card_id: str = Path(..., description="Card ID to delete")
) -> dict:
    """Delete a card."""
    client = get_client()
    try:
        await client.delete_card(card_id)
        return {"success": True, "message": "Card deleted"}
    finally:
        await client.close()


# --- Member Endpoints ---

@router.get(
    "/boards/{board_id}/members",
    response_model=List[Member],
    operation_id="trello_get_members",
    summary="Get board members",
    description="Get all members of a specific board. Use for assigning cards."
)
async def get_members(
    board_id: str = Path(..., description="Board ID to get members from")
) -> List[Member]:
    """Get all members of a board."""
    client = get_client()
    try:
        return await client.get_members(board_id)
    finally:
        await client.close()


# --- Todo/Due Cards Endpoints ---

@router.get(
    "/todos",
    response_model=TodoSummary,
    operation_id="trello_get_todos",
    summary="Get cards with due dates",
    description="Get all cards with due dates across boards. Includes overdue count and categorization by urgency."
)
async def get_todos(
    board_ids: Optional[str] = Query(None, description="Comma-separated board IDs to check (default: all)"),
    member_id: Optional[str] = Query(None, description="Filter by assigned member ID")
) -> TodoSummary:
    """Get todo summary across boards."""
    client = get_client()
    try:
        board_id_list = board_ids.split(",") if board_ids else None
        return await client.get_todos(
            board_ids=board_id_list,
            member_id=member_id
        )
    finally:
        await client.close()
