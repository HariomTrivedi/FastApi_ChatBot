"""
Pydantic models for Word document operations.
Defines request/response schemas for the Word connector endpoints.
"""
from typing import Optional, List, Dict, Any, TYPE_CHECKING
from pydantic import BaseModel, Field

if TYPE_CHECKING:
    pass  # Forward references resolved below
from enum import Enum


class TextAlignment(str, Enum):
    """Paragraph alignment options."""
    LEFT = "left"
    CENTER = "center"
    RIGHT = "right"
    JUSTIFY = "justify"


class HeadingLevel(int, Enum):
    """Heading levels (0 = Title, 1-9 = Heading levels)."""
    TITLE = 0
    H1 = 1
    H2 = 2
    H3 = 3
    H4 = 4
    H5 = 5
    H6 = 6


class FontStyle(BaseModel):
    """Font styling options."""
    bold: bool = Field(False, description="Bold text")
    italic: bool = Field(False, description="Italic text")
    underline: bool = Field(False, description="Underlined text")
    size_pt: Optional[int] = Field(None, description="Font size in points")
    color_hex: Optional[str] = Field(None, description="Font color as hex (e.g., 'FF0000' for red)")
    font_name: Optional[str] = Field(None, description="Font family name (e.g., 'Arial')")


class ParagraphStyle(str, Enum):
    """Built-in paragraph styles."""
    NORMAL = "Normal"
    TITLE = "Title"
    SUBTITLE = "Subtitle"
    HEADING_1 = "Heading 1"
    HEADING_2 = "Heading 2"
    HEADING_3 = "Heading 3"
    LIST_BULLET = "List Bullet"
    LIST_NUMBER = "List Number"
    QUOTE = "Quote"
    INTENSE_QUOTE = "Intense Quote"
    BODY_TEXT = "Body Text"


class TableStyle(str, Enum):
    """Built-in table styles."""
    NORMAL = "Table Normal"
    GRID = "Table Grid"
    LIGHT_SHADING = "Light Shading"
    LIGHT_SHADING_ACCENT_1 = "Light Shading Accent 1"
    LIGHT_GRID = "Light Grid"
    LIGHT_GRID_ACCENT_1 = "Light Grid Accent 1"
    MEDIUM_SHADING_1 = "Medium Shading 1"
    MEDIUM_GRID_1 = "Medium Grid 1"
    MEDIUM_GRID_1_ACCENT_1 = "Medium Grid 1 Accent 1"


# --- Document Creation Models ---

class ParagraphContent(BaseModel):
    """Content for a paragraph."""
    text: str = Field(..., description="Paragraph text content")
    style: Optional[ParagraphStyle] = Field(None, description="Paragraph style")
    alignment: Optional[TextAlignment] = Field(None, description="Text alignment")
    font_style: Optional[FontStyle] = Field(None, description="Font styling")


class HeadingContent(BaseModel):
    """Content for a heading."""
    text: str = Field(..., description="Heading text")
    level: HeadingLevel = Field(HeadingLevel.H1, description="Heading level (0=Title, 1-6)")


class TableCell(BaseModel):
    """Single table cell content."""
    text: str = Field(..., description="Cell text content")
    bold: bool = Field(False, description="Bold text in cell")


class TableRow(BaseModel):
    """Table row with cells."""
    cells: List[TableCell] = Field(..., description="List of cells in this row")


class TableContent(BaseModel):
    """Content for a table."""
    headers: List[str] = Field(..., description="Table header row")
    rows: List[List[str]] = Field(..., description="Table data rows")
    style: Optional[TableStyle] = Field(None, description="Table style")


class ImageContent(BaseModel):
    """Content for an image."""
    base64_data: str = Field(..., description="Base64 encoded image data")
    filename: str = Field(..., description="Original filename for MIME type detection")
    width_inches: Optional[float] = Field(None, description="Image width in inches")
    height_inches: Optional[float] = Field(None, description="Image height in inches")


class HyperlinkContent(BaseModel):
    """Content for a hyperlink."""
    url: str = Field(..., description="URL for the hyperlink")
    display_text: str = Field(..., description="Text to display for the link")


class PageBreak(BaseModel):
    """Represents a page break."""
    pass


class DocumentSection(BaseModel):
    """A section of document content."""
    type: str = Field(..., description="Content type: paragraph, heading, table, image, hyperlink, page_break")
    content: Dict[str, Any] = Field(..., description="Content data based on type")


# --- Document Creation Request ---

class DocumentCreateRequest(BaseModel):
    """Request to create a new Word document."""
    title: Optional[str] = Field(None, description="Document title (added as Title heading)")
    sections: List[DocumentSection] = Field(..., description="Document content sections in order")

    class Config:
        json_schema_extra = {
            "example": {
                "title": "Project Report",
                "sections": [
                    {"type": "heading", "content": {"text": "Introduction", "level": 1}},
                    {"type": "paragraph", "content": {"text": "This is the introduction paragraph."}},
                    {"type": "table", "content": {
                        "headers": ["Name", "Value"],
                        "rows": [["Item 1", "100"], ["Item 2", "200"]]
                    }}
                ]
            }
        }


class DocumentFromTemplateRequest(BaseModel):
    """Request to create document from template with placeholders."""
    template_base64: str = Field(..., description="Base64 encoded .docx template file")
    replacements: Dict[str, str] = Field(..., description="Placeholder replacements (key: placeholder, value: replacement)")

    class Config:
        json_schema_extra = {
            "example": {
                "template_base64": "UEsDBBQAAAA...",
                "replacements": {
                    "{{client_name}}": "Acme Corp",
                    "{{project_name}}": "Website Redesign",
                    "{{date}}": "2025-01-15"
                }
            }
        }


# --- Document Modification Models ---

class AppendParagraphRequest(BaseModel):
    """Request to append a paragraph to existing document."""
    document_base64: str = Field(..., description="Base64 encoded .docx file")
    paragraph: ParagraphContent = Field(..., description="Paragraph to append")


class AppendTableRequest(BaseModel):
    """Request to append a table to existing document."""
    document_base64: str = Field(..., description="Base64 encoded .docx file")
    table: TableContent = Field(..., description="Table to append")


class ReplaceTextRequest(BaseModel):
    """Request to find and replace text in document."""
    document_base64: str = Field(..., description="Base64 encoded .docx file")
    find_text: str = Field(..., description="Text to find")
    replace_text: str = Field(..., description="Replacement text")
    match_case: bool = Field(True, description="Case-sensitive matching")


# --- Response Models ---

class DocumentResponse(BaseModel):
    """Response containing a generated document."""
    document_base64: str = Field(..., description="Base64 encoded .docx file")
    filename: str = Field(..., description="Suggested filename")
    size_bytes: int = Field(..., description="Document size in bytes")


class DocumentInfo(BaseModel):
    """Information about a document."""
    paragraph_count: int = Field(..., description="Number of paragraphs")
    table_count: int = Field(..., description="Number of tables")
    image_count: int = Field(..., description="Number of inline images")
    word_count: int = Field(..., description="Approximate word count")
    styles_used: List[str] = Field(..., description="List of styles used in document")


class OperationResult(BaseModel):
    """Result of a document operation."""
    success: bool = Field(..., description="Whether operation succeeded")
    message: str = Field(..., description="Result message")
    document_base64: Optional[str] = Field(None, description="Modified document if applicable")


# --- SharePoint Integration Models ---

class SharePointSaveRequest(BaseModel):
    """Request to save a created Word document to SharePoint."""
    drive_id: str = Field(..., description="SharePoint drive/library ID")
    folder_path: str = Field(..., description="Target folder path (e.g., 'Documents/Reports')")
    file_name: str = Field(..., description="Name for the saved file (without extension)")
    document: "DocumentCreateRequest" = Field(..., description="Document content to create and save")

    class Config:
        json_schema_extra = {
            "example": {
                "drive_id": "b!abc123...",
                "folder_path": "Documents/Reports",
                "file_name": "Monthly_Report",
                "document": {
                    "title": "Monthly Report",
                    "sections": [
                        {"type": "paragraph", "content": {"text": "Report content here."}}
                    ]
                }
            }
        }


class SharePointAppendParagraphRequest(BaseModel):
    """Request to atomically append a paragraph to a SharePoint document."""
    drive_id: str = Field(..., description="SharePoint drive/library ID")
    item_id: str = Field(..., description="Document item ID in SharePoint")
    paragraph: ParagraphContent = Field(..., description="Paragraph to append")


class SharePointAppendTableRequest(BaseModel):
    """Request to atomically append a table to a SharePoint document."""
    drive_id: str = Field(..., description="SharePoint drive/library ID")
    item_id: str = Field(..., description="Document item ID in SharePoint")
    table: TableContent = Field(..., description="Table to append")


class SharePointReplaceTextRequest(BaseModel):
    """Request to atomically find/replace text in a SharePoint document."""
    drive_id: str = Field(..., description="SharePoint drive/library ID")
    item_id: str = Field(..., description="Document item ID in SharePoint")
    find_text: str = Field(..., description="Text to find")
    replace_text: str = Field(..., description="Replacement text")
    match_case: bool = Field(True, description="Case-sensitive matching")


class SharePointFromTemplateRequest(BaseModel):
    """Request to fill a template from SharePoint and save the result."""
    template_drive_id: str = Field(..., description="Drive ID where template is stored")
    template_item_id: str = Field(..., description="Template document item ID")
    replacements: Dict[str, str] = Field(..., description="Placeholder replacements")
    output_drive_id: str = Field(..., description="Drive ID for output file")
    output_folder_path: str = Field(..., description="Output folder path")
    output_file_name: str = Field(..., description="Output file name (without extension)")

    class Config:
        json_schema_extra = {
            "example": {
                "template_drive_id": "b!abc123...",
                "template_item_id": "01ABC...",
                "replacements": {
                    "{{client_name}}": "Acme Corp",
                    "{{date}}": "2025-01-15"
                },
                "output_drive_id": "b!abc123...",
                "output_folder_path": "Documents/Proposals",
                "output_file_name": "Proposal_AcmeCorp"
            }
        }


class SharePointDocumentResult(BaseModel):
    """Result of a SharePoint document operation."""
    success: bool = Field(..., description="Whether operation succeeded")
    message: str = Field(..., description="Result message")
    item_id: str = Field(..., description="SharePoint item ID of the document")
    item_name: str = Field(..., description="File name")
    web_url: Optional[str] = Field(None, description="URL to open in browser")
    size_bytes: Optional[int] = Field(None, description="File size in bytes")
