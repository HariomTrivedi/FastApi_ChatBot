# Development Guide

## Getting Started

### Prerequisites

- Python 3.11+
- Docker Desktop (recommended for container simulation)
- Git
- VS Code (recommended) with Python extension

### Initial Setup

```bash
# Clone the repository
git clone <repository-url>
cd catapult_connectors

# Create virtual environment
python -m venv .venv

# Activate virtual environment
# Windows:
.venv\Scripts\activate
# Linux/Mac:
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Copy environment template
cp .env.example .env
```

### Configure Local Settings

Edit `.env` with your credentials:

```env
# Application Settings
PORT=8000
LOG_LEVEL=info

# Simplicate
SIMPLICATE_SUBDOMAIN=your-subdomain
SIMPLICATE_API_KEY=your-key
SIMPLICATE_API_SECRET=your-secret

# Trello
TRELLO_API_KEY=your-key
TRELLO_API_TOKEN=your-token

# Microsoft Graph (Azure AD)
AZURE_TENANT_ID=your-tenant
AZURE_CLIENT_ID=your-client-id
AZURE_CLIENT_SECRET=your-secret
```

### Run Locally (FastAPI)

You can run the application directly with Uvicorn:

```bash
# Start the server with hot reload
uvicorn main:app --reload --port 8000
```

### Run with Docker

To simulate the Azure Container Apps environment:

```bash
# Build the image
docker build -t catapult-connectors .

# Run the container
docker run -p 8000:8000 --env-file .env catapult-connectors
```

Access the API:
- Base URL: http://localhost:8000
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

---

## Project Structure

```
catapult_connectors/
├── main.py                   # FastAPI entry point
├── Dockerfile                # Container definition
├── gunicorn.conf.py          # Production server config
├── requirements.txt          # Dependencies
├── connectors/               # Connector modules
│   ├── shared/               # Shared utilities
│   ├── simplicate/           # Simplicate connector
│   ├── trello/               # Trello connector
│   ├── graph/                # Microsoft Graph connectors
│   └── word/                 # Word document connector
├── openapi/                  # OpenAPI tools
├── documentation/            # Documentation
└── tests/                    # Test suites
```

---

## Adding a New Connector

### Step 1: Create Connector Directory

```bash
mkdir -p connectors/newservice
touch connectors/newservice/__init__.py
touch connectors/newservice/models.py
touch connectors/newservice/client.py
touch connectors/newservice/router.py
```

### Step 2: Define Models (`models.py`)

```python
from typing import Optional, List
from pydantic import BaseModel, Field

class ItemBase(BaseModel):
    """Base model for items."""
    name: str = Field(..., description="Item name")
    description: Optional[str] = Field(None, description="Description")

class ItemCreate(ItemBase):
    """Model for creating items."""
    pass

class Item(ItemBase):
    """Full item model."""
    id: str = Field(..., description="Unique identifier")
    created_at: Optional[str] = None

    class Config:
        from_attributes = True
```

### Step 3: Implement Client (`client.py`)

```python
import httpx
from typing import Optional, List
from ..shared.auth import get_newservice_auth
from ..shared.errors import NewServiceError
from .models import Item, ItemCreate

class NewServiceClient:
    def __init__(self):
        self.auth = get_newservice_auth()
        self._client: Optional[httpx.AsyncClient] = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.auth.base_url,
                headers=self.auth.headers,
                timeout=30.0
            )
        return self._client

    async def get_items(self) -> List[Item]:
        client = await self._get_client()
        response = await client.get("/items")

        if response.status_code >= 400:
            raise NewServiceError(
                status_code=response.status_code,
                message=response.text
            )

        data = response.json()
        return [Item(**item) for item in data]

    async def close(self):
        if self._client:
            await self._client.aclose()
            self._client = None
```

### Step 4: Create Router (`router.py`)

```python
from fastapi import APIRouter, HTTPException
from typing import List
from .client import NewServiceClient
from .models import Item, ItemCreate

router = APIRouter()

def get_client() -> NewServiceClient:
    return NewServiceClient()

@router.get(
    "/items",
    response_model=List[Item],
    operation_id="newservice_get_items",
    summary="List items",
    description="Get all items from the service."
)
async def get_items() -> List[Item]:
    client = get_client()
    try:
        return await client.get_items()
    finally:
        await client.close()
```

### Step 5: Register Router

Edit `main.py`:

```python
from connectors.newservice.router import router as newservice_router

# Add to routers section
app.include_router(
    newservice_router,
    prefix="/newservice",
    tags=["New Service"]
)
```

### Step 6: Add Authentication (if needed)

Edit `connectors/shared/auth.py`:

```python
class NewServiceAuth:
    def __init__(self):
        self.api_key = os.environ.get("NEWSERVICE_API_KEY", "")

    @property
    def is_configured(self) -> bool:
        return bool(self.api_key)

    @property
    def headers(self) -> Dict[str, str]:
        return {"Authorization": f"Bearer {self.api_key}"}

    @property
    def base_url(self) -> str:
        return "https://api.newservice.com/v1"

@lru_cache()
def get_newservice_auth() -> NewServiceAuth:
    return NewServiceAuth()
```

---

## Coding Standards

### Naming Conventions

| Type | Convention | Example |
|------|------------|---------|
| Files | snake_case | `mail_router.py` |
| Classes | PascalCase | `GraphClient` |
| Functions | snake_case | `get_inbox_messages` |
| Constants | UPPER_SNAKE | `MAX_RETRY_COUNT` |
| Variables | snake_case | `message_count` |

### Type Hints

Always use type hints:

```python
from typing import Optional, List, Dict

async def get_items(
    limit: int = 100,
    filter: Optional[str] = None
) -> List[Item]:
    ...
```

### Docstrings

Use Google-style docstrings:

```python
async def create_item(self, item: ItemCreate) -> Item:
    """
    Create a new item.

    Args:
        item: Item data for creation

    Returns:
        The created item with generated ID

    Raises:
        NewServiceError: If creation fails
    """
```

### Error Handling

Use connector-specific exceptions:

```python
from ..shared.errors import NewServiceError

try:
    response = await client.get("/items")
    if response.status_code >= 400:
        raise NewServiceError(
            status_code=response.status_code,
            message=f"Failed to get items: {response.text}"
        )
except httpx.RequestError as e:
    raise NewServiceError(
        status_code=500,
        message=f"Connection error: {str(e)}"
    )
```

---

## Testing

We follow a comprehensive testing strategy that includes both unit and integration tests to ensure reliability and maintainability.

### Testing Philosophy

*   **Unit Tests**: Focus on verifying the logic of individual components (Clients, Models, Shared Utils) in isolation. We strictly mock external dependencies (like HTTP requests) to keep tests fast and deterministic.
*   **Integration Tests**: Verify that the API endpoints work correctly and that the different layers (Router -> Client -> Shared) interact as expected.

### Documentation

For detailed instructions on how to run tests, specific commands, and directory structure, please refer to the **[Tests README](../tests/README.md)**.

For a deeper dive into the testing architecture, decisions, and strategies, see the **[Testing Strategy](TESTING_STRATEGY.md)** document.

---

## Debugging

### VS Code Configuration

Create `.vscode/launch.json`:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "FastAPI: Debug",
      "type": "python",
      "request": "launch",
      "module": "uvicorn",
      "args": [
        "main:app",
        "--reload",
        "--port",
        "8000"
      ],
      "jinja": true,
      "justMyCode": true,
      "envFile": "${workspaceFolder}/.env"
    }
  ]
}
```

### Logging

Use Python's logging module:

```python
import logging

logger = logging.getLogger(__name__)

async def process_item(item_id: str):
    logger.info(f"Processing item: {item_id}")
    try:
        result = await do_something()
        logger.debug(f"Result: {result}")
    except Exception as e:
        logger.error(f"Failed to process item {item_id}: {e}")
        raise
```

---

## Common Tasks

### Generate OpenAPI Spec

```bash
# Generate Swagger 2.0 for Copilot Studio
python openapi/generate_swagger.py \
  --host localhost:7071 \
  --output openapi/swagger.json

# Also output OpenAPI 3.x
python openapi/generate_swagger.py \
  --host localhost:7071 \
  --openapi3
```

### Update Dependencies

```bash
# Update all packages
pip install --upgrade -r requirements.txt

# Add new package
pip install new-package
pip freeze | grep new-package >> requirements.txt
```

### Format Code

```bash
# Using black
pip install black
black connectors/

# Using isort for imports
pip install isort
isort connectors/
```

---

## Troubleshooting

### Import Errors

If you see import errors, ensure:
1. Virtual environment is activated
2. All dependencies are installed
3. `__init__.py` exists in all packages

### Authentication Issues

Check environment variables:
```python
from connectors.shared.auth import get_simplicate_auth
auth = get_simplicate_auth()
print(f"Configured: {auth.is_configured}")
print(f"Base URL: {auth.base_url}")
```

### Async Issues

Always use `async/await` consistently:
```python
# Wrong
result = client.get_items()  # Missing await

# Correct
result = await client.get_items()
```
