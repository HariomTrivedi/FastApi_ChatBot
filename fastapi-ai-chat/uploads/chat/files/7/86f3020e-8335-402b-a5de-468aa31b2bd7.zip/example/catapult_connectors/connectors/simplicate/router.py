"""
FastAPI router for Simplicate CRM connector endpoints.
All endpoints are documented for Copilot Studio OpenAPI integration.
"""
from fastapi import APIRouter, Query, Path, HTTPException, Body
from typing import Optional, List
from datetime import date

from .client import SimplicateClient
from .models import (
    Client, ClientSearchResult,
    Project, ProjectCreate, ProjectUpdate,
    HoursEntry, HoursEntryCreate,
    Employee, CapacityCheck
)

router = APIRouter()


def get_client() -> SimplicateClient:
    """Get Simplicate client instance."""
    return SimplicateClient()


# --- Client/Organization Endpoints ---

@router.get(
    "/clients",
    response_model=List[Client],
    operation_id="simplicate_get_clients",
    summary="List all clients",
    description="Retrieve all clients/organizations from Simplicate CRM. Use for client lookups and project creation."
)
async def get_clients(
    limit: int = Query(100, ge=1, le=500, description="Maximum number of results to return"),
    offset: int = Query(0, ge=0, description="Pagination offset for results")
) -> List[Client]:
    """Get all clients with pagination."""
    client = get_client()
    try:
        return await client.get_clients(limit=limit, offset=offset)
    finally:
        await client.close()


@router.get(
    "/clients/search",
    response_model=List[Client],
    operation_id="simplicate_search_clients",
    summary="Search clients by name",
    description="Fuzzy search for clients by name. Returns matches with confidence scores. Use when looking for existing clients."
)
async def search_clients(
    query: str = Query(..., min_length=2, description="Search query for client name (minimum 2 characters)")
) -> List[Client]:
    """Search clients by name with fuzzy matching."""
    client = get_client()
    try:
        return await client.search_clients(query)
    finally:
        await client.close()


@router.get(
    "/clients/{client_id}",
    response_model=Client,
    operation_id="simplicate_get_client",
    summary="Get client by ID",
    description="Retrieve a specific client/organization by their unique ID."
)
async def get_client_by_id(
    client_id: str = Path(..., description="Unique client identifier")
) -> Client:
    """Get a single client by ID."""
    client = get_client()
    try:
        return await client.get_client(client_id)
    finally:
        await client.close()


# --- Project Endpoints ---

@router.get(
    "/projects",
    response_model=List[Project],
    operation_id="simplicate_get_projects",
    summary="List projects",
    description="Get all projects, optionally filtered by client or status. Use to check existing projects and avoid duplicates."
)
async def get_projects(
    client_id: Optional[str] = Query(None, description="Filter projects by client ID"),
    status: Optional[str] = Query(None, description="Filter by status: active, completed, on_hold, draft"),
    limit: int = Query(100, ge=1, le=500, description="Maximum results to return"),
    offset: int = Query(0, ge=0, description="Pagination offset")
) -> List[Project]:
    """Get projects with optional filters."""
    client = get_client()
    try:
        return await client.get_projects(
            client_id=client_id,
            status=status,
            limit=limit,
            offset=offset
        )
    finally:
        await client.close()


@router.get(
    "/projects/{project_id}",
    response_model=Project,
    operation_id="simplicate_get_project",
    summary="Get project by ID",
    description="Retrieve a specific project by its unique ID including hours logged and status."
)
async def get_project_by_id(
    project_id: str = Path(..., description="Unique project identifier")
) -> Project:
    """Get a single project by ID."""
    client = get_client()
    try:
        return await client.get_project(project_id)
    finally:
        await client.close()


@router.post(
    "/projects",
    response_model=Project,
    operation_id="simplicate_create_project",
    summary="Create new project",
    description="Create a new project in Simplicate linked to a client. Returns the created project with generated ID and Simplicate URL."
)
async def create_project(
    project: ProjectCreate = Body(..., description="Project details to create")
) -> Project:
    """Create a new project."""
    client = get_client()
    try:
        return await client.create_project(project)
    finally:
        await client.close()


@router.put(
    "/projects/{project_id}",
    response_model=Project,
    operation_id="simplicate_update_project",
    summary="Update project",
    description="Update an existing project's details including status, dates, and budget."
)
async def update_project(
    project_id: str = Path(..., description="Project ID to update"),
    update: ProjectUpdate = Body(..., description="Fields to update")
) -> Project:
    """Update an existing project."""
    client = get_client()
    try:
        return await client.update_project(project_id, update)
    finally:
        await client.close()


# --- Hours/Time Tracking Endpoints ---

@router.get(
    "/hours",
    response_model=List[HoursEntry],
    operation_id="simplicate_get_hours",
    summary="Get time entries",
    description="Retrieve time entries with optional filters for project, employee, or date range. Use to check logged hours."
)
async def get_hours(
    project_id: Optional[str] = Query(None, description="Filter by project ID"),
    employee_id: Optional[str] = Query(None, description="Filter by employee ID"),
    start_date: Optional[str] = Query(None, description="Filter from date (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="Filter to date (YYYY-MM-DD)"),
    limit: int = Query(100, ge=1, le=500, description="Maximum results"),
    offset: int = Query(0, ge=0, description="Pagination offset")
) -> List[HoursEntry]:
    """Get time entries with filters."""
    client = get_client()
    try:
        start = date.fromisoformat(start_date) if start_date else None
        end = date.fromisoformat(end_date) if end_date else None
        return await client.get_hours(
            project_id=project_id,
            employee_id=employee_id,
            start_date=start,
            end_date=end,
            limit=limit,
            offset=offset
        )
    finally:
        await client.close()


@router.post(
    "/hours",
    response_model=HoursEntry,
    operation_id="simplicate_log_hours",
    summary="Log time entry",
    description="Log a new time entry for a project. Associates hours with employee and project."
)
async def log_hours(
    entry: HoursEntryCreate = Body(..., description="Time entry details")
) -> HoursEntry:
    """Log a new time entry."""
    client = get_client()
    try:
        return await client.log_hours(entry)
    finally:
        await client.close()


# --- Employee/Capacity Endpoints ---

@router.get(
    "/employees",
    response_model=List[Employee],
    operation_id="simplicate_get_employees",
    summary="List employees",
    description="Get all active employees/team members. Use for capacity checking and team assignment."
)
async def get_employees(
    limit: int = Query(100, ge=1, le=500, description="Maximum results"),
    offset: int = Query(0, ge=0, description="Pagination offset")
) -> List[Employee]:
    """Get all employees."""
    client = get_client()
    try:
        return await client.get_employees(limit=limit, offset=offset)
    finally:
        await client.close()


@router.get(
    "/capacity",
    response_model=CapacityCheck,
    operation_id="simplicate_check_capacity",
    summary="Check team capacity",
    description="Check availability of team members for a given date range. Returns utilization percentages and suggested available team members. Status: GREEN (available), YELLOW (limited), RED (unavailable)."
)
async def check_capacity(
    start_date: str = Query(..., description="Start date for capacity check (YYYY-MM-DD)"),
    end_date: str = Query(..., description="End date for capacity check (YYYY-MM-DD)"),
    roles: Optional[str] = Query(None, description="Comma-separated list of roles to filter (e.g., 'designer,developer')")
) -> CapacityCheck:
    """Check team capacity for a date range."""
    client = get_client()
    try:
        return await client.check_capacity(start_date, end_date, roles)
    finally:
        await client.close()
