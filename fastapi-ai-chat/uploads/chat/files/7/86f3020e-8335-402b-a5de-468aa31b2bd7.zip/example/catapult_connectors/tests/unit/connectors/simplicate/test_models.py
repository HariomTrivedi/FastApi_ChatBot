import pytest
from datetime import date, datetime
from pydantic import ValidationError
from connectors.simplicate.models import (
    Employee,
    HoursEntryCreate,
    HoursEntry,
    Project,
    ProjectStatus
)

class TestSimplicateModels:
    """Test suite for Simplicate Pydantic models."""

    def test_employee_model_valid(self):
        """Test valid Employee model creation."""
        data = {
            "id": "emp_123",
            "name": "John Doe",
            "work_email": "john@example.com",  # Mapping handled in client, but model expects fields matching schema if strict? 
            # Wait, the model definition has 'email', 'role'. 
            # The Client maps API response keys to Model keys. 
            # So here we test the Model structure directly.
            "email": "john@example.com",
            "role": "Developer",
            "is_active": True,
            "avatar_url": "https://example.com/avatar.jpg"
        }
        employee = Employee(**data)
        assert employee.id == "emp_123"
        assert employee.name == "John Doe"
        assert employee.email == "john@example.com"
        assert employee.is_active is True

    def test_employee_model_validation_missing_id(self):
        """Test Employee model requires id."""
        data = {
            "name": "John Doe"
        }
        with pytest.raises(ValidationError) as exc:
            Employee(**data)
        assert "id" in str(exc.value)

    def test_hours_entry_create_valid(self):
        """Test valid HoursEntryCreate model."""
        data = {
            "project_id": "proj_123",
            "employee_id": "emp_123",
            "hours": 4.5,
            "entry_date": date(2023, 10, 27),
            "description": "Coding",
            "billable": True
        }
        entry = HoursEntryCreate(**data)
        assert entry.project_id == "proj_123"
        assert entry.hours == 4.5
        assert entry.entry_date == date(2023, 10, 27)

    def test_hours_entry_create_validation(self):
        """Test HoursEntryCreate validation logic."""
        # Test missing required fields
        with pytest.raises(ValidationError):
            HoursEntryCreate(
                project_id="proj_123",
                # Missing employee_id
                hours=4.5,
                entry_date=date.today()
            )

        # Test negative hours
        with pytest.raises(ValidationError):
            HoursEntryCreate(
                project_id="proj_123",
                employee_id="emp_123",
                hours=-1.0,  # Invalid
                entry_date=date.today()
            )

    def test_project_model(self):
        """Test Project model structure and enum handling."""
        data = {
            "id": "proj_123",
            "name": "New Website",
            "client_id": "client_456",
            "status": "active",
            "created_at": "2023-01-01T12:00:00"
        }
        project = Project(**data)
        assert project.status == ProjectStatus.ACTIVE
        assert isinstance(project.created_at, datetime)

    def test_project_status_enum(self):
        """Test ProjectStatus enum values."""
        assert ProjectStatus.ACTIVE == "active"
        assert ProjectStatus.COMPLETED == "completed"
        assert ProjectStatus.ON_HOLD == "on_hold"
        assert ProjectStatus.DRAFT == "draft"