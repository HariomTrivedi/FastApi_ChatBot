import pytest
import time
from unittest.mock import Mock, patch, AsyncMock
from connectors.shared.auth import SimplicateAuth, TrelloAuth, GraphAuth, OBOTokenCache, get_simplicate_auth, get_trello_auth, get_graph_auth
from connectors.shared.dependencies import validate_token, UserContext
from connectors.shared.config import get_settings
from fastapi import HTTPException

@pytest.fixture(autouse=True)
def clear_settings_cache():
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()

# --- Simplicate Auth Tests ---

def test_simplicate_auth_init_env(monkeypatch):
    """Test SimplicateAuth initializes from env vars."""
    monkeypatch.setenv("SIMPLICATE_SUBDOMAIN", "sub")
    monkeypatch.setenv("SIMPLICATE_API_KEY", "key")
    monkeypatch.setenv("SIMPLICATE_API_SECRET", "secret")
    
    auth = SimplicateAuth()
    assert auth.subdomain == "sub"
    assert auth.api_key == "key"
    assert auth.api_secret == "secret"
    assert auth.is_configured is True

def test_simplicate_auth_headers():
    auth = SimplicateAuth(subdomain="sub", api_key="key", api_secret="secret")
    headers = auth.headers
    assert headers["Authentication-Key"] == "key"
    assert headers["Authentication-Secret"] == "secret"
    assert auth.base_url == "https://sub.simplicate.nl/api/v2"

# --- Trello Auth Tests ---

def test_trello_auth_init_env(monkeypatch):
    """Test TrelloAuth initializes from env vars."""
    monkeypatch.setenv("TRELLO_API_KEY", "key")
    monkeypatch.setenv("TRELLO_API_TOKEN", "token")
    
    auth = TrelloAuth()
    assert auth.api_key == "key"
    assert auth.api_token == "token"
    assert auth.is_configured is True

def test_trello_auth_params():
    auth = TrelloAuth(api_key="key", api_token="token")
    params = auth.params
    assert params["key"] == "key"
    assert params["token"] == "token"
    assert auth.base_url == "https://api.trello.com/1"

# --- OBO Token Cache Tests ---

def test_obo_token_cache():
    cache = OBOTokenCache(default_ttl=3600)
    
    # Set
    cache.set("key1", "token1", expires_in=100)
    assert cache.get("key1") == "token1"
    
    # Expiry (mock time)
    with patch("time.time", return_value=time.time() + 200):
        assert cache.get("key1") is None
        
    # Invalidate
    cache.set("key2", "token2")
    cache.invalidate("key2")
    assert cache.get("key2") is None
    
    # Clear
    cache.set("key3", "token3")
    cache.clear()
    assert cache.get("key3") is None

# --- Graph Auth Tests ---

@pytest.mark.asyncio
async def test_graph_auth_app_only(monkeypatch):
    """Test getting app-only token."""
    monkeypatch.setenv("AZURE_TENANT_ID", "tid")
    monkeypatch.setenv("AZURE_CLIENT_ID", "cid")
    monkeypatch.setenv("AZURE_CLIENT_SECRET", "secret")
    
    auth = GraphAuth()
    
    # Mock Azure Credential
    with patch("connectors.shared.auth.ClientSecretCredential") as MockCred:
        mock_cred_instance = MockCred.return_value
        mock_cred_instance.get_token.return_value = Mock(token="mock_token")
        
        token = await auth.get_token()
        assert token == "mock_token"
        
        headers = await auth.get_headers()
        assert headers["Authorization"] == "Bearer mock_token"

@pytest.mark.asyncio
async def test_graph_auth_obo_flow(monkeypatch):
    """Test OBO flow token exchange."""
    monkeypatch.setenv("AZURE_TENANT_ID", "tid")
    monkeypatch.setenv("AZURE_CLIENT_ID", "cid")
    monkeypatch.setenv("AZURE_CLIENT_SECRET", "secret")
    
    auth = GraphAuth()
    
    # Mock httpx response for OBO exchange
    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.json.return_value = {"access_token": "obo_token", "expires_in": 3600}
    
    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = mock_response
        
        token = await auth.get_user_graph_token("user_assertion_token")
        assert token == "obo_token"
        
        # Verify cache usage on second call
        token2 = await auth.get_user_graph_token("user_assertion_token")
        assert token2 == "obo_token"
        assert mock_post.call_count == 1  # Should only be called once due to caching

# --- Dependency Tests (validate_token) ---

@pytest.mark.asyncio
async def test_validate_token_success(monkeypatch):
    """Test successful token validation."""
    monkeypatch.setenv("AZURE_TENANT_ID", "tid")
    monkeypatch.setenv("AZURE_CLIENT_ID", "cid")
    monkeypatch.setenv("AZURE_CLIENT_SECRET", "secret")
    
    # Mock JWT decoding and JWKS
    with patch("connectors.shared.dependencies.jwt") as mock_jwt, \
         patch("connectors.shared.dependencies._jwks_cache.get_jwks", new_callable=AsyncMock) as mock_get_jwks, \
         patch("connectors.shared.dependencies._get_signing_key") as mock_get_key, \
         patch("connectors.shared.dependencies.jwk") as mock_jwk:
             
        # Setup mocks
        mock_jwt.get_unverified_claims.return_value = {"tid": "tid"}
        mock_jwt.decode.return_value = {
            "oid": "user_oid",
            "tid": "tid",
            "name": "Test User",
            "preferred_username": "test@example.com",
            "scp": "User.Read"
        }
        
        mock_credentials = Mock()
        mock_credentials.credentials = "valid_token"
        
        context = await validate_token(mock_credentials)
        
        assert isinstance(context, UserContext)
        assert context.user_id == "user_oid"
        assert context.email == "test@example.com"
        assert context.token == "valid_token"

@pytest.mark.asyncio
async def test_validate_token_missing_config(monkeypatch):
    """Test validation fails if OBO not configured."""
    # Set to empty string to ensure it overrides any .env file
    monkeypatch.setenv("AZURE_CLIENT_SECRET", "")
    
    with pytest.raises(HTTPException) as exc:
        await validate_token(Mock())
    
    assert exc.value.status_code == 500
    assert "not configured" in exc.value.detail