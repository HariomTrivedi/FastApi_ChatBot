# Gunicorn configuration file for Azure Container Apps
# Optimized for FastAPI with Uvicorn workers

import multiprocessing
import os

# Server socket
bind = f"0.0.0.0:{os.getenv('PORT', '8000')}"

# Worker processes
# Use Uvicorn's worker class for async/ASGI support
worker_class = "uvicorn.workers.UvicornWorker"

# Number of workers based on CPU cores
# For Container Apps, this scales with allocated vCPUs
workers = (multiprocessing.cpu_count() * 2) + 1

# Worker timeout (seconds)
timeout = 120

# Keep-alive timeout
keepalive = 5

# Maximum requests per worker before restart (prevents memory leaks)
max_requests = 1000
max_requests_jitter = 50

# Logging
accesslog = "-"  # stdout
errorlog = "-"   # stderr
loglevel = os.getenv("LOG_LEVEL", "info")

# Graceful timeout for worker restart
graceful_timeout = 30

# Preload application for better memory usage
preload_app = True
