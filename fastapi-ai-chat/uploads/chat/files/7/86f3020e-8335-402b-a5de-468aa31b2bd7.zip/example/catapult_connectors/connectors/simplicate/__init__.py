# Simplicate CRM Connector
from .router import router as simplicate_router

__all__ = ["simplicate_router"]
