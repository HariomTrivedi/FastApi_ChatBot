# Connector Documentation

This document provides detailed information about each connector, including authentication setup, available endpoints, and usage examples.

---

## Simplicate CRM Connector

### Overview

Simplicate is a Dutch CRM and project management system. This connector provides access to clients, projects, time tracking, and team capacity features.

### Authentication

Simplicate uses API Key + Secret authentication via custom headers.

**Required Environment Variables:**
```
SIMPLICATE_SUBDOMAIN=your-company
SIMPLICATE_API_KEY=your-api-key
SIMPLICATE_API_SECRET=your-api-secret
```

**How to get credentials:**
1. Log in to Simplicate
2. Go to Settings → API
3. Generate API credentials

### Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/simplicate/clients` | GET | List all clients |
| `/simplicate/clients/search` | GET | Search clients by name |
| `/simplicate/clients/{id}` | GET | Get specific client |
| `/simplicate/projects` | GET | List projects |
| `/simplicate/projects` | POST | Create project |
| `/simplicate/projects/{id}` | GET | Get project details |
| `/simplicate/projects/{id}` | PUT | Update project |
| `/simplicate/hours` | GET | Get time entries |
| `/simplicate/hours` | POST | Log time entry |
| `/simplicate/employees` | GET | List employees |
| `/simplicate/capacity` | GET | Check team capacity |

### Key Features

#### Capacity Check
The capacity endpoint analyzes team availability based on logged hours:

```json
{
  "overall_status": "GREEN",  // GREEN/YELLOW/RED
  "employees": [
    {
      "employee_name": "John Doe",
      "utilization_pct": 65.5,
      "available_hours": 27.6,
      "status": "GREEN"
    }
  ],
  "suggested_team": ["John Doe", "Jane Smith"]
}
```

Status thresholds:
- **GREEN**: < 70% utilization (available)
- **YELLOW**: 70-90% utilization (limited)
- **RED**: > 90% utilization (fully booked)

---

## Trello Connector

### Overview

Trello is a kanban-style project management tool. This connector provides access to boards, lists, cards, and todo tracking.

### Authentication

Trello uses API Key + Token authentication via query parameters.

**Required Environment Variables:**
```
TRELLO_API_KEY=your-api-key
TRELLO_API_TOKEN=your-api-token
```

**How to get credentials:**
1. Get API key: https://trello.com/power-ups/admin/
2. Generate token with the API key

### Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/trello/boards` | GET | List all boards |
| `/trello/boards` | POST | Create board |
| `/trello/boards/{id}` | GET | Get board details |
| `/trello/boards/{id}/lists` | GET | Get lists on board |
| `/trello/boards/{id}/cards` | GET | Get cards on board |
| `/trello/boards/{id}/members` | GET | Get board members |
| `/trello/cards` | POST | Create card |
| `/trello/cards/{id}` | GET | Get card details |
| `/trello/cards/{id}` | PUT | Update card |
| `/trello/cards/{id}` | DELETE | Delete card |
| `/trello/todos` | GET | Get cards with due dates |

### Key Features

#### Todo Summary
The todos endpoint aggregates cards with due dates across boards:

```json
{
  "total_todos": 15,
  "overdue_count": 2,
  "due_today_count": 3,
  "due_this_week_count": 5,
  "cards": [
    {
      "name": "Complete report",
      "due": "2025-01-15T17:00:00Z",
      "is_overdue": true,
      "board_name": "Project X",
      "list_name": "In Progress"
    }
  ]
}
```

---

## Microsoft Graph - Mail Connector

### Overview

Provides access to Outlook mail functionality via Microsoft Graph API. Uses On-Behalf-Of (OBO) authentication to access the authenticated user's mailbox via Copilot Studio.

### Authentication

Uses OAuth 2.0 On-Behalf-Of flow. The user's token from Copilot Studio is exchanged for a Microsoft Graph token.

**Required Environment Variables:**
```
AZURE_TENANT_ID=your-tenant-id
AZURE_CLIENT_ID=your-app-client-id
AZURE_CLIENT_SECRET=your-client-secret
```

**Required API Permissions (Delegated):**
- `Mail.Read` - Read user's mail
- `Mail.Send` - Send mail as user
- `Mail.ReadWrite` - Read and write user's mail
- `User.Read` - Sign in and read user profile

**How to set up:**
1. Register app in Azure AD
2. Add API permissions (Microsoft Graph → Delegated)
3. Create client secret
4. Configure Copilot Studio authentication to use this app registration

### Endpoints

#### Basic Mail Operations

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/mail/inbox` | GET | Get inbox messages |
| `/mail/messages/{id}` | GET | Get specific message |
| `/mail/send` | POST | Send email |
| `/mail/messages/{id}/forward` | POST | Forward message |
| `/mail/messages/{id}` | PATCH | Update message |
| `/mail/messages/{id}/move` | POST | Move message to folder |
| `/mail/folders` | GET | Get mail folders |

#### Draft Email Operations

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/mail/drafts` | GET | List draft emails |
| `/mail/drafts` | POST | Create a draft email |
| `/mail/drafts/{id}` | PATCH | Update a draft |
| `/mail/drafts/{id}/send` | POST | Send a draft |

#### Folder Management

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/mail/folders` | POST | Create a mail folder |
| `/mail/folders/{id}` | PATCH | Rename/update folder |
| `/mail/folders/{id}` | DELETE | Delete a mail folder |
| `/mail/folders/{id}/children` | GET | List child folders (nested) |

### Key Features

#### OData Filters
The inbox endpoint supports OData filters:

```
/mail/inbox?filter=isRead eq false
/mail/inbox?filter=importance eq 'high'
/mail/inbox?filter=hasAttachments eq true
```

#### Draft Workflow
Create, edit, and send draft emails:

```json
// POST /mail/drafts - Create draft
{
  "subject": "Project Update",
  "body_content": "<p>Here's the latest update...</p>",
  "to_recipients": ["colleague@company.com"],
  "importance": "normal"
}

// PATCH /mail/drafts/{id} - Update draft
{
  "subject": "Updated: Project Update",
  "to_recipients": ["colleague@company.com", "manager@company.com"]
}

// POST /mail/drafts/{id}/send - Send when ready
```

#### Folder Organization
Create custom folders and organize emails:

```json
// POST /mail/folders - Create folder
{
  "display_name": "Project X",
  "parent_folder_id": null  // null for root level
}

// POST /mail/folders - Create nested folder
{
  "display_name": "Important",
  "parent_folder_id": "AAMk..."  // parent folder ID
}

// POST /mail/messages/{id}/move - Move message
{
  "destination_folder_id": "AAMk..."
}
```

---

## Microsoft Graph - Calendar Connector

### Overview

Provides access to Outlook calendar functionality via Microsoft Graph API using OBO authentication.

### Authentication

Same as Mail connector (shared GraphAuth).

**Required API Permissions (Delegated):**
- `Calendars.Read` - Read user calendars
- `Calendars.ReadWrite` - Have full access to user calendars

### Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/calendar/events` | GET | List events |
| `/calendar/view` | GET | Get events in date range |
| `/calendar/events` | POST | Create event |
| `/calendar/events/{id}` | GET | Get event details |
| `/calendar/events/{id}` | PATCH | Update event |
| `/calendar/events/{id}` | DELETE | Delete event |
| `/calendar/availability` | POST | Check free/busy times |

### Key Features

#### Teams Meeting Integration
Creating events with `is_online_meeting: true` automatically creates a Teams meeting:

```json
{
  "subject": "Team Standup",
  "is_online_meeting": true,
  "attendees": ["user@domain.com"]
}
```

Response includes:
```json
{
  "online_meeting_url": "https://teams.microsoft.com/l/meetup-join/..."
}
```

---

## Microsoft Graph - SharePoint Connector

### Overview

Provides access to SharePoint sites, document libraries, and files via Microsoft Graph API using OBO authentication.

### Authentication

Same as Mail connector (shared GraphAuth).

**Required API Permissions (Delegated):**
- `Sites.Read.All` - Read items in all site collections
- `Files.Read.All` - Read all files that user can access
- `Files.ReadWrite.All` - Have full access to all files user can access

### Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/sharepoint/sites` | GET | List SharePoint sites |
| `/sharepoint/sites/{id}/drives` | GET | Get document libraries |
| `/sharepoint/drives/{id}/items` | GET | List files/folders |
| `/sharepoint/drives/{id}/items/{id}` | GET | Get item metadata |
| `/sharepoint/upload` | POST | Upload file |
| `/sharepoint/download/{drive_id}/{item_id}` | GET | Download file |
| `/sharepoint/folders` | POST | Create folder |
| `/sharepoint/search` | GET | Search files |

### Key Features

#### Path Navigation
Navigate folders using folder_path parameter:

```
/sharepoint/drives/{id}/items?folder_path=Projects/ClientA/Documents
```

---

## Word Documents Connector

### Overview

Provides functionality to create, modify, and analyze Microsoft Word (.docx) documents. Uses the python-docx library locally. Includes SharePoint integration for editing and saving documents directly to/from SharePoint.

### Authentication

- **Local operations**: No authentication required
- **SharePoint operations**: Uses shared GraphAuth (same as Mail/Calendar connectors)

### Endpoints

#### Local Document Operations

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/word/create` | POST | Create document from structure |
| `/word/from-template` | POST | Create from template |
| `/word/append-paragraph` | POST | Add paragraph to document |
| `/word/append-table` | POST | Add table to document |
| `/word/replace-text` | POST | Find and replace text |
| `/word/analyze` | POST | Get document statistics |
| `/word/extract-text` | POST | Extract plain text |

#### SharePoint Integration (Atomic Operations)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/word/sharepoint/save` | POST | Create document and save to SharePoint |
| `/word/sharepoint/append-paragraph` | POST | Download, append paragraph, save back |
| `/word/sharepoint/append-table` | POST | Download, append table, save back |
| `/word/sharepoint/replace-text` | POST | Download, find/replace, save back |
| `/word/sharepoint/from-template` | POST | Fill SharePoint template, save result |

### Key Features

#### Section Types

When creating documents, use these section types:

| Type | Description | Content Fields |
|------|-------------|----------------|
| `heading` | Heading (H1-H6) | `text`, `level` |
| `paragraph` | Text paragraph | `text`, `style`, `alignment`, `font_style` |
| `table` | Data table | `headers`, `rows`, `style` |
| `list_bullet` | Bullet list | `items` |
| `list_number` | Numbered list | `items` |
| `image` | Inline image | `base64_data`, `filename`, `width_inches` |
| `page_break` | Page break | (empty) |

#### Font Styling

Apply font styles to paragraphs:

```json
{
  "font_style": {
    "bold": true,
    "italic": false,
    "underline": false,
    "size_pt": 14,
    "color_hex": "0066CC",
    "font_name": "Arial"
  }
}
```

#### Template Placeholders

Templates support placeholder replacement:
- Use format: `{{placeholder_name}}`
- Placeholders work in paragraphs, tables, headers, and footers

Example template content:
```
Dear {{client_name}},

This proposal for {{project_name}} is dated {{date}}.

Total: {{total_amount}}
```

#### SharePoint Integration

The SharePoint integration endpoints provide atomic operations that download a document, modify it, and upload it back in a single request.

**Save Created Document to SharePoint:**
```json
// POST /word/sharepoint/save
{
  "drive_id": "b!abc123...",
  "folder_path": "Documents/Reports",
  "file_name": "Monthly_Report",
  "document": {
    "title": "Monthly Report",
    "sections": [
      {"type": "heading", "content": {"text": "Summary", "level": 1}},
      {"type": "paragraph", "content": {"text": "This month's highlights..."}}
    ]
  }
}
```

**Edit SharePoint Document (Append Paragraph):**
```json
// POST /word/sharepoint/append-paragraph
{
  "drive_id": "b!abc123...",
  "item_id": "01ABC...",
  "paragraph": {
    "text": "This paragraph was added via the API.",
    "font_style": {"bold": true}
  }
}
```

**Fill Template from SharePoint:**
```json
// POST /word/sharepoint/from-template
{
  "template_drive_id": "b!abc123...",
  "template_item_id": "01TEMPLATE...",
  "replacements": {
    "{{client_name}}": "Acme Corp",
    "{{project_name}}": "Website Redesign",
    "{{date}}": "2025-01-15"
  },
  "output_drive_id": "b!abc123...",
  "output_folder_path": "Documents/Proposals",
  "output_file_name": "Proposal_AcmeCorp"
}
```

**Response Format:**
```json
{
  "success": true,
  "message": "Document saved to SharePoint: Monthly_Report.docx",
  "item_id": "01XYZ...",
  "item_name": "Monthly_Report.docx",
  "web_url": "https://company.sharepoint.com/...",
  "size_bytes": 15432
}
```

---

## Common Patterns

### Error Handling

All connectors return consistent error responses:

```json
{
  "error": "NOT_FOUND",
  "message": "Project with ID xyz not found",
  "details": {"project_id": "xyz"},
  "connector": "simplicate"
}
```

### Pagination

Endpoints that return lists support pagination:

```
?limit=100&offset=0
```

### Base64 Encoding

Word documents are transferred as base64-encoded strings:

```python
import base64

# Decode received document
doc_bytes = base64.b64decode(response["document_base64"])
with open("output.docx", "wb") as f:
    f.write(doc_bytes)

# Encode document for sending
with open("template.docx", "rb") as f:
    template_base64 = base64.b64encode(f.read()).decode("utf-8")
```
